# A6 / Work v0.3 / B mock 통합 실행 패키지

Node.js24에서 이 ZIP 전체를 풀고 최상위 폴더에서 한 명령으로 실행합니다. npm·인증·네트워크 불필요합니다.

```sh
node bridge/tools/e2e.cjs
```

구현·복구·테스트·남은 조건: `bridge/README.md`.
전체 A6 원본 ZIP: `baseline/local6/full.zip`. 최종 A6 TXT는 `scripts/A6_Code.gs.txt`에도 제공합니다. B 전체 실행 TXT는 `b11/scripts/`, 새 bridge 전체 TXT는 `bridge/scripts/`입니다. Node 전용 파일을 운영 Apps Script에 붙여넣지 마세요.

첫 프로세스의 소스·중앙 원장·발송 원장·정책 거부·키 연결·실행 로그는 `bridge/reports/e2e-first/`, 동일 원장을 사용한 두 번째 프로세스의 추가 요청0 증거는 `e2e-second/`입니다. 수락 회귀는 A6 420/B133/Work기존286/bridge56 통과입니다. 신규 성공 입력·시간은 합성이며 실제 Google·Telegram 실증이 아닙니다.

`SHA256SUMS.txt`는 이 패키지 전 파일을 검사합니다. `git-metadata.json`에 브랜치·커밋·diff 기준과 기존 A6/B ZIP 전체 SHA가 있습니다. 실제 운영·clone·Telegram 실행0, 원격 게시0이며 운영 NO-GO를 유지합니다.
