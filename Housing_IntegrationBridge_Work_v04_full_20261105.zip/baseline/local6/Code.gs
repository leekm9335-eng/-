'use strict';
const LH_BASE = 'https://apply.lh.or.kr/lhapply/apply/wt/wrtanc/';
const INITIAL_FROM = '2026-09-18';
const MASTER_HEADERS = ['공고 고유ID','최초 발견일','공고 게시일','공급 구분','공급기관','공고명','모집 차수','변경 유형','시·도','시·군·구','단지명','건물 유형','전용 최소(㎡)','전용 최대(㎡)','공급 세대수','분양가·보증금(원)','월 임대료(원)','접수 시작일','접수 마감일','당첨 발표일','입주 예정일','중요 표시','★중요★ 판단 근거','자격 확인','추천 신청자','진행 상태','공식 원문 URL','원문 확인 상태','최종 확인일','정정 전후 변경','비고','마감 D-day','중복 점검','수집경로','원천공고번호','원천시스템','내용해시','최종수집시각','원문스냅샷키','연관공고ID'];
function textOf(s) { return String(s).replace(/<em\b[^>]*class="(?:day|new)"[^>]*>[\s\S]*?<\/em>/gi,'').replace(/<[^>]+>/g,' ').replace(/&nbsp;/g,' ').replace(/&amp;/g,'&').replace(/&#39;|&#x27;/g,"'").replace(/&quot;/g,'"').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/\s+/g,' ').trim(); }
function qs(p) {return Object.keys(p).map(k=>encodeURIComponent(k)+'='+encodeURIComponent(p[k])).join('&');}
function lhUrl(kind,page,to) {return LH_BASE+'selectWrtancList.do?'+qs({mi:kind==='lease'?'1026':'1027',srchUppAisTpCd:kind==='lease'?'061339':'053954',uppAisTpCd:kind==='lease'?'06':'05',srchY:'Y',panSs:'',schTy:'0',startDt:INITIAL_FROM,endDt:to,listCo:100,currPage:page});}
function parseLh(html,kind) {
 const totalMatch=html.match(/class="bbs_total"[^>]*>\s*전체\s*<strong>\s*([\d,]+)/);
 if(!totalMatch) throw Error('LH 목록 총건수 표식 없음: 차단/HTML 변경');
 const total=Number(totalMatch[1].replace(/,/g,'')),records=[];let buttons=0;
 for(const tr of html.match(/<tr\b[^>]*>[\s\S]*?<\/tr>/gi)||[]) {
  if(!tr.includes('wrtancInfoBtn')) continue;buttons++;
  const a=tr.match(/<a\b[^>]*class="wrtancInfoBtn"[^>]*>([\s\S]*?)<\/a>/i);
  if(!a) throw Error('LH 공고 링크 구조 변경');
  const ids=[1,2,3,4].map(n=>(a[0].match(new RegExp('data-id'+n+'="([^"]+)"'))||[])[1]);
  const td=[...tr.matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map(m=>textOf(m[1]));
  if(ids.some(v=>!v)||td.length!==9) throw Error('LH ID 또는 열 구조 변경');
  const [pan,ccr,upp,ais]=ids;
  const title=textOf(a[1]);
  const url=LH_BASE+'selectWrtancInfo.do?'+qs({panId:pan,ccrCnntSysDsCd:ccr,uppAisTpCd:upp,aisTpCd:ais});
  records.push({id:'LH:'+ccr+':'+pan,number:pan,system:ccr,source:'LH_'+kind,agency:'LH청약플러스',title,published:td[5].replace(/\./g,'-'),region:td[3],type:td[1],supply:kind==='lease'?'공공임대':'공공분양',status:td[7],url,boardDeadline:td[6].replace(/\./g,'-'),change:/정정/.test(title)?'정정공고':/추가|재모집/.test(title)?'추가모집':'신규',raw:JSON.stringify({ids,td})});
 }
 if(records.length!==buttons||(total>0&&!records.length))throw Error('LH 파싱 누락');
 return {total,records};
}
function collectLh(kind,to,fetchText) {
 let all=[],expected=null,pagingHtml='';
 for(let page=1;page<=100;page++) {
  const request=page===1?null:lhPagingRequest42A3(pagingHtml,page);
  const h=page===1?fetchText(lhUrl(kind,page,to)):fetchText(request.url,request.options);
  pagingHtml=h;
  if(page>1&&!(new RegExp('name=\"currPage\"\\s+value=\"'+page+'\"')).test(h))throw Error('PARTIAL: LH 요청 페이지 미반영');
  if(!h.includes('value="'+INITIAL_FROM+'"')||!h.includes('value="'+to+'"'))throw Error('LH 조회기간 미반영');
  const sel=(h.match(/<select\b[^>]*id="panSs"[\s\S]*?<\/select>/)||[])[0];
  if(!sel||!/<option value=""\s+selected/.test(sel))throw Error('LH 전체 상태 필터 미반영');
  const p=parseLh(h,kind);
  if(expected===null)expected=p.total;
  if(expected!==p.total)throw Error('LH 수집 중 총건수 변경: 다음 실행 재점검');
  if(p.records.some(r=>r.published<INITIAL_FROM||r.published>to))throw Error('LH 날짜 범위 이탈');
  all.push(...p.records);
  if(all.length>=expected) {
   if(all.length!==expected||new Set(all.map(r=>r.id)).size!==expected)throw Error('LH 전체건수/고유ID 불일치');
   return all;
  }
  if(!p.records.length)throw Error('LH 중간 페이지 비어 있음');
 }
 throw Error('LH 100페이지 상한: 전체 점검 실패');
}
const APPLY_ENDPOINTS=['getAPTLttotPblancDetail','getUrbtyOfctlLttotPblancDetail','getRemndrLttotPblancDetail','getPblPvtRentLttotPblancDetail','getOPTLttotPblancDetail'];
function collectApply(endpoint,to,key,fetchText) {
 if(!key)throw Error('청약홈 인증키 미설정');
 const base='https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/'+endpoint;
 const probe=JSON.parse(fetchText(base+'?'+qs({page:1,perPage:1,serviceKey:key})));
 if(!Array.isArray(probe.data)||!Number.isInteger(probe.totalCount)||probe.currentCount!==probe.data.length)throw Error('PARSE: API 형식 확인 응답');
 if(probe.totalCount===0||!probe.data.length)throw Error('PARTIAL: 무필터 API 표본 없음·실공고 미검증');
 const sampleDate=String(probe.data[0].RCRIT_PBLANC_DE||'');
 if(!/^\d{8}$|^\d{4}-\d{2}-\d{2}$/.test(sampleDate))throw Error('PARSE: API 날짜형식 변경');
 const apiDate=d=>/^\d{8}$/.test(sampleDate)?d.replace(/-/g,''):d;
 let rows=[],total=null;
 for(let page=1;page<=100;page++) {
  const u='https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/'+endpoint+'?'+qs({page,perPage:100,serviceKey:key,'cond[RCRIT_PBLANC_DE::GTE]':apiDate(INITIAL_FROM),'cond[RCRIT_PBLANC_DE::LTE]':apiDate(to)});
  const j=JSON.parse(fetchText(u));
  if(!Array.isArray(j.data)||!Number.isInteger(j.matchCount)||j.currentCount!==j.data.length)throw Error('청약홈 오류/응답 스키마 변경');
  if(total===null){total=j.matchCount;const d=dateClean(sampleDate);if(total===0&&d>=INITIAL_FROM&&d<=to)throw Error('PARTIAL: 조회기간 내 공식 표본 존재하지만 필터 결과0건');}

  if(total!==j.matchCount)throw Error('청약홈 수집 중 총건수 변경');
  rows.push(...j.data);
  if(rows.length>=total) {
   if(rows.length!==total)throw Error('청약홈 총건수 불일치');
   const normalized=rows.map(r=>normalizeApply(r,endpoint));
   if(new Set(normalized.map(r=>r.id)).size!==total)throw Error('청약홈 중복 페이지');
   return normalized;
  }
  if(!j.data.length)throw Error('청약홈 중간 페이지 비어 있음');
 }
 throw Error('청약홈 페이지 상한 초과');
}
function v1NormalizeApply(r,endpoint) {
 if(!r.HOUSE_MANAGE_NO||!r.PBLANC_NO||!r.HOUSE_NM||!r.RCRIT_PBLANC_DE)throw Error('청약홈 필수 식별자 누락');
 return {id:'APPLYHOME:'+r.HOUSE_MANAGE_NO+':'+r.PBLANC_NO,number:String(r.PBLANC_NO),system:'APPLYHOME',source:endpoint,agency:'청약홈',title:r.HOUSE_NM,published:r.RCRIT_PBLANC_DE,region:r.SUBSCRPT_AREA_CODE_NM||'',address:r.HSSPLY_ADRES||'',type:endpoint==='getAPTLttotPblancDetail'?'아파트':'확인 필요',supply:/Rent|Urbty/.test(endpoint)?'공급구분 확인 필요':'분양(공공·민간 확인 필요)',status:'일정 확인 필요',url:r.PBLANC_URL||'',begin:r.RCEPT_BGNDE||'',end:r.RCEPT_ENDDE||'',winner:r.PRZWNER_PRESNATN_DE||'',move:r.MVN_PREARNGE_YM||'',count:r.TOT_SUPLY_HSHLDCO||'',change:/정정/.test(r.HOUSE_NM)?'정정공고':/추가|재모집/.test(r.HOUSE_NM)?'추가모집':'신규',raw:JSON.stringify(r)};
}
function semantic(r) {const x={...r};delete x.raw;delete x.source;return JSON.stringify(x,Object.keys(x).sort());}
function important(r){return importantV2(r,null);}
function masterRow35V4(r,now,hash,snapshot) {
 const imp=important(r),row=Array(40).fill('');
 const vals={0:r.id,1:now,2:r.published,3:r.supply,4:r.agency,5:r.title,6:'원문 확인 필요',7:r.change,8:r.region,10:r.title,11:r.type==='아파트'?'아파트':'확인 필요',14:r.count||'',17:r.begin||'',18:r.end||'',19:r.winner||'',20:r.move||'',21:imp[0],22:imp[1],23:'공고일 기준 자격 검토 필요',25:r.status,26:r.url,27:'공식 목록 확인·상세/첨부 미검증',28:now,30:r.source.startsWith('LH_')?'목록 마감일 '+r.boardDeadline+' (접수 마감일로 대입하지 않음); '+r.type:'API 상세 데이터 수집; 첨부 원문·주택형 미검증',33:r.source,34:r.number,35:r.system,36:hash,37:now,38:snapshot};
 Object.keys(vals).forEach(i=>row[Number(i)]=vals[i]);return row;
}
function v1PlanUpsert(existing,records,now,hashFn) {
 const index=new Map();existing.forEach((row,i)=>{if(row[0]){if(index.has(row[0]))throw Error('기존 원장 ID 중복: '+row[0]);index.set(row[0],{row:row.slice(),position:i+4});}});
 const writes=[],history=[],raw=[],events=[];let added=0,changed=0,unchanged=0,excluded=0;
 for(const r of records) {
  const pureResult=resultNotice52A(r.title)&&noticeKind52A(r.title)==='EXCLUDED';if(pureResult&&!index.has(r.id)){excluded++;raw.push([r.id+':RESULT:'+hashFn(semantic(r)),now,r.source,r.url,'제외: 결과/대상자 발표·원천 버전 보존',r.raw]);continue;}
  if(/가정어린이집|상가|토지/.test(r.type)||(!pureResult&&/당첨자발표|선정결과발표|신청현황/.test(r.title))){excluded++;raw.push([r.id,now,r.source,r.url,'제외: 주택 입주자 모집 대상 아님',r.raw]);continue;}
  const hash=hashFn(semantic(r)),snap=r.id+':'+hash,old=index.get(r.id);
  if(old&&old.row[36]===hash){unchanged++;continue;}
  const row=masterRow(r,now,hash,snap);
  if(old){row[1]=old.row[1];for(const i of [6,9,10,11,12,13,15,16,23,24,27,39])if(old.row[i]!==''&&old.row[i]!=null)row[i]=old.row[i];
   if(String(old.row[27]||'').includes('원문 확인'))row[27]='변경 감지·원문 재확인 필요';
   row[7]='변경 감지';row[29]='수집 필드 변경 (정정 여부 원문 확인 필요)';changed++;
   const fields=[];for(let i=0;i<31;i++)if(![1,28,29,7].includes(i)&&String(old.row[i]||'')!==String(row[i]||''))fields.push(MASTER_HEADERS[i]);
   history.push([r.id,now,r.published,'수집내용 변경',fields.join(', '),JSON.stringify(old.row.slice(0,31)),JSON.stringify(row.slice(0,31)),'확인 필요',r.url,'원문 재확인 필요',snap]);
  }else{added++;}
  const position=old?old.position:4+existing.length+(added-1);
  row[31]='=IF(S'+(position+1)+'="","",IFERROR(DATEVALUE(S'+(position+1)+')-TODAY(),""))';
  row[32]='=IF(A'+(position+1)+'="","",IF(COUNTIF(A$5:A,A'+(position+1)+')>1,"중복","고유"))';
  row[31]=formula52A(row[31]);row[32]=formula52A(row[32]);writes.push({position,row});index.set(r.id,{position,row});
  raw.push([snap,now,r.source,r.url,'수집원본',r.raw]);if(!pureResult)events.push([snap,r.id,now,old?'변경':'신규','미발송','후속 단계: 텔레그램 묶음 발송',r.url]);
 }
 return {writes,history,raw,events,added,changed,unchanged,excluded};
}
const SPREADSHEET_ID='14pkdPEgFzF2uEsA2oj9v8d6NK2qj4yNMlwUbqaMciVQ';
function onOpen(){SpreadsheetApp.getUi().createMenu('청약 수집').addItem('지금 목록 수집(운영 쓰기)','runCollection').addItem('실행/트리거 상태 확인(읽기 전용)','inspect52AReadOnly').addItem('자동실행 관리 안내(설치·삭제 안 함)','triggerGuide52A').addToUi();}
function nowKst(){return Utilities.formatDate(new Date(),'Asia/Seoul','yyyy-MM-dd HH:mm:ss');}
function todayKst(){return Utilities.formatDate(new Date(),'Asia/Seoul','yyyy-MM-dd');}
function digest(s){return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,s,Utilities.Charset.UTF_8).map(b=>('0'+((b+256)%256).toString(16)).slice(-2)).join('');}
function legacyFetch3535V4(url){
 for(let i=0;i<3;i++){
  const r=UrlFetchApp.fetch(url,{muteHttpExceptions:true,followRedirects:true});const status=r.getResponseCode();
  if(status===200)return r.getContentText('UTF-8');
  if(status<500&&status!==429)throw Error('HTTP '+status+' (응답/인증키 비공개)');
  if(i===2)throw Error('HTTP '+status+' 재시도 소진');Utilities.sleep(1000*(i+1));
 }
}
function cell(v){if(v&&typeof v==='object'&&typeof v._formula52A==='string')return {userEnteredValue:{formulaValue:v._formula52A}};if(v instanceof Date)v=Utilities.formatDate(v,'Asia/Seoul','yyyy-MM-dd HH:mm:ss');return {userEnteredValue:typeof v==='number'?{numberValue:v}:{stringValue:String(v??'')}};}
function block(sheetId,start,rows){return {updateCells:{range:{sheetId,startRowIndex:start,endRowIndex:start+rows.length,startColumnIndex:0,endColumnIndex:rows[0].length},rows:rows.map(row=>({values:row.map(cell)})),fields:'userEnteredValue'}};}
function batch35V4(requests){
 const ss=SpreadsheetApp.openById(SPREADSHEET_ID),sheets=new Map(ss.getSheets().map(s=>[s.getSheetId(),s]));
 const updates=[];
 for(const request of requests){
  if(request.appendDimension){const d=request.appendDimension,s=sheets.get(d.sheetId);if(d.dimension!=='ROWS')throw Error('지원하지 않는 확장');s.insertRowsAfter(s.getMaxRows(),d.length);continue;}
  const u=request.updateCells;if(!u)throw Error('지원하지 않는 저장 요청');
  const g=u.start||u.range,id=g.sheetId,row=g.rowIndex??g.startRowIndex,col=g.columnIndex??g.startColumnIndex;
  const values=u.rows.map(r=>r.values.map(c=>{const v=c.userEnteredValue||{};if(v.formulaValue!==undefined)return v.formulaValue;if(v.numberValue!==undefined)return v.numberValue;const t=String(v.stringValue??'');return /^[=+@-]/.test(t)?"'"+t:t;}));
  if(!values.length||values.some(r=>r.length!==values[0].length))throw Error('저장 행 폭 불일치');
  updates.push({sheet:sheets.get(id),row,col,values});
 }
 const sourceNames=['정정이력','수집원본','발송대기'];
 for(const u of updates.filter(u=>sourceNames.includes(u.sheet.getName()))){
  const keyCol=u.sheet.getName()==='정정이력'?10:0,start=u.sheet.getName()==='정정이력'?5:2,last=u.sheet.getLastRow();
  const existing=new Set(last>=start?u.sheet.getRange(start,keyCol+1,last-start+1,1).getValues().flat().map(String):[]);
  const fresh=u.values.filter(r=>{const k=String(r[keyCol]);if(existing.has(k))return false;existing.add(k);return true;});
  if(fresh.length){const at=u.sheet.getLastRow()+1,need=at+fresh.length-1;if(need>u.sheet.getMaxRows())u.sheet.insertRowsAfter(u.sheet.getMaxRows(),need-u.sheet.getMaxRows());u.sheet.getRange(at,u.col+1,fresh.length,fresh[0].length).setValues(fresh);}
 }
 SpreadsheetApp.flush();
 for(const u of coalesceUpdates52A(updates.filter(u=>u.sheet.getName()==='공고원장')))u.sheet.getRange(u.row+1,u.col+1,u.values.length,u.values[0].length).setValues(u.values);
 SpreadsheetApp.flush();
 for(const u of updates.filter(u=>!sourceNames.includes(u.sheet.getName())&&u.sheet.getName()!=='공고원장'))u.sheet.getRange(u.row+1,u.col+1,u.values.length,u.values[0].length).setValues(u.values);
 SpreadsheetApp.flush();
}
function ensureSupport(ss){
 const definitions={'수집원본':['스냅샷키','수집시각','수집경로','공식URL','구분','원천JSON'],'발송대기':['이벤트ID','공고ID','생성시각','이벤트유형','전송상태','메모','공식URL'],'수집상태':['수집경로','최근시도(KST)','최근결과','마지막 정상수집(KST)','조회시작','조회종료','확인수','누적신규','누적변경','잔여위험']};
 for(const name of Object.keys(definitions)){let s=ss.getSheetByName(name);if(!s){s=ss.insertSheet(name);s.getRange(1,1,1,definitions[name].length).setValues([definitions[name]]);s.setFrozenRows(1);}}
 const master=ss.getSheetByName('공고원장');const header=master.getRange(4,1,1,40).getValues()[0];
 for(let i=0;i<33;i++)if(header[i]!==MASTER_HEADERS[i])throw Error('공고원장 기존 헤더 불일치: '+(i+1));
 for(let i=33;i<40;i++)if(header[i]&&header[i]!==MASTER_HEADERS[i])throw Error('공고원장 확장 열 충돌');
 master.getRange(4,34,1,7).setValues([MASTER_HEADERS.slice(33)]);
}
function v1RunCollection(){
 const lock=LockService.getScriptLock();if(!lock.tryLock(1000))return;
 const start=Date.now();
 try{
  const ss=SpreadsheetApp.openById(SPREADSHEET_ID);ensureSupport(ss);
  const to=todayKst(),key=PropertiesService.getScriptProperties().getProperty('APPLYHOME_SERVICE_KEY');
  const sources=[{id:'LH_lease',agency:'LH청약플러스',label:'임대 게시판',url:lhUrl('lease',1,to),run:()=>collectLh('lease',to,fetchText)},{id:'LH_sale',agency:'LH청약플러스',label:'분양 게시판',url:lhUrl('sale',1,to),run:()=>collectLh('sale',to,fetchText)},...APPLY_ENDPOINTS.map(e=>({id:e,agency:'청약홈',label:e,url:'https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/'+e,run:()=>collectApply(e,to,key,fetchText)}))];
  for(const src of sources){
   try{if(Date.now()-start>240000)throw Error('실행시간 예산 초과: 다음 주기 재점검');const records=src.run();saveResult(ss,src,records,null,to);}
   catch(e){saveResult(ss,src,[],safeError(e),to);}
  }
  ss.getSheetByName('대시보드').getRange('B8').setValue('부분 수집: 수집상태 탭 확인 / 전국 전체점검 미완료');refreshDashboard(ss);
 }finally{lock.releaseLock();}
}
function safeError(e){return String(e.message||e).replace(/([?&]serviceKey=)[^&\s]+/gi,'$1[비공개]').slice(0,300);}
function saveResult(ss,src,records,error,to){
 const now=nowKst(),master=ss.getSheetByName('공고원장');
 const existing=master.getLastRow()>4?safeMasterRows52A(master,40):[];
 const p=error?{writes:[],history:[],raw:[],events:[],added:0,changed:0,unchanged:0,excluded:0}:planUpsert(existing,records,now,digest,{ss,snapshots:ss.getSheetByName('수집원본').getDataRange().getValues()});
 const requests=[],allocated=new Map();
 function write(s,start,rows){if(!rows.length)return;const id=s.getSheetId(),size=allocated.get(id)||s.getMaxRows(),need=start+rows.length;if(need>size){requests.push({appendDimension:{sheetId:id,dimension:'ROWS',length:need-size}});allocated.set(id,need);}requests.push(block(id,start,rows));}
 for(const w of p.writes)write(master,w.position,[w.row]);
 write(ss.getSheetByName('정정이력'),ss.getSheetByName('정정이력').getLastRow(),p.history);
 write(ss.getSheetByName('수집원본'),ss.getSheetByName('수집원본').getLastRow(),p.raw);
 write(ss.getSheetByName('발송대기'),ss.getSheetByName('발송대기').getLastRow(),p.events.map(e=>Array.from({length:10},(_,i)=>e[i]===undefined?'':e[i])));
 const logs=ss.getSheetByName('기관점검');
 write(logs,logs.getLastRow(),[[now.slice(0,10),now.slice(11),src.agency,src.label,src.url,'자동수집 / '+src.id,INITIAL_FROM,to,error?'실패':'목록 수집 성공',error?'':records.length,p.added,p.changed,error||'상세/첨부 원문·타기관 교차검증 미완료',to,'제외 '+p.excluded+'건; 동일 '+p.unchanged+'건']]);
 const state=ss.getSheetByName('수집상태'),data=state.getDataRange().getValues();let at=data.findIndex((r,i)=>i>0&&r[0]===src.id);let old=at<0?[]:data[at];if(at<0)at=data.length;
 write(state,at,[[src.id,now,error?'실패':src.partial35?'일부 누락 가능':'목록 수집 성공',(error||src.partial35)?(old[3]||''):now,INITIAL_FROM,to,error?'':records.length,existing.filter(r=>r[33]===src.id).length+p.added,Number(old[8]||0)+p.changed,error||'상세첨부/전국기관 미검증']]);
 batch(requests);return {added:p.added,changed:p.changed,unchanged:p.unchanged};
}
function installHourlyTrigger(){removeCollectionTriggers();ScriptApp.newTrigger('runCollection').timeBased().everyHours(1).create();}
function removeCollectionTriggers(){for(const t of ScriptApp.getProjectTriggers())if(t.getHandlerFunction()==='runCollection')ScriptApp.deleteTrigger(t);}

function legacyRefreshDashboard(ss=SpreadsheetApp.openById(SPREADSHEET_ID)){
 const state=ss.getSheetByName('수집상태').getDataRange().getValues().filter(r=>r[0]==='LH_lease'||r[0]==='LH_sale');
 const times=state.map(r=>r[3] instanceof Date?Utilities.formatDate(r[3],'Asia/Seoul','yyyy-MM-dd HH:mm:ss'):String(r[3]||'')).filter(Boolean).sort();
 ss.getSheetByName('대시보드').getRange('B10').setValue(times.length===2?times[0]:'LH 양쪽 정상수집 확인 필요');
 const active=ScriptApp.getProjectTriggers().filter(t=>t.getHandlerFunction()==='runCollection').length;
 ss.getSheetByName('대시보드').getRange('B11').setValue(active?'자동실행 활성 (시간 트리거 '+active+'개)':'자동실행 미설치');
}
function startTimerVerification(){ScriptApp.newTrigger('verifyTimerOnce').timeBased().after(60000).create();}
function verifyTimerOnce(){try{runCollection();}finally{for(const t of ScriptApp.getProjectTriggers())if(t.getHandlerFunction()==='verifyTimerOnce')ScriptApp.deleteTrigger(t);}}

// Shared parser: Node verification and Google Apps Script use exactly this source.
function cleanHtml(h){return h.replace(/<!--[\s\S]*?-->/g,'').replace(/<script\b[\s\S]*?<\/script>/gi,'');}
function tableGrid(html){
 const grid=[];let ri=0;
 for(const m of html.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)){
  const row=grid[ri]||(grid[ri]=[]);let ci=0;
  for(const c of m[1].matchAll(/<(?:td|th)\b([^>]*)>([\s\S]*?)<\/(?:td|th)>/gi)){
   while(row[ci]!==undefined)ci++;
   const rs=Number((c[1].match(/rowspan=['"]?(\d+)/i)||[])[1]||1),cs=Number((c[1].match(/colspan=['"]?(\d+)/i)||[])[1]||1),v=textOf(c[2]);
   if(rs>100||cs>100)throw Error('PARSE: 비정상 표 병합');
   for(let y=0;y<rs;y++){grid[ri+y]||(grid[ri+y]=[]);for(let x=0;x<cs;x++)grid[ri+y][ci+x]=v;}ci+=cs;
  }ri++;
 }return grid.filter(r=>r.length);
}
function dateClean(s){const t=String(s||'').trim();if(/^\d{6}$/.test(t)){const y=t.slice(0,4),m=+t.slice(4);return m>=1&&m<=12?y+'-'+String(m).padStart(2,'0'):'';}const d=/^\d{8}$/.test(t)?t.slice(0,4)+'-'+t.slice(4,6)+'-'+t.slice(6,8):t.split(/[T ]/)[0];const x=temporal52A(d);return x?x.slice(0,10):'';}
function parseLhDetail(html,r){
 if(!html.includes('id="panId"')||!html.includes(r.number))throw Error('PARSE: LH 상세 식별자/본문 없음');
 const d={_parserVersion:'LH52A2',id:r.id,url:r.url,complexes:[],units:[],attachments:[],begin:'',end:'',winner:'',move:'',address:'',building:'원문 확인 필요',qualification:'원문 확인 필요',price:'원문 확인 필요',monthly:'원문 확인 필요'};
 const h=cleanHtml(html);
 for(const m of h.matchAll(/<a\b[^>]*href="javascript:fileDownLoad\('([^']+)'\);?"[^>]*>([\s\S]*?)<\/a>/gi)){
  if(!d.attachments.some(a=>a.fileId===m[1]))d.attachments.push({fileId:m[1],name:textOf(m[2]),url:'https://apply.lh.or.kr/lhapply/lhFile.do?fileid='+encodeURIComponent(m[1])});
 }
 const sections=h.split(/<div\b[^>]*id="wrtancSbdTab\d+"[^>]*>/i).slice(1);
 for(const section of sections){
  const name=textOf((section.match(/<h4\b[^>]*class="tit2"[^>]*>([\s\S]*?)<\/h4>/i)||[])[1]||'');
  const address=(section.match(/<li\b[^>]*>\s*소재지\s*:?([\s\S]*?)<\/li>/i)||[])[1];
  if(name)d.complexes.push(name);if(address)d.address+=(d.address?'; ':'')+textOf(address).replace(/^:\s*/,'');
  for(const tm of section.matchAll(/<table\b[^>]*>[\s\S]*?<\/table>/gi)){
   const cap=textOf((tm[0].match(/<caption[^>]*>([\s\S]*?)<\/caption>/i)||[])[1]||'');
   if(!/주택형 안내/.test(cap))continue;
   const rows=tableGrid(tm[0]),hi=rows.findIndex(x=>x.some(v=>/전용면적/.test(v))&&x.some(v=>/금회공급/.test(v)));
   if(hi<0)continue;const heads=rows[hi],ai=heads.findIndex(v=>/전용면적/.test(v)),ni=heads.findIndex(v=>/금회공급/.test(v));
   for(const row of rows.slice(hi+1)){const area=Number(row[ai]),ct=String(row[ni]||'').replace(/,/g,'');if(!area||area>1000)continue;
    d.units.push({complex:name,type:row[0],area,count:/^\d+$/.test(ct)?Number(ct):'원문 확인 필요',deposit:'원문 확인 필요',monthly:'원문 확인 필요',evidence:row.join(' | ')});
   }
  }
 }
 // Embedded static schedule data is parsed as text; never execute website JavaScript.
 for(const [field,key,mode] of [['begin','sbscAcpStDt','min'],['end','sbscAcpClsgDt','max'],['winner','pzwrAncDt','min']]){
  const vals=[...html.matchAll(new RegExp(key+"\\s*:\\s*['\"]([0-9.\\/-]{8,10})['\"]",'g'))].map(x=>dateClean(x[1])).filter(x=>/^\d{4}-\d{2}-\d{2}$/.test(x)).sort();
  d[field]=vals.length?vals[mode==='min'?0:vals.length-1]:'';
 }
 const original=(html.match(/var\s+sOtxtPanId\s*=\s*'([^']+)'/)||[])[1];d.related=original&&original!==r.number?'LH:'+r.id.split(':')[1]+':'+original:'';
 d.min=d.units.length?Math.min(...d.units.map(u=>u.area)):'';d.max=d.units.length?Math.max(...d.units.map(u=>u.area)):'';
 d.count=d.units.length&&d.units.every(u=>typeof u.count==='number')?d.units.reduce((a,u)=>a+u.count,0):'';
 // A title alone is insufficient to establish building type for leases.
 if(/아파트/.test(r.type+' '+r.title))d.building='아파트';
 d.status=d.units.length?'상세 HTML 주택형 확인·첨부/자격 원문 확인 필요':'상세 HTML 확인·주택형/첨부 원문 확인 필요';
 return d;
}
function parseFirstCome(html,branch){
 const m=html.match(/data-id=['"]totalCoComma['"]>\s*([\d,]+)/);if(!m)throw Error('PARSE: 선착순 총건수 표식 없음');
 const total=Number(m[1].replace(/,/g,''));if(!total)return {total,rows:[]};
 const t=(html.match(/<table\b[^>]*>[\s\S]*?<\/table>/gi)||[]).find(t=>/선착순계약가능지구/.test(t)&&/총세대수/.test(t));if(!t)throw Error('PARSE: 선착순 표 없음');
 const body=(cleanHtml(t).match(/<tbody[^>]*>([\s\S]*?)<\/tbody>/i)||[])[1]||'';const rows=tableGrid(body);
 if(rows.length!==total||rows.some(r=>r.length!==10))throw Error('PARTIAL: 선착순 표시건수/표 열 불일치');
 return {total,rows:rows.map(r=>({branch,region:r[0],district:r[1],block:r[2],complexCount:r[3],area:r[4],unsold:r[5],priceThousand:r[6],contact:r[7],note:r[9]}))};
}
function importantV2(r,d){const m=Array(40).fill('');m[0]=r.id||'';m[5]=r.title||'';m[8]=r.region||'';const geo=regionV4(m,d);if(!geo.eligible)return ['',''];if(geo.group==='지역 확인 필요')return ['검토 필요','공급 소재지 확인 대기·기본 발견/기록 보존'];if(d&&(d.complexes||[]).length===1&&d.building==='아파트'&&typeof d.max==='number'&&d.max>=59)return ['★중요★','공급 소재지 서울·경기 확인; 아파트·최대59㎡ 이상·신청자격 별도'];return ['검토 필요','서울·경기 전역 기본 대상·면적/건물/자격은 추가 확인'];}

// Verified against official ODcloud Swagger stage 37000, saved with evidence.
function collectApplyModels(r,key,fetcher){
 if(!key)throw Error('청약홈 인증키 미설정');
 const endpoint=r.source.replace(/Detail$/,'Mdl'),raw=JSON.parse(r.raw),all=[];let total=null;
 for(let page=1;page<=100;page++){
  const url='https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/'+endpoint+'?'+qs({page,perPage:100,serviceKey:key,'cond[HOUSE_MANAGE_NO::EQ]':raw.HOUSE_MANAGE_NO,'cond[PBLANC_NO::EQ]':raw.PBLANC_NO});
  const j=JSON.parse(fetcher(url));if(!Array.isArray(j.data)||!Number.isInteger(j.matchCount)||j.currentCount!==j.data.length)throw Error('PARSE: 청약홈 주택형 스키마');
  if(total===null)total=j.matchCount;if(total!==j.matchCount)throw Error('PARTIAL: 주택형 총건수 변경');all.push(...j.data);
  if(all.length>=total){if(all.length!==total||new Set(all.map(u=>u.MODEL_NO)).size!==total)throw Error('PARTIAL: 주택형 중복/누락');break;}if(!j.data.length||page===100)throw Error('PARTIAL: 주택형 페이지 누락');
 }
 const units=all.map(u=>{const val=u.LTTOT_TOP_AMOUNT??u.SUPLY_AMOUNT,number=String(val??'').replace(/,/g,'');return {complex:r.title,type:u.HOUSE_TY||u.TP||u.MODEL_NO,area:u.EXCLUSE_AR&&Number(u.EXCLUSE_AR)>0?Number(u.EXCLUSE_AR):'',count:Number.isInteger(u.SUPLY_HSHLDCO)?u.SUPLY_HSHLDCO+Number(u.SPSPLY_HSHLDCO||0):'원문 확인 필요',deposit:/^\d+(\.\d+)?$/.test(number)?Number(number)*10000:'원문 확인 필요',monthly:'원문 확인 필요',evidence:JSON.stringify(u)};});
 // SUPLY_AR is supply area, not exclusive. HOUSE_TY is left as source text.
 const areas=units.map(u=>u.area).filter(a=>typeof a==='number');
 return {_parserVersion:2,id:r.id,url:r.url,complexes:[r.title],units,attachments:[],begin:r.begin,end:r.end,winner:r.winner,move:r.move,address:r.address,building:/APT|Remndr|OPT/.test(r.source)?'아파트':'원문 확인 필요',qualification:'원문 확인 필요',price:'주택형상세 참조·만원을 원으로 환산',monthly:'원문 확인 필요',min:areas.length?Math.min(...areas):'',max:areas.length?Math.max(...areas):'',count:r.count,status:'공식 API 주택형 확인·공급면적을 전용면적으로 대입하지 않음·첨부/자격 원문 확인 필요'};
}

function normalizeApply(raw,endpoint){const r=v1NormalizeApply(raw,endpoint);r.published=dateClean(raw.RCRIT_PBLANC_DE);r.begin=dateClean(raw.RCEPT_BGNDE||raw.SUBSCRPT_RCEPT_BGNDE||raw.GNRL_RCEPT_BGNDE||'');r.end=dateClean(raw.RCEPT_ENDDE||raw.SUBSCRPT_RCEPT_ENDDE||raw.GNRL_RCEPT_ENDDE||'');r.winner=dateClean(raw.PRZWNER_PRESNATN_DE);r.move=dateClean(raw.MVN_PREARNGE_YM);if(!r.published)throw Error('PARSE: Applyhome invalid publication date');return r;}

const V2_TABLES={
 '공고상세':['공고ID','상세해시','확인시각(KST)','상세주소','단지명','건물유형','금회전용최소','금회전용최대','금회공급수','접수시작','접수마감','당첨발표','입주예정','자격','검증상태','근거URL','정규화JSON','2차 중요표시','2차 판단근거'],
 '주택형상세':['주택형키','공고ID','확인시각','단지명','주택형','전용면적㎡','금회공급수','보증금/가격원','월임대료원','근거행','공식URL'],
 '첨부파일':['첨부키','공고ID','파일ID','파일명','공식URL','SHA256','마지막시도','마지막정상','분석상태','본문발췌','변경횟수','발견시각'],
 '수의계약점검':['공급행키','확인시각','메뉴','지역','지구명','블록','전용면적㎡','미분양호수','가격천원','문의처','비고','근거URL','주의'],
 '수집감시':['수집경로','최근시도','마지막정상','수집결과','경과시간','감시판정'],
 '상세작업':['공고ID','상태','마지막시도','마지막정상','오류','다음재시도']
};
function supportV2(ss){
 ensureSupport(ss);
 for(const name of Object.keys(V2_TABLES)){let s=ss.getSheetByName(name);if(!s){s=ss.insertSheet(name);s.getRange(1,1,1,V2_TABLES[name].length).setValues([V2_TABLES[name]]);s.setFrozenRows(1);}else if(s.getRange(1,1).getValue()!==V2_TABLES[name][0])throw Error('PARSE: 확장시트 헤더 충돌 '+name);}
 const q=ss.getSheetByName('발송대기');q.getRange(1,8,1,3).setValues([['적재구분','발송허용','차단사유']]);
 if(q.getLastRow()>1){const rows=q.getRange(2,1,q.getLastRow()-1,10).getValues();for(let i=0;i<rows.length;i++)if(!rows[i][7])q.getRange(i+2,8,1,3).setValues([['초기적재/이전 미분류','N','과거 적재분 자동발송 차단']]);}
}
function planUpsert35V4(existing,records,now,hashFn,context){
 const olds=new Map(existing.map(r=>[r[0],r])),snapshots=context&&context.snapshots||(typeof SpreadsheetApp==='undefined'?[]:SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName('수집원본').getDataRange().getValues()),snapMap=new Map(snapshots.map(r=>[r[0],r]));let sameSH=0;
 const effective=records.filter(r=>{if(!String(r.id).startsWith('SH:'))return true;const old=olds.get(r.id),snap=old&&snapMap.get(old[38]);if(!snap)return true;try{const before=JSON.parse(snap[5]),after=JSON.parse(r.raw),official=x=>JSON.stringify([String(x.seq),x.title,x.published,x.department||'']);if(official(before)===official(after)){sameSH++;return false;}}catch(e){}return true;});
 const p=v1PlanUpsert(existing,effective,now,hashFn);p.unchanged+=sameSH;
 for(const w of p.writes){const old=olds.get(w.row[0]);if(old){
  // Listing refresh owns these columns only. All detail/user columns remain intact.
  const owned=new Set([2,5,7,25,26,28,29,33,34,35,36,37,38]);
  for(let i=0;i<40;i++)if(!owned.has(i))w.row[i]=old[i];
  const snap=snapMap.get(old[38]);let expected={};if(snap){try{const raw=JSON.parse(snap[5]);if(String(old[0]).startsWith('SH:')){const sh=normalizeSH(raw,old[33]);expected={2:sh.published,5:sh.title,25:sh.status,26:sh.url};}else if(String(old[0]).startsWith('GH:')){const gh=normalizeGHV4(raw,{kind:String(old[0]).startsWith('GH:WEB:')?'web':String(old[0]).startsWith('GH:NOTICE:')?'notice':'apply',id:old[33]});expected={2:gh.published,5:gh.title,25:gh.status,26:gh.url};}else if(raw.td){expected={2:raw.td[5].replace(/\./g,'-'),5:raw.td[2],25:raw.td[7],26:snap[3]};}else{const a=normalizeApply(raw,old[33]);expected={2:a.published,5:a.title,25:a.status,26:a.url};}}catch(e){}}for(const i of [2,5,25,26])if(old[i]!==''&&(expected[i]===undefined||!sameCell52A(expected[i],old[i])))w.row[i]=old[i];if(old[7]&&!['신규','정정공고','추가모집','변경 감지'].includes(old[7]))w.row[7]=old[7];
 }else{const r=records.find(r=>r.id===w.row[0]),imp=importantV2(r,null);w.row[21]=imp[0];w.row[22]=imp[1];}}
 finalizeHistory41(p,existing);
 return p;
}
function activeUrl(kind,page,to){return lhUrl(kind,page,to).replace('panSs=','panSs='+encodeURIComponent('공고중')).replace('startDt='+INITIAL_FROM,'startDt=2000-01-01');}
function collectActive(kind,to){let rows=[],total=null,previous='';for(let p=1;p<=100;p++){
 const req=p===1?null:lhPagingRequest42A3(previous,p);
 if(req&&(req.options.payload.panSs!=='공고중'||req.options.payload.startDt!=='2000-01-01'||req.options.payload.endDt!==to))throw Error('PARSE: LH 공고중 POST 필터 불일치');
 const h=p===1?fetchText(activeUrl(kind,1,to)):fetchText(req.url,req.options);previous=h;
 if(!h.includes('value="2000-01-01"')||!h.includes('value="'+to+'"')||!/<option value="공고중"\s+selected/.test(h)||p>1&&!new RegExp('name=["\']currPage["\']\\s+value=["\']'+p+'["\']').test(h))throw Error('PARSE: 공고중 기간/상태/페이지 미반영');
 const x=parseLh(h,kind);if(total===null)total=x.total;if(total!==x.total)throw Error('PARTIAL: 수집중 건수변경');rows.push(...x.records);
 if(rows.length>=total){if(rows.length!==total||new Set(rows.map(r=>r.id)).size!==total)throw Error('PARTIAL: 공고중 ID/건수 불일치');return rows;}if(!x.records.length)throw Error('PARTIAL: 중간페이지 비어있음');}throw Error('PARTIAL: 페이지 상한');}
function legacyClassify35(e){const t=safeError(e);return /인증키 미설정/.test(t)?'인증키 미설정':/HTTP (401|403)/.test(t)?'API 인증/접근 오류':/PARSE|구조|파싱|스키마|표식|필터|식별자/.test(t)?'파싱 오류':/PARTIAL|불일치|누락|중간|상한|예산|총건수 변경/.test(t)?'일부 누락 가능':/시간|timed|Timeout/i.test(t)?'시간 초과':'공식사이트/저장 접근 실패';}
function sourceAttempt(ss,src,to){const s=ss.getSheetByName('수집상태'),rows=s.getDataRange().getValues();let at=rows.findIndex(r=>r[0]===src.id);if(at<1)at=rows.length;const old=rows[at]||[];s.getRange(at+1,1,1,10).setValues([[src.id,nowKst(),'시도중',old[3]||'',src.from||INITIAL_FROM,to,'',old[7]||0,old[8]||0,'실행중단 시 정상으로 처리하지 않음']]);SpreadsheetApp.flush();}
function v2SourceFinish(ss,src,records,error,to){
 saveResult(ss,src,records,error,to);
 const s=ss.getSheetByName('수집상태'),rows=s.getDataRange().getValues(),at=rows.findIndex(r=>r[0]===src.id);
 const log=ss.getSheetByName('기관점검'),newCount=log.getRange(log.getLastRow(),11).getValue();
 s.getRange(at+1,3).setValue(error?classifyError(error):newCount?'정상·신규 발견':'정상·신규 0건');s.getRange(at+1,5).setValue(src.from||INITIAL_FROM);
 const q=ss.getSheetByName('발송대기');if(q.getLastRow()>1){const a=q.getRange(2,1,q.getLastRow()-1,10).getValues(),base=PropertiesService.getScriptProperties().getProperty('BASELINE_'+src.id);
  const ids=new Map(records.map(r=>[r.id,r]));for(let i=0;i<a.length;i++)if(!a[i][7]&&ids.has(a[i][1])){
   const r=ids.get(a[i][1]),live=!!base&&(a[i][3]==='변경'||r.published>=base);const kind=live?(a[i][3]==='변경'?'정정/변경':'실시간신규'):'초기/과거백필';q.getRange(i+2,8,1,3).setValues([[kind,live?'Y':'N',live?'외부발송 미연결':'초기적재 또는 과거공고 자동발송 차단']]);}
 }
 if(!error)PropertiesService.getScriptProperties().setProperty('BASELINE_'+src.id,to);
}
function upsertTable35V4(s,rows,keycol=0){if(!rows.length)return;const attachment=s.getName()==='첨부파일';if(attachment&&s.getMaxColumns()<19)s.insertColumnsAfter(s.getMaxColumns(),19-s.getMaxColumns());
 const old=s.getDataRange().getValues();unique52A(old.slice(s.getName()==='정정이력'?4:1).map(r=>[r[keycol]]),'upsert '+s.getName());const prior=new Map(old.map(r=>[String(r[keycol]),r]));const last=new Map();for(const r of rows)last.set(String(r[keycol]),r);rows=[...last.values()].map(r=>attachment?Array.from({length:19},(_,i)=>r[i]!==undefined?r[i]:(prior.get(String(r[keycol]))||[])[i]??''):r);const ix=new Map(old.slice(1).map((r,i)=>[String(r[keycol]),i+2]));const fresh=[];for(const r of rows){const at=ix.get(String(r[keycol]));if(at)s.getRange(at,1,1,r.length).setValues([r.map(v=>typeof v==='string'&&/^[=+@-]/.test(v)?"'"+v:v)]);else fresh.push(r);}if(fresh.length){const at=s.getLastRow()+1,need=at+fresh.length-1;if(need>s.getMaxRows())s.insertRowsAfter(s.getMaxRows(),need-s.getMaxRows());s.getRange(at,1,fresh.length,fresh[0].length).setValues(fresh.map(r=>r.map(v=>typeof v==='string'&&/^[=+@]/.test(v)?"'"+v:v)));if(s.getName()==='주택형상세')s.getRange(at,12,fresh.length,1).setFormulas(fresh.map((r,i)=>[unitVersionFormula(at+i)]));}}
function saveDetail(ss,r,d){
 const now=nowKst(),hash=digest(JSON.stringify(d)),s=ss.getSheetByName('공고상세'),previous=s.getDataRange().getValues().find(x=>x[0]===r.id);
 const snap=r.id+':DETAIL:'+hash;

 upsertTable(s,[[r.id,hash,now,d.address,d.complexes.join('; '),d.building,d.min,d.max,d.count,d.begin,d.end,d.winner,'원문 확인 필요',d.qualification,d.status,r.url,JSON.stringify(d),...importantV2(r,d)]]);
 upsertTable(ss.getSheetByName('주택형상세'),d.units.map((u,i)=>[r.id+':'+hash+':'+i,r.id,now,u.complex,u.type,u.area,u.count,u.deposit,u.monthly,u.evidence,r.url]));
 const aSheet=ss.getSheetByName('첨부파일'),as=aSheet.getDataRange().getValues();upsertTable(aSheet,d.attachments.filter(a=>!as.some(x=>x[0]===r.id+':'+a.fileId)).map(a=>[r.id+':'+a.fileId,r.id,a.fileId,a.name,a.url,'','','','미취득: 원문 확인 필요','','0',now]));
 const master=ss.getSheetByName('공고원장'),rows=safeMasterRows52A(master,40),at=rows.findIndex(x=>x[0]===r.id);if(at<0)return;const row=rows[at];const formulas=master.getRange(at+5,1,1,40).getFormulas()[0];
 const vals={10:d.complexes.join('; '),11:d.building,12:d.min,13:d.max,14:d.count,17:d.begin,18:d.end,19:d.winner,27:d.status,39:d.related||''};
 // Only blanks, placeholders or last machine-written values can be replaced.
 const oldD=previous?JSON.parse(previous[16]||'{}'):null,oldVals=oldD?{10:(oldD.complexes||[]).join('; '),11:oldD.building,12:oldD.min,13:oldD.max,14:oldD.count,17:oldD.begin,18:oldD.end,19:oldD.winner,27:oldD.status,39:oldD.related||''}:{};
 for(const k of Object.keys(vals)){const i=Number(k),v=vals[k],current=row[i];const placeholder=typeof current==='string'&&/^(?:원문 확인 필요|미확인|확인 필요|상세 미생성)$/.test(current.trim());if(v!==''&&v!=null&&!formulas[i]&&(current===''||current==null||placeholder||oldVals[i]!==undefined&&sameCell52A(current,oldVals[i]))&&!sameCell52A(current,v))master.getRange(at+5,i+1).setValue(safeText52A(v));}
 // Existing importance/user fields are preserved. The evidence-based v2 assessment is in 공고상세 R:S.
 const imp=importantV2(r,d);if(master.getRange(at+5,22,1,2).isBlank())master.getRange(at+5,22,1,2).setValues([imp]);
 detailJob52A(ss,r.id);upsertTable(ss.getSheetByName('상세작업'),[[r.id,/^(LH|SH):/.test(String(r.id))?'정상·HTML만':'정상·API주택형',now,now,'','']]);
 SpreadsheetApp.flush();finalizeDetailEvent42A(ss,r,previous,d,hash);
}
function processDetailJobs35V4(ss,start){
 const master=ss.getSheetByName('공고원장'),rows=safeMasterRows52A(master,40).filter(r=>r[0]);if(!rows.length)return;
 const dueJobs=new Map(ss.getSheetByName('상세작업').getDataRange().getValues().slice(1).map(r=>[r[0],r[5]])),due=id=>!dueJobs.get(id)||!/^\d{4}-/.test(String(dueJobs.get(id)))||stampV3(dueJobs.get(id))<=nowKst();const props=PropertiesService.getScriptProperties();let cursor=Number(props.getProperty('DETAIL_CURSOR')||0)%rows.length;const known=new Set(ss.getSheetByName('공고상세').getDataRange().getValues().slice(1).map(r=>r[0])),pending=rows.filter(r=>!known.has(r[0])&&due(r[0])).sort((a,b)=>stampV3(b[1]).localeCompare(stampV3(a[1])));
 for(let i=0;i<8&&Date.now()-start<210000;i++){
  const urgent=i<4&&pending.length>0,row=urgent?pending.shift():rows[cursor],r={id:row[0],number:String(row[34]),title:row[5],type:row[11],region:row[8],url:row[26],published:row[2]},now=nowKst();
  if(!due(r.id)){if(!urgent)cursor=(cursor+1)%rows.length;continue;}
  detailAttempt(ss,r.id);try{let d;if(String(r.id).startsWith('SH:'))d=parseSHDetail(fetchText(r.url),r);else if(String(r.id).startsWith('LH:'))d=parseLhDetail(fetchText(r.url),r);else {const key=props.getProperty('APPLYHOME_SERVICE_KEY'),snap=ss.getSheetByName('수집원본').getDataRange().getValues().find(x=>x[0]===row[38]);if(!snap)throw Error('PARSE: 청약홈 원본 없음');r.raw=snap[5];r.source=row[33];const api=normalizeApply(JSON.parse(r.raw),r.source);d=collectApplyModels(api,key,fetchText);}saveDetail(ss,r,d);if(String(r.id).startsWith('SH:'))saveSHAttachments(ss,r,d);detailRecovered(ss,r.id);}catch(e){const s=ss.getSheetByName('상세작업'),old=s.getDataRange().getValues().find(x=>x[0]===r.id);upsertTable(s,[[r.id,classifyError(e),now,old?old[3]:'',safeError(e),'다음 순환 재시도']]);detailFailed(ss,r.id,e);}
  if(!urgent)cursor=(cursor+1)%rows.length;props.setProperty('DETAIL_CURSOR',String(cursor));
 }
}
function processAttachment35V4(ss,claimed=false){
 const s=ss.getSheetByName('첨부파일'),rows=s.getDataRange().getValues().slice(1);if(!rows.length)return;const props=PropertiesService.getScriptProperties();let cursor=Number(props.getProperty('ATTACH_CURSOR')||0)%rows.length,r=rows[cursor].slice(),now=nowKst();const eligible=x=>x[17]!=='별도처리'&&leaseDue52A(x[15],Date.now());const urgent=rows.filter(x=>eligible(x)&&!x[5]&&x[11]).sort((a,b)=>String(b[11]).localeCompare(String(a[11])))[0];if(urgent)r=urgent.slice();if(!eligible(r)){const next=rows.find(eligible);if(!next)return;r=next.slice();}while(r.length<19)r.push('');r[12]=Number(r[12]||0)+1;r[6]=now;
 if(!claimed){const lease=r.slice();lease[15]=Utilities.formatDate(new Date(Date.now()+6*3600000),'Asia/Seoul','yyyy-MM-dd HH:mm:ss');lease[8]='시도중·중단시 지연 재시도';upsertTable(s,[lease]);SpreadsheetApp.flush();}
 try{const res=UrlFetchApp.fetch(r[4],{muteHttpExceptions:true});if(res.getResponseCode()!==200)throw Error('HTTP '+res.getResponseCode());const blob=res.getBlob(),bytes=blob.getBytes();if(bytes.length>12000000)throw Error('첨부 12MB 초과: 별도분석 필요');if(/\.pdf$/i.test(r[3])&&String.fromCharCode(...bytes.slice(0,5))!=='%PDF-')throw Error('PARSE: PDF 대신 HTML/오류 응답');const hash=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,bytes).map(b=>('0'+((b+256)%256).toString(16)).slice(-2)).join('');
 if(r[5]&&r[5]!==hash){r[10]=Number(r[10]||0)+1;upsertTable(ss.getSheetByName('정정이력'),[[r[1],now,'','첨부 바이너리 변경',r[3],r[5],hash,'원문 재확인',r[4],'파일ID 동일·내용변경',r[0]+':'+hash]],10);upsertTable(ss.getSheetByName('발송대기'),[[r[0]+':'+hash,r[1],now,'첨부변경','미발송','파일 바이너리 변경·원문 재확인',r[4],'정정/변경','Y','외부발송 미연결']]);}
 r[5]=hash;r[7]=now;r[8]='해시 확인·PDF/HWP 내용 원문 확인 필요';
 if(/\.hwpx$/i.test(r[3])){const text=Utilities.unzip(blob.setContentType('application/zip')).filter(b=>/^Contents\/section\d+\.xml$/.test(b.getName())).map(b=>[...b.getDataAsString('UTF-8').matchAll(/<(?:\w+:)?t\b[^>]*>([\s\S]*?)<\/(?:\w+:)?t>/g)].map(m=>textOf(m[1])).join(' ')).join('\n');r[8]='HWPX 텍스트 추출·조건/표 구조 원문 확인 필요';r[9]=text.slice(0,20000);}
 r[14]=0;r[15]='';}catch(e){r[8]=classifyError(e)+': '+safeError(e);r[13]=Number(r[13]||0)+1;r[14]=Number(r[14]||0)+1;r[15]=Utilities.formatDate(new Date(Date.now()+retryDelayV2(r[14])*60000),'Asia/Seoul','yyyy-MM-dd HH:mm:ss');ss.getSheetByName('처리오류이력').appendRow([now,'첨부',r[0],r[14]>=3?'재시도 누적실패':'실패',r[14],r[15],safeError(e)]);}upsertTable(s,[r]);props.setProperty('ATTACH_CURSOR',String((cursor+1)%rows.length));
}
function legacyMonitor35(ss){
 const rows=ss.getSheetByName('수집상태').getDataRange().getValues().slice(1),s=ss.getSheetByName('수집감시');
 rows.forEach((r,i)=>{const n=i+2;s.getRange(n,1,1,6).setValues([[r[0],r[1],r[3],r[2],'=IF(C'+n+'="","",(NOW()-VALUE(C'+n+'))*24)','=IF(C'+n+'="","정상수집 이력 없음",IF(E'+n+'>3,"경고: 3시간 이상 정상수집 없음",IF(D'+n+'="시도중","실행중/중단 여부 확인",D'+n+')))']]);});
 ss.setRecalculationInterval(SpreadsheetApp.RecalculationInterval.MINUTE);
 ss.getSheetByName('대시보드').getRange('B8').setValue('부분 수집: LH·청약홈5종 목록 / 상세·첨부 순환점검·타기관 미수집; 수집감시 확인');refreshDashboard(ss);
}
function v2RunCollection(){
 const lock=LockService.getScriptLock();if(!lock.tryLock(1000))return;const start=Date.now();
 try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID);supportV2(ss);const to=todayKst(),key=PropertiesService.getScriptProperties().getProperty('APPLYHOME_SERVICE_KEY');
 const sources=['lease','sale'].flatMap(k=>[{id:'LH_'+k,agency:'LH청약플러스',label:k+' 최근 전체상태',url:lhUrl(k,1,to),run:()=>collectLh(k,to,fetchText)},{id:'LH_'+k+'_active',agency:'LH청약플러스',label:k+' 공고중(정정/접수중 포함)',from:'2000-01-01',url:activeUrl(k,1,to),run:()=>collectActive(k,to)}]).concat(APPLY_ENDPOINTS.map(e=>({id:e,agency:'청약홈',label:e,url:'https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/'+e,run:()=>collectApply(e,to,key,fetchText)})));
 for(const src of sources){sourceAttempt(ss,src,to);try{if(Date.now()-start>180000)throw Error('PARTIAL: 실행 예산 초과·다음 시간 재시도');sourceFinish(ss,src,src.run(),null,to);}catch(e){sourceFinish(ss,src,[],safeError(e),to);}}
 for(const branch of [1,2,5]){const url='https://apply.lh.or.kr/lhapply/apply/bor_ctrt_psb_dst/'+branch+'/lfn_getTabChange.do?mi='+({1:'201526',2:'201529',5:'1201802'})[branch],src={id:'LH_FIRSTCOME_'+branch,agency:'LH청약플러스',label:'수의계약 '+branch,url};sourceAttempt(ss,src,to);try{
  if(Date.now()-start>200000)throw Error('PARTIAL: 실행 예산 초과');const p=parseFirstCome(fetchText(url),branch),now=nowKst();upsertTable(ss.getSheetByName('수의계약점검'),p.rows.map((r,i)=>[branch+':'+i,now,branch,r.region,r.district,r.block,r.area,r.unsold,r.priceThousand,r.contact,r.note,url,'재고표시 행: 별도 공고ID/모집 유효성 미확인']));sourceFinish(ss,src,[],null,to);const st=ss.getSheetByName('수집상태'),a=st.getDataRange().getValues().findIndex(r=>r[0]===src.id);st.getRange(a+1,7).setValue(p.total);
 }catch(e){sourceFinish(ss,src,[],safeError(e),to);}}
 processDetailJobs(ss,start-70000);for(let n=0;n<2&&Date.now()-start<150000;n++)processAttachmentJob(ss);refreshMonitor(ss);
 }finally{lock.releaseLock();}
}
function verifyV2(){const ss=SpreadsheetApp.openById(SPREADSHEET_ID);supportV2(ss);refreshMonitor(ss);const ids=safeMasterRows52A(ss.getSheetByName('공고원장'),1).flat().filter(Boolean);console.log(JSON.stringify({master:ids.length,unique:new Set(ids).size,triggers:ScriptApp.getProjectTriggers().map(t=>t.getHandlerFunction()),detailCursor:PropertiesService.getScriptProperties().getProperty('DETAIL_CURSOR'),keyConfigured:!!PropertiesService.getScriptProperties().getProperty('APPLYHOME_SERVICE_KEY')}));}

function extendV2Assessment(){const ss=SpreadsheetApp.openById(SPREADSHEET_ID),s=ss.getSheetByName('공고상세');if(s.getRange(1,18,1,2).isBlank())s.getRange(1,18,1,2).setValues([['2차 중요표시','2차 판단근거']]);const a=ss.getSheetByName('첨부파일');if(a.getRange(1,12).isBlank())a.getRange(1,12).setValue('발견시각');}
function fillDetailBlanks(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))return;try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID),s=ss.getSheetByName('공고상세'),details=s.getDataRange().getValues().slice(1),master=ss.getSheetByName('공고원장'),ids=safeMasterRows52A(master,1).flat(),props=PropertiesService.getScriptProperties();const start=Date.now();let cursor=Number(props.getProperty('FILL_CURSOR')||0);for(;cursor<details.length&&Date.now()-start<180000;cursor++){const d=JSON.parse(details[cursor][16]||'{}'),at=ids.indexOf(d.id);if(at<0)continue;for(const [i,v] of [[12,d.min],[13,d.max],[14,d.count],[17,d.begin],[18,d.end],[19,d.winner],[39,d.related]]){if(v!==''&&v!=null){const c=master.getRange(at+5,i+1);if(c.isBlank())c.setValue(v);}}props.setProperty('FILL_CURSOR',String(cursor+1));}console.log('상세 빈칸 보완 '+cursor+'/'+details.length);}finally{lock.releaseLock();}}

function activateV2(){extendV2Assessment();fillDetailBlanks();if(!ScriptApp.getProjectTriggers().some(t=>t.getHandlerFunction()==='verifyTimerOnce'))startTimerVerification();verifyV2();}
function diagnoseApplyhome(){
 const ss=SpreadsheetApp.openById(SPREADSHEET_ID),key=PropertiesService.getScriptProperties().getProperty('APPLYHOME_SERVICE_KEY');let s=ss.getSheetByName('API검증');if(!s){s=ss.insertSheet('API검증');s.appendRow(['경로','확인시각','전체건수','필터건수','응답건수','공고ID','게시일','공고명','원천JSON','상태']);}
 for(const endpoint of APPLY_ENDPOINTS){try{const base='https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/'+endpoint,first=JSON.parse(fetchText(base+'?'+qs({page:1,perPage:1,serviceKey:key})));if(!Array.isArray(first.data)||!Number.isInteger(first.totalCount))throw Error('PARSE: 진단 응답 스키마');const page=Math.max(1,Math.ceil(first.totalCount/100)),last=page===1?first:JSON.parse(fetchText(base+'?'+qs({page,perPage:100,serviceKey:key})));const samples=first.data.concat(last.data).filter((r,i,a)=>a.findIndex(x=>x.PBLANC_NO===r.PBLANC_NO&&x.HOUSE_MANAGE_NO===r.HOUSE_MANAGE_NO)===i).sort((a,b)=>String(b.RCRIT_PBLANC_DE).localeCompare(String(a.RCRIT_PBLANC_DE))).slice(0,3);if(!samples.length)s.appendRow([endpoint,nowKst(),first.totalCount,first.matchCount,first.currentCount,'','','','','전체 응답도 0건·실공고 미검증']);for(const raw of samples){const r=normalizeApply(raw,endpoint);upsertTable(s,[[endpoint+':'+r.id,nowKst(),first.totalCount,first.matchCount,first.currentCount,r.id,r.published,r.title,JSON.stringify(raw),'앞/뒤 페이지 표본: 전체 최신성 보증 아님']]);}}
 catch(e){s.appendRow([endpoint,nowKst(),'','','','','','','',classifyError(e)+':'+safeError(e)]);}}
}

function verifyApplyhomeLive(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))return;try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID),props=PropertiesService.getScriptProperties(),key=props.getProperty('APPLYHOME_SERVICE_KEY'),to=todayKst();if(!props.getProperty('APPLY_V2_FORMAT_MIGRATED')){for(const e of APPLY_ENDPOINTS)props.deleteProperty('BASELINE_'+e);props.setProperty('APPLY_V2_FORMAT_MIGRATED','true');}for(const e of APPLY_ENDPOINTS){const src={id:e,agency:'청약홈',label:e+' 실제 YYYYMMDD 검증',url:'https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/'+e};sourceAttempt(ss,src,to);try{sourceFinish(ss,src,collectApply(e,to,key,fetchText),null,to);}catch(err){sourceFinish(ss,src,[],safeError(err),to);}}processDetailJobs(ss,Date.now()-170000);refreshMonitor(ss);}finally{lock.releaseLock();}}

function diagnoseApplyFormats(){const ss=SpreadsheetApp.openById(SPREADSHEET_ID),s=ss.getSheetByName('API검증'),key=PropertiesService.getScriptProperties().getProperty('APPLYHOME_SERVICE_KEY');for(const e of APPLY_ENDPOINTS){try{const j=JSON.parse(fetchText('https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/'+e+'?'+qs({page:1,perPage:1,serviceKey:key})));const raw=j.data&&j.data[0];upsertTable(s,[[e+':FORMAT',nowKst(),j.totalCount,j.matchCount,j.currentCount,raw?raw.PBLANC_NO:'',raw?raw.RCRIT_PBLANC_DE:'',raw?raw.HOUSE_NM:'',raw?JSON.stringify(raw):'','perPage1 공식 날짜 표본']]);}catch(err){upsertTable(s,[[e+':FORMAT',nowKst(),'','','','','','','',safeError(err)]]);}}}
function verifyAllModels(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 수집 실행중·검증 재시도 필요');try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID),key=PropertiesService.getScriptProperties().getProperty('APPLYHOME_SERVICE_KEY'),log=ss.getSheetByName('개발검증');for(const e of APPLY_ENDPOINTS){try{const j=JSON.parse(fetchText('https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/'+e+'?'+qs({page:1,perPage:1,serviceKey:key})));if(!j.data||!j.data.length)throw Error('실제 표본 없음');const r=normalizeApply(j.data[0],e),d=collectApplyModels(r,key,fetchText);saveDetail(ss,r,d);log.appendRow(['실제 API 주택형 '+e.replace(/Detail$/,'Mdl'),'통과',nowKst()+' | '+r.id+' | '+d.units.length+'행 | 공급면적은 전용면적으로 대입하지 않음']);}catch(err){log.appendRow(['실제 API 주택형 '+e.replace(/Detail$/,'Mdl'),'실패',nowKst()+' | '+safeError(err)]);}}}finally{lock.releaseLock();}}
function finishPhase2Validation(){verifyApplyhomeLive();verifyAllModels();if(!ScriptApp.getProjectTriggers().some(t=>t.getHandlerFunction()==='verifyTimerOnce'))startTimerVerification();verifyV2();}

function unitVersionFormula(row){return `=IFERROR(IF(REGEXEXTRACT(A${row},":([0-9a-f]{64}):[0-9]+$")=VLOOKUP(B${row},'공고상세'!A:B,2,FALSE),"현재","이전"),"확인 필요")`;}
function legacyVerifyNextDetails(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 수집 실행중');try{processDetailJobs(SpreadsheetApp.openById(SPREADSHEET_ID),Date.now());}finally{lock.releaseLock();}}

// Phase 2 quality handoff. Derived fields do not alter source hashes or notification events.
function v2ClassifySupply(row,raw){
 const src=String(row[33]||''),owner=String(raw.BSNS_MBY_NM||''),detail=String(raw.HOUSE_DTL_SECD_NM||''),rent=String(raw.RENT_SECD_NM||'');
 if(/^LH_/.test(src))return [/민간임대/.test((raw.td||[])[1]||'')?'민간임대':/sale/.test(src)?'공공분양':'공공임대','LH 공식 '+src+' 게시판 공급분류'];
 if(/PblPvtRent/.test(src)||detail==='민간임대')return ['민간임대','공식 API 공공지원민간임대 경로 또는 세부유형 민간임대'];
 const pub=/^(한국토지주택공사|경기주택도시공사|서울주택도시개발공사|서울주택도시공사|인천도시공사)/.test(owner);
 if(/임대/.test(rent))return [pub?'공공임대':detail==='민영'?'민간임대':'미확인','RENT_SECD_NM='+rent+'; 사업주체='+owner];
 if(/APT|Remndr|OPT/.test(src)&&pub)return ['공공분양','분양 조회 경로; 공식 사업주체='+owner];
 if(detail==='민영'&&rent==='분양주택')return ['민간분양','HOUSE_DTL_SECD_NM=민영; RENT_SECD_NM=분양주택'];
 if(/Remndr|OPT/.test(src)&&owner&&!pub)return ['민간분양','APT 재공급/임의공급 분양 경로; 공식 민간 사업주체='+owner];
 return ['미확인','공공·민간 또는 임대·분양 확정 근거 부족; 공식 세부유형='+detail+'; 사업주체='+owner];
}
function qualityEvidence(row,d,raw){
 const building=d&&d.building==='아파트'?'아파트':/APT|Remndr|OPT/.test(String(row[33]))?'아파트':/아파트/.test(String(d&&d.address||''))?'아파트':/^(오피스텔|도시형생활주택|도시형 생활주택|생활숙박시설)$/.test(raw.HOUSE_DTL_SECD_NM||'')?raw.HOUSE_DTL_SECD_NM:'원문 확인 필요';
 const supply=classifySupplyV2(row,raw),x=d||{},known=v=>v!==undefined&&v!==null&&v!==''&&!/확인 필요|미확인/.test(String(v));
 const fields=[['상세주소',known(x.address)],['건물유형',known(building)],['전용면적',typeof x.max==='number'&&x.max>0],['금회공급수',!!(x.units||[]).length&&(x.units||[]).every(u=>typeof u.count==='number')],['가격/보증금',!!(x.units||[]).length&&(x.units||[]).every(u=>typeof u.deposit==='number')],['접수일정',known(x.begin)&&known(x.end)],['당첨발표',known(x.winner)],['입주예정',known(x.move)]];
 return {building,supply,done:fields.filter(f=>f[1]).length,missing:fields.filter(f=>!f[1]).map(f=>f[0]).join(', '),core:d?(fields.every(f=>f[1])?'핵심8항목 확인':'핵심정보 일부 확인'):'상세 미생성'};
}
function latestImportanceV2(row,d,q){
 if(!d)return ['★검토 필요★','상세 미생성: 순환 수집 대기; 신청자격 확인 필요'];
 const addresses=String(d.address||'').split(';').map(s=>s.trim()).filter(Boolean),near=/서울|경기.*(고양|김포|부천|광명|시흥|안양|과천|의왕|성남|하남|구리|남양주|의정부|양주)/;
 const matched=addresses.filter(a=>supplyGeo52A(a).target),hint=regionV4(row,d).eligible&&regionV4(row,d).group!=='지역 확인 필요';
 if(!matched.length&&!hint)return ['',''];
 if(/취소/.test(String(row[5])))return ['★검토 필요★','취소 표시: 실제 모집 유효성 확인 필요; 신청자격 확인 필요'];
 // Multi-complex notices qualify only if all explicitly listed addresses meet the regional rule.
 if(matched.length&&matched.length===addresses.length&&(d.complexes.length===1||addresses.every(a=>/아파트/.test(a)))&&q.building==='아파트'&&typeof d.max==='number'&&d.max>=59)return ['★중요★','공식 상세주소 '+matched.join('; ')+'; 아파트 근거 확인; 금회 전용 최대 '+d.max+'㎡(59㎡ 이상). 검토 가치 확인이며 신청자격·비용·해당 주택형 확인 필요'];
 return ['★검토 필요★','서울/인접 경기 후보; '+(q.building==='아파트'?'아파트 확인':'아파트 여부 확인 필요')+'; '+(typeof d.max==='number'?'금회 전용 최대 '+d.max+'㎡':'전용면적 확인 필요')+'; 복수단지 지역·주택형 연결 및 신청자격 확인 필요'];
}
function detailDue(ss,id){const r=ss.getSheetByName('상세작업').getDataRange().getValues().find(x=>x[0]===id);return !r||!r[5]||!/^\d{4}-/.test(String(r[5]))||String(r[5])<=nowKst();}
function retryDelayV2(n){return n<=1?15:n===2?60:n===3?180:360;}
function detailAttempt(ss,id){const j=detailJob52A(ss,id);j.s.getRange(j.at,13).setValue(Number(j.row[12]||0)+1);return j;}
function detailFailed(ss,id,error){const j=detailJob52A(ss,id),n=Number(j.row[14]||0)+1,next=Utilities.formatDate(new Date(Date.now()+retryDelayV2(n)*60000),'Asia/Seoul','yyyy-MM-dd HH:mm:ss');j.s.getRange(j.at,2).setValue(classifyError(error));j.s.getRange(j.at,6).setValue(next);j.s.getRange(j.at,14,1,2).setValues([[Number(j.row[13]||0)+1,n]]);ss.getSheetByName('처리오류이력').appendRow([nowKst(),'상세',id,n>=3?'재시도 누적실패':'실패',n,next,safeError(error)]);}
function detailRecovered(ss,id){const s=ss.getSheetByName('상세작업'),rows=s.getDataRange().getValues(),at=rows.findIndex(r=>r[0]===id);if(at<1)return;if(Number(rows[at][14]||0)>0)ss.getSheetByName('처리오류이력').appendRow([nowKst(),'상세',id,'복구',rows[at][14],'','정상수집 재개']);s.getRange(at+1,15).setValue(0);}
function legacyReconcileQualityV2(ss){
 const master=ss.getSheetByName('공고원장'),rows=safeMasterRows52A(master,40).filter(r=>r[0]),ds=ss.getSheetByName('공고상세'),details=ds.getDataRange().getValues(),di=new Map(details.slice(1).map((r,i)=>[r[0],i+2])),raws=new Map(ss.getSheetByName('수집원본').getDataRange().getValues().slice(1).map(r=>[r[0],r])),js=ss.getSheetByName('상세작업'),jobs=js.getDataRange().getValues(),ji=new Map(jobs.slice(1).map((r,i)=>[r[0],i+2])),attachments=ss.getSheetByName('첨부파일').getDataRange().getValues().slice(1);
 for(let i=0;i<rows.length;i++){
  const row=rows[i],dr=di.has(row[0])?details[di.get(row[0])-1]:null;let d=null,raw={};try{if(dr)d=JSON.parse(dr[16]||'{}');const sr=raws.get(row[38]);if(sr)raw=JSON.parse(sr[5]);}catch(e){ss.getSheetByName('처리오류이력').appendRow([nowKst(),'분석상태',row[0],'JSON 파싱 오류','','',safeError(e)]);}
  const q=qualityEvidence(row,d,raw),imp=latestImportanceV2(row,d,q),af=attachments.filter(a=>a[1]===row[0]),ast=af.length?'첨부 '+af.length+'개: PDF/HWP/HWPX 조건·표 분석 미완료':'원문 첨부 확인 필요';
  let at=ji.get(row[0]);if(!at){at=js.getLastRow()+1;js.getRange(at,1,1,6).setValues([[row[0],'미처리·순환 대기','','','','']]);ji.set(row[0],at);}
  js.getRange(at,7,1,6).setValues([[d?'Y':'N',q.core,q.done/8,q.missing,ast,'신청자격 확인 필요·충족 미판정']]);
  if(dr){ds.getRange(di.get(row[0]),18,1,9).setValues([[...imp,...q.supply,q.building,q.core,q.done/8,q.missing,'신청자격 확인 필요']]);}
  // Update only recognized generated supply labels; custom user classifications survive.
  if(q.supply[0]!=='미확인'&&(/^(분양\(공공·민간 확인 필요\)|공급구분 확인 필요)$/.test(String(row[3]))||(dr&&row[3]===dr[19]))&&row[3]!==q.supply[0])master.getRange(i+5,4).setValue(q.supply[0]);
 }
}
function v2QualityDashboard(ss=SpreadsheetApp.openById(SPREADSHEET_ID)){
 legacyRefreshDashboard(ss);if(!ss.getSheetByName('처리오류이력'))return;reconcileQualityV2(ss);
 const s=ss.getSheetByName('대시보드');s.getRange('A2').setValue('LH·청약홈 5종 실제 연동 / 상세·첨부 순환 처리 / 전국 전체 수집 미완료 / 신청자격 별도 확인');
 const metrics=[['전체 공고',"=COUNTA('공고원장'!A5:A)"],['★중요★ · 최신 근거',"=COUNTIF('공고상세'!R2:R,\"★중요★\")"],['★검토 필요★ · 최신 분석',"=COUNTIF('공고상세'!R2:R,\"★검토 필요★\")"],['수집 경로 상태',"=\"정상 \"&COUNTIF('수집상태'!C2:C,\"정상*\")&\" / 전체 \"&COUNTA('수집상태'!A2:A)&\" · 경고 \"&COUNTIF('수집감시'!F2:F,\"*경고*\")"],['외부 알림','미연결·발송 없음']];s.getRange(5,1,metrics.length,2).setValues(metrics);
 const more=[['조회기간',"=TEXT(INDEX(SORT(FILTER('수집상태'!E2:E,'수집상태'!E2:E<>\"\")),1),\"yyyy-mm-dd\")&\" ~ \"&TEXT(INDEX(SORT(FILTER('수집상태'!F2:F,'수집상태'!F2:F<>\"\"),1,FALSE),1),\"yyyy-mm-dd\")"],['기존 예비 중요 · 보존',"=COUNTIF('공고원장'!V5:V,\"*중요*\")"],['상세 레코드 생성',"=COUNTA('공고상세'!A2:A)"],['상세 미생성 · 순환 대기',"=B5-B14"],['핵심8항목 확인 건수',"=COUNTIF('상세작업'!H2:H,\"핵심8항목 확인\")"],['실제 핵심정보 완료율', '=IFERROR(B16/B5,0)'],['핵심정보 미완료', '=B5-B16'],['핵심 항목 평균 확인율',"=IFERROR(AVERAGE('상세작업'!I2:I),0)"],['첨부 링크 · 조건 분석 미완료',"=COUNTA('첨부파일'!A2:A)"],['PDF 미분석 링크',"=COUNTIF('첨부파일'!D2:D,\"*.pdf\")"],['HWP 미분석 링크',"=COUNTIF('첨부파일'!D2:D,\"*.hwp\")"],['HWPX 조건·표 미분석 링크',"=COUNTIF('첨부파일'!D2:D,\"*.hwpx\")"],['상세 오류 · 재시도 대기',"=COUNTIF('상세작업'!O2:O,\">0\")"],['상세 3회 이상 연속 실패',"=COUNTIF('상세작업'!O2:O,\">=3\")"],['발송차단 초기/과거 이벤트',"=COUNTIF('발송대기'!I2:I,\"N\")"],['공급구분 미확인',"=COUNTIF('공고원장'!D5:D,\"*확인 필요*\")"],['분석 완료 기준','주소·건물유형·전용면적·금회공급수·가격·접수일정·당첨발표·입주예정의 8항목. 신청자격은 별도 미판정']];s.getRange(12,1,more.length,2).setValues(more);s.getRange('B17').setNumberFormat('0.0%');s.getRange('B19').setNumberFormat('0.0%');
}
function installQualityHandoff(){
 const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 수집 실행중');try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID);supportV2(ss);let log=ss.getSheetByName('처리오류이력');if(!log){log=ss.insertSheet('처리오류이력');log.appendRow(['시각(KST)','작업','공고ID','결과','연속실패수','다음재시도','오류/복구 내용']);log.setFrozenRows(1);}
 ss.getSheetByName('첨부파일').getRange(1,13,1,4).setValues([['시도수(보완 이후)','실패누계(보완 이후)','연속실패수','다음재시도']]);
 ss.getSheetByName('공고상세').getRange(1,20,1,7).setValues([['최신 공급유형','공급분류 근거','근거 건물유형','핵심정보 분석상태','핵심8항목 확인율','미확인 핵심항목','신청자격 판정']]);
 ss.getSheetByName('상세작업').getRange(1,7,1,9).setValues([['상세레코드 생성','핵심정보 분석상태','핵심8항목 확인율','미확인 핵심항목','원문 첨부 분석상태','신청자격 판정','실제 시도수(보완 이후)','실패 누계(보완 이후)','연속실패수']]);
 ss.getSheetByName('시스템설정').getRange('A2').setValue('LH·청약홈 공식 5종 API 연동. 수집상태·수집감시 기준 운영. 전국 전체 수집 미완료.');ss.getSheetByName('시스템설정').getRange('C11').setValue('기존 runCollection 시간 트리거 유지; 청약홈 인증키는 스크립트 속성에서 관리');ss.getSheetByName('시스템설정').getRange('D10').setValue('운영·경로별 실패/3시간 중단 감시');
 ss.getSheetByName('수집범위').getRange(1,1,10,6).setValues([
 ['기관/경로','공식유형','현재 구현','실제검증','미수집/미검증','공식근거'],
 ['청약홈','APT·도시형/오피스텔/민간임대·무순위·공공지원민간임대·임의공급','공식 목록5종+주택형5종','실제 API 수집·Sheets 저장','API 미제공 첨부·자격조건, 전용면적 미제공 유형','https://www.data.go.kr/data/15098547/openapi.do'],
 ['LH 게시판','임대·분양','최근전체상태 + 2000년부터 공고중 조회','148 고유공고 기준 실수집 검증; 최신 수집상태 참조','접수상태 필터 외 과거공고/외부 신청 별도게시판 완전성 미보장','https://apply.lh.or.kr/'],
 ['LH 공식API','분양·임대','미연동','교차검증 미실시','인증키 및 응답 대조 필요','공공데이터포털 LH 공고정보'],
 ['LH 선착순/수의계약','메뉴1·2·5','공식 재고표 별도 기록','14/0/0행 실응답 검증','공고ID·현재 계약가능성 별도확인; 공고원장 전체등록 아님','수의계약점검 탭 근거URL'],
 ['첨부파일','PDF/HWP/HWPX','URL·해시 순환점검·HWPX 텍스트 추출','바이너리 및 텍스트 처리 실제 검증','PDF/HWP 의미분석, HWPX 조건·표 구조 해석 미완료','첨부파일 탭'],
 ['기타기관','SH·GH·HUG·청년안심주택','후속단계','미수집','전국 완전수집 아님','SH 최우선'],
 ['조회기간','최근 목록 2026-09-18부터 현재','종료일 매 실행 갱신','LH 공고중은 2000년부터 보완조회','기간 이전 종료공고 전체 백필 미실시','수집상태 E:F'],
 ['중요 판단','기존 예비표시와 최신 상세근거 분리','상세 R:S 최신 / 원장 V:W 보존','검토 가치와 신청자격 분리','신청자격 충족 단정 금지','중요공고/상세작업 참조'],
 ['자동실행','기존 1시간 트리거','중복 생성 없음','Apps Script 실행기록 + 수집감시','사이트 변경·권한·실행 누락 시 운영매뉴얼로 복구','대시보드/수집감시']]);
 const imp=ss.getSheetByName('중요공고');imp.getRange('A2').setValue('최신 근거 기반 ★중요★와 ★검토 필요★를 분리. 원장 V:W는 기존 예비표시 보존. 신청자격은 별도 확인 필요.');imp.getRange('N4:P4').setValues([['★검토 필요★ 공고ID','판정','구체적 근거']]);imp.getRange('N5').setFormula('=IFERROR(FILTER({\'공고상세\'!A2:A,\'공고상세\'!R2:S},\'공고상세\'!R2:R="★검토 필요★"),"검토 필요 공고 없음")');
 refreshMonitor(ss);ss.getSheetByName('개발검증').appendRow(['인수인계 보완 설치','실제 반영',nowKst()+' | 기존 ID/이력/트리거 보존; 파생지표 별도 관리']);console.log('QUALITY_HANDOFF_INSTALLED');}finally{lock.releaseLock();}
}
function verifyNextDetails(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 수집 실행중');try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID);processDetailJobs(ss,Date.now());refreshMonitor(ss);console.log('DETAIL_ROTATION_VERIFIED');}finally{lock.releaseLock();}}

const SH_ORIGIN='https://www.i-sh.co.kr';
const SH_FROM='2026-01-01';
const SH_ROUTES=[
 {id:'SH_주택임대',path:'/main/lay2/program/S1T294C297/www/brd/m_247/list.do',cat:'2',from:SH_FROM,recruit:true},
 {id:'SH_주택분양',path:'/main/lay2/program/S1T294C296/www/brd/m_244/list.do',cat:'1',from:SH_FROM,recruit:true},
 {id:'SH_주택매입',path:'/main/lay2/program/S1T294C3379/www/brd/m_247/list.do',cat:'512',from:SH_FROM,recruit:true},
 {id:'SH_입주안내',path:'/main/lay2/program/S1T294C298/www/brd/m_248/list.do',cat:'4',from:SH_FROM,recruit:false},
 {id:'SH_전체모집',path:'/main/lay2/program/S1T294C295/www/brd/m_241/list.do',cat:'',from:SH_FROM,recruit:true},
 {id:'SH_최근전체공고',path:'/main/lay2/program/S1T294C295/www/brd/m_241/list.do',cat:'',from:'2026-09-18',recruit:false}
];
function shUrl(src,page,to){return SH_ORIGIN+src.path+'?'+qs({page,srchFr:src.from,srchTo:to,itm_seq_1:src.recruit?'1':'0',...(src.cat?{multi_itm_seq:src.cat}:{multi_itm_seqs:'1,2,4,8,16,32,64,128,256,512,1024'})});}
function shProgram(title){
 const ii=/신혼.*매입임대(?:주택)?\s*\(?[Ⅱ2](?!\d)/.test(title),one=/신혼.*매입임대(?:주택)?\s*\(?[Ⅰ1](?!\d)/.test(title);
 if(/장기안심/.test(title))return '장기안심주택(보증금지원)';
 if(/보증금지원/.test(title))return /미리내집/.test(title)?'보증금지원형 미리내집':'보증금지원형 주거지원';
 if(/일반주택형.*미리내집/.test(title))return /공공한옥/.test(title)?'일반주택형 미리내집(공공한옥)':ii?'일반주택형 미리내집(신혼·신생아 매입임대Ⅱ)':'일반주택형 미리내집';
 if(ii)return '신혼·신생아 매입임대Ⅱ';if(one)return '신혼·신생아 매입임대Ⅰ';
 if(/아파트형.*미리내집|장기전세주택\s*[2Ⅱ](?!\d)/.test(title))return '아파트형 미리내집/장기전세Ⅱ';
 if(/미리내집/.test(title))return /공공한옥/.test(title)?'미리내집(공공한옥/연계형)':'미리내집(세부유형 확인 필요)';
 return /장기전세/.test(title)?'일반 장기전세':/분양주택|공공분양/.test(title)?'공공분양':/행복주택/.test(title)?'행복주택':/장기미임대/.test(title)?'장기미임대':/재개발임대/.test(title)?'재개발임대':/매입임대/.test(title)?'매입임대':'기타 주거용 모집';
}

function shDisposition(title){
 if(/상가|공장|용지|택지|토지.*(?:매각|매수)|사업자|운영기관|관리업체|주택매입공고|주택 매입공고/.test(title)&&!/토지임대부.*분양주택/.test(title))return ['제외','주거용 입주자 모집 아님'];
 const common=noticeKind52A(title);if(resultNotice52A(title)){if(common==='EXCLUDED')return ['제외','공통 결과/대상자 발표 판정·원장/원천 보존'];if(common==='REVIEW')return ['별도검토','결과 및 실제 모집변경 혼합·원문 근거 확인 필요'];}
 const action=/2순위.*(?:청약|접수).*안내|추가.*접수|접수.*연장|정정.*모집|모집.*정정|추가모집|재모집/.test(title);
 if(/당첨자|입주대상자.*발표|예비자.*발표|대상자.*발표|심사대상|경쟁률|선정결과|배정 결과|접수 결과|접수결과/.test(title)&&!action)return ['제외','결과·경쟁률·당첨자 안내'];
 if(/(?:입주자|입주대상자|잔여세대|주택|거주자).*(?:모집|청약)|2순위.*청약접수.*안내/.test(title))return ['수집','주거용 신규/정정/추가접수 후보'];
 return ['별도검토','모집 여부 제목만으로 불충분'];
}
function parseSHList(html){
 const c=html.match(/class=["'][^"']*mentcount[^"']*["'][^>]*>([\s\S]*?)<\/div>/i),txt=c?textOf(c[1]):'',m=txt.match(/총\s*([\d,]+)\s*건\s*\[(\d+)\/(\d+)페이지/);
 if(!m)throw Error('PARSE: SH 총건수/페이지 표식 없음');
 if(Number(m[3])>=1&&Number(m[2])>Number(m[3]))throw Error('PARTIAL: SH 페이지 범위 초과 '+m[2]+'/'+m[3]);
 const table=(html.match(/<table\b[^>]*>[\s\S]*?<\/table>/gi)||[]).find(t=>/공고 및 공지 목록/.test(t));if(!table)throw Error('PARSE: SH 공고 목록 표 없음');
 const records=[],pinned=[];for(const tr of table.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)){
  const a=tr[1].match(/<a\b[^>]*onclick=["'][^"']*getDetailView\('?(\d+)'?\)[^>]*>([\s\S]*?)<\/a>/i);if(!a)continue;
  const tds=[...tr[1].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map(x=>textOf(x[1]));
  const published=tds.find(x=>/^20\d{2}-\d{2}-\d{2}$/.test(x));if(!published||!textOf(a[2]))throw Error('PARSE: SH 공고번호/게시일/제목 누락');
  const row={seq:a[1],title:textOf(a[2]),published,department:tds[2]||''};if(tds[0]==='공지')pinned.push({...row,pinned:true});else records.push(row);
 }
 const total=Number(m[1].replace(/,/g,''));if(total>0&&!records.length&&!pinned.length)throw Error('PARSE: SH 목록 행 추출 0건');
 return {total,page:Number(m[2]),pages:Number(m[3]),records,pinned};
}
function collectSH(src,to,start){let all=[],total=null,pages=null;const pins=new Map();
 for(let page=1;page<=150;page++){
  if(Date.now()-start>110000)throw Error('PARTIAL: SH 실행예산 소진·다음 실행 재시도');
  const html=fetchText(shUrl(src,page,to)),x=parseSHList(html);
  if(x.page!==page)throw Error('PARTIAL: SH 요청 페이지 미반영');
  if(!new RegExp('name=["\']srchFr["\'][^>]*value=["\']'+src.from+'["\']|value=["\']'+src.from+'["\'][^>]*name=["\']srchFr["\']').test(html))throw Error('PARSE: SH 조회기간 미반영');
  if(total===null){total=x.total;pages=x.pages;}if(x.total!==total||x.pages!==pages)throw Error('PARTIAL: SH 수집 중 총건수 변경');
  for(const r of x.pinned)pins.set(r.seq,r);all.push(...x.records);if(page>=pages||total===0){if(all.length!==total||new Set(all.map(r=>r.seq)).size!==total)throw Error('PARTIAL: SH 건수/고유번호 대조 실패');return {total,pages,pinned:pins.size,rows:all.concat([...pins.values()].filter(r=>!all.some(a=>a.seq===r.seq)))};}
 }throw Error('PARTIAL: SH 페이지 상한');
}
function normalizeSH(raw,source){const program=shProgram(raw.title),supply=/사회주택|협동조합주택/.test(raw.title)?'공급구분 확인 필요':/보증금지원|장기안심/.test(raw.title)?'보증금지원':/분양주택|공공분양/.test(raw.title)?'공공분양':'공공임대';return {id:'SH:'+raw.seq,number:raw.seq,system:'SH_GS0401',source,agency:'SH서울주택도시개발공사',title:raw.title,published:raw.published,region:'서울권(세부 소재지 확인 필요)',type:program,supply,status:'접수기간 원문 확인 필요',url:SH_ORIGIN+'/main/lay2/program/S1T294C295/www/brd/m_241/view.do?seq='+raw.seq,change:/정정|수정/.test(raw.title)?'정정공고':/추가|재모집|잔여세대|2순위/.test(raw.title)?'추가모집':'신규',raw:JSON.stringify(raw)};}
function shDateTokens(line,year){
 const out=[];let prior=null;const re=/(20\d{2})[.\/-](\d{1,2})[.\/-](\d{1,2})|(?<!\d)(\d{1,2})[.\/](\d{1,2})(?!\d)/g;let m;
 while((m=re.exec(String(line)))){const explicit=!!m[1],mo=+(m[2]||m[4]),day=+(m[3]||m[5]);let y=explicit?+m[1]:prior?prior.y:+year;if(!explicit&&prior&&prior.mo===12&&mo===1)y=prior.y+1;else if(!explicit&&prior&&mo<prior.mo)throw Error('PARSE: SH ambiguous month decrease');const date=y+'-'+String(mo).padStart(2,'0')+'-'+String(day).padStart(2,'0');if(!temporal52A(date))throw Error('PARSE: SH invalid date');out.push(date);prior={y,mo};}return out;
}
function parseSHDetail(html,r){
 const body=(html.match(/<td\b[^>]*class=["'][^"']*\bcont\b[^"']*["'][^>]*>([\s\S]*?)<\/td>/i)||[])[1];if(!body||!html.includes(r.number))throw Error('PARSE: SH 상세 본문/공고번호 확인 실패');
 const lines=body.replace(/<\/(?:p|div|li|h\d)>|<br\s*\/?\s*>/gi,'\n').split('\n').map(textOf).filter(Boolean),text=lines.join('\n'),year=kstDayV3(r.published).slice(0,4),schedules=[];let receipt=false,winner='';
 for(const line of lines){
  if(/접수일|신청기간|청약기간|접수기간/.test(line)&&!/서류|심사|포기/.test(line))receipt=true;
  if(/^[■□○]?\s*(?:당첨자|심사대상자|서류제출|기타|문의)/.test(line))receipt=false;
  if(/당첨자\s*발표/.test(line)){const dates=shDateTokens(line,year);if(dates.length)winner=dates[0];}
  if(receipt&&!/발표|선정결과|포기|서류제출|방문.*유의/.test(line)){const dates=shDateTokens(line,year);if(dates.length)schedules.push({label:line.slice(0,120),begin:dates[0],end:dates[dates.length-1],evidence:line});}
 }
 const dates=schedules.flatMap(s=>[s.begin,s.end]).sort(),files=html.match(/initParam\.downList\s*=\s*(\[[\s\S]*?\]);/),attachments=[];
 if(files){let parsed;try{parsed=JSON.parse(files[1]);}catch(e){throw Error('PARSE: SH 첨부 메타JSON 변경');}for(const f of parsed){if(String(f.seq)!==String(r.number))throw Error('PARSE: SH 첨부 공고번호 불일치');attachments.push({fileId:f.brdId+':'+f.seq+':'+f.fileSeq,name:f.oriFileNm,size:Number(f.fileSize),url:SH_ORIGIN+'/main/com/file/innoFD.do?'+qs({brdId:f.brdId,seq:f.seq,fileTp:f.fileTp,fileSeq:f.fileSeq}),mode:'공식 다운로드 경로·바이너리 순환검증'});}}
 const count=(text.match(/공급(?:호수|세대수)\s*[:：]?\s*([\d,]+)\s*(?:호|세대)/)||[])[1];
 return {_parserVersion:'SH52A2',id:r.id,url:r.url,complexes:[r.title],units:[],attachments,address:lines.filter(line=>/^(?:공급(?:주택)?\s*)?(?:소재지|주택주소|공급주소)\s*[:：]/.test(line)).map(line=>line.replace(/^[^:：]+[:：]\s*/,'' )).filter(x=>supplyGeo52A(x).known).join('; '),building:/아파트형/.test(text)?'아파트':'원문 확인 필요',begin:dates.length?dates[0]:'',end:dates.length?dates[dates.length-1]:'',winner,move:'',qualification:'원문 확인 필요',price:'원문 확인 필요',monthly:'원문 확인 필요',min:'',max:'',count:count?Number(count.replace(/,/g,'')):'',schedules,bodyEvidence:text.slice(0,18000),status:'SH 공식 HTML 본문 확인·기간은 추출 근거행 참조·PDF/HWP 조건 미분석'};
}
function saveSHAttachments(ss,r,d){const s=ss.getSheetByName('첨부파일'),all=s.getDataRange().getValues();for(const f of d.attachments){const key=r.id+':'+f.fileId,old=all.find(a=>a[0]===key),a=(old||[key,r.id,f.fileId,f.name,f.url,'','','','미취득','','0',nowKst()]).slice();while(a.length<19)a.push('');a[3]=f.name;a[4]=f.url;a[16]=f.size;a[17]=f.size>12000000?'별도처리':'자동점검';a[18]=f.size>12000000?'12MB 초과·외부 분석 필요':'';if(!old||String(old[8]).startsWith('별도처리:'))a[8]=f.size>12000000?'별도처리: '+a[18]:'다운로드 해시 점검 대기';upsertTable(s,[a]);}}
function runSHCollection(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 수집 실행중');const start=Date.now();try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID);supportV3(ss);const to=todayKst(),audit=ss.getSheetByName('SH게시판대조');
 const props=PropertiesService.getScriptProperties(),cursor=Number(props.getProperty('SH_ROUTE_CURSOR')||0)%SH_ROUTES.length,ordered=SH_ROUTES.slice(cursor).concat(SH_ROUTES.slice(0,cursor));props.setProperty('SH_ROUTE_CURSOR',String((cursor+1)%SH_ROUTES.length));for(const cfg of ordered){const src={...cfg,agency:'SH',label:cfg.id,url:shUrl(cfg,1,to)};sourceAttempt(ss,src,to);try{const result=collectSH(cfg,to,start),records=[],auditRows=[];for(const row of result.rows){const c=shDisposition(row.title);auditRows.push([cfg.id+':'+row.seq,cfg.id,nowKst(),result.total,result.pages,row.seq,row.title,row.published,c[0],(row.pinned?'고정공지·검색총건수와 별도; ':'')+c[1],normalizeSH(row,cfg.id).url]);if(c[0]==='수집')records.push(normalizeSH(row,cfg.id));}upsertSHMachineAudit(audit,auditRows);sourceFinish(ss,src,records,null,to);const s=ss.getSheetByName('수집상태'),at=s.getDataRange().getValues().findIndex(r=>r[0]===cfg.id);s.getRange(at+1,7).setValue(result.total);s.getRange(at+1,10).setValue('기간 내 공식 '+result.total+'행/ID 대조 완료; 고정공지 '+result.pinned+'건 별도; 제목 별도검토 '+result.rows.filter(r=>shDisposition(r.title)[0]==='별도검토').length+'건. 주거 모집만 원장 반영. 2026년 이전·외부 게시판 미수집');}catch(e){sourceFinish(ss,src,[],safeError(e),to);}}
 const master=ss.getSheetByName('공고원장'),rows=safeMasterRows52A(master,40).filter(r=>String(r[0]).startsWith('SH:')),known=new Set(ss.getSheetByName('공고상세').getDataRange().getValues().slice(1).map(r=>r[0])),dueJobs=new Map(ss.getSheetByName('상세작업').getDataRange().getValues().slice(1).map(r=>[r[0],r[5]])),due=id=>!dueJobs.get(id)||!/^\d{4}-/.test(String(dueJobs.get(id)))||stampV3(dueJobs.get(id))<=nowKst();
 for(const row of rows.filter(r=>!known.has(r[0])&&due(r[0])).sort((a,b)=>kstDayV3(b[2]).localeCompare(kstDayV3(a[2]))).slice(0,8)){if(Date.now()-start>160000)break;const r={id:row[0],number:String(row[34]),title:row[5],published:kstDayV3(row[2]),url:row[26]};detailAttempt(ss,r.id);try{const d=parseSHDetail(fetchText(r.url),r);saveDetail(ss,r,d);saveSHAttachments(ss,r,d);detailRecovered(ss,r.id);}catch(e){const s=ss.getSheetByName('상세작업'),old=s.getDataRange().getValues().find(a=>a[0]===r.id);upsertTable(s,[[r.id,classifyError(e),nowKst(),old?old[3]:'',safeError(e),'']]);detailFailed(ss,r.id,e);}}
 refreshMonitor(ss);console.log('SH_COLLECTION_ATTEMPT_FINISHED; 상세·첨부 미분석은 별도 상태 참조');}finally{lock.releaseLock();}}

function stampV3(v){if(v instanceof Date)return Utilities.formatDate(v,'Asia/Seoul','yyyy-MM-dd HH:mm:ss');return String(v||'').replace(/^(\d{4}-\d{2}-\d{2} )([0-9]):/,'$10$2:');}
function kstDayV3(v){if(typeof v==='string'&&/^20\d{2}-\d{2}-\d{2}T.*(?:Z|[+-]\d{2}:\d{2})$/.test(v)&&!isNaN(Date.parse(v)))return new Date(Date.parse(v)+9*3600000).toISOString().slice(0,10);if(v instanceof Date)return Utilities.formatDate(v,'Asia/Seoul','yyyy-MM-dd');if(typeof v==='number'&&v>20000&&v<100000)return new Date(Date.UTC(1899,11,30)+v*86400000).toISOString().slice(0,10);const m=String(v||'').match(/^(20\d{2})[-.](\d{1,2})[-.](\d{1,2})/);return m?m[1]+'-'+m[2].padStart(2,'0')+'-'+m[3].padStart(2,'0'):'';}
function lifecycle35V4(row,d,today){if(String(row[0]).startsWith('SH:')&&shDisposition(String(row[5]))[0]==='제외')return '모집대상 제외';if(/취소공고|모집취소|공고취소/.test(String(row[5])))return '취소';const intervals=d&&d.schedules||[];if(intervals.length){if(intervals.some(x=>x.begin<=today&&x.end>=today))return '접수중';if(intervals.some(x=>x.begin>today))return '접수예정';if(intervals.every(x=>x.end<today))return '마감';}const begin=kstDayV3(d&&d.begin||row[17]),end=kstDayV3(d&&d.end||row[18]);if(end&&end<today)return '마감';if(begin&&begin>today)return '접수예정';if(begin&&end&&begin<=today&&end>=today)return '접수중';return '기간 확인 필요';}
function assess35V4(row,d,q){
 if(String(row[0]).startsWith('SH:')&&shDisposition(String(row[5]))[0]==='제외')return ['','SH 공식 제목 재검증: 결과/대상자 안내 또는 비주거. 기록 보존·신규 모집 후보 제외'];
 if(String(row[0]).startsWith('SH:')&&/미리내집|장기전세|장기안심|신혼.*매입임대(?:주택)?\s*\(?[Ⅱ2](?!\d)|토지임대부.*분양주택|공공분양/.test(row[5]))return ['★중요★','SH 공식 공고 제목에서 관심 공급유형 '+shProgram(row[5])+' 확인. 검토 가치 표시이며 소재지·아파트 여부·59㎡·비용·신청자격은 별도 확인 필요'];
 if(!d){const t=String(row[8])+' '+String(row[5]);if(/서울|경기.*(고양|김포|부천|광명|시흥|안양|과천|의왕|성남|하남|구리|남양주|의정부|양주)/.test(t))return ['★검토 필요★','임시 검토: 공식 목록의 지역/유형 후보. 상세 레코드 미생성·면적/건물/자격 미확인'];return ['',''];}
 return latestImportanceV2(row,d,q);
}
function classify35V4(row,raw){if(String(row[0]).startsWith('SH:'))return [raw.title?/사회주택|협동조합주택/.test(raw.title)?'공급구분 확인 필요':/보증금지원|장기안심/.test(raw.title)?'보증금지원':/분양주택|공공분양/.test(raw.title)?'공공분양':'공공임대':row[3],'SH 공식 게시 출처·제목 기준. 사회주택/협동조합은 별도 운영주체 확인 필요; 보증금지원은 주택공급과 별도'];return v2ClassifySupply(row,raw);}
function supportV3(ss){
 const defs={'SH게시판대조':['대조키','공식경로','확인시각','공식총건수','전체페이지','공식seq','제목','게시일','처리','판단근거','원문URL'],'공고판정':['공고ID','모집상태','최신 중요표시','판단근거','접수시작','접수마감','최초발견','상세레코드','공급유형','공고명','지역','원문URL','신청자격','관심유형','핵심정보상태','갱신시각'],'별도처리대상':['대상키','공고ID','구분','사유','최초등록','마지막확인','원문URL','처리상태']};
 for(const [n,h] of Object.entries(defs)){let s=ss.getSheetByName(n);if(!s){s=ss.insertSheet(n);s.getRange(1,1,1,h.length).setValues([h]);s.setFrozenRows(1);}}
 const a=ss.getSheetByName('첨부파일');a.getRange(1,17,1,3).setValues([['공식파일크기(byte)','처리구분','별도처리사유']]);
 const p=PropertiesService.getScriptProperties();if(!p.getProperty('V3_STARTED'))p.setProperty('V3_STARTED',nowKst());
}
function legacySourceFinish35(ss,src,records,error,to){
 const q=ss.getSheetByName('발송대기'),before=q.getLastRow(),initial=!PropertiesService.getScriptProperties().getProperty('BASELINE_'+src.id);v2SourceFinish(ss,src,records,error,to);if(error||q.getLastRow()<=before)return;
 const master=ss.getSheetByName('공고원장').getDataRange().getValues(),map=new Map(master.slice(4).map(r=>[r[0],r])),rows=q.getRange(before+1,1,q.getLastRow()-before,10).getValues(),base=PropertiesService.getScriptProperties().getProperty('V3_STARTED');
 for(let i=0;i<rows.length;i++){const e=rows[i],m=map.get(e[1]);if(!m)continue;const changed=e[3]!=='신규',live=base&&stampV3(m[1])>=base,published=kstDayV3(m[2]);let kind=changed?'重要変更候補':initial&&published<todayKst()?'초기백필':live&&published>=todayKst()?'실시간신규':live?'신규발견·과거게시':'초기백필';let [allow,reason]=seedPolicy35(kind,changed);if(kind==='초기백필')reason='이전 초기 적재분 차단 유지';q.getRange(before+i+1,8,1,3).setValues([[kind.replace('重要変更候補','중요변경 후보'),allow,reason]]);}
}
function attachmentDispositionV3(row){if(row[17]==='별도처리')return row[18]||'별도처리';if(Number(row[16])>12000000||/12MB 초과/.test(String(row[8])))return '12MB 초과·외부 분석 필요';if(/압축.*초과|지원하지 않는|unsupported|Invalid argument.*zip/i.test(String(row[8])))return '형식/압축 분석 별도 확인';return '';}
function reconcileExceptionsV3(ss){const s=ss.getSheetByName('첨부파일'),rows=s.getDataRange().getValues().slice(1),ex=ss.getSheetByName('별도처리대상'),all=ex.getDataRange().getValues(),ix=new Map(all.slice(1).map((r,i)=>[r[0],i+1]));for(const r of rows){const reason=attachmentDispositionV3(r);if(!reason)continue;r[17]='별도처리';r[18]=reason;const at=ix.get(r[0]),old=at?all[at]:null,v=[r[0],r[1],'첨부',reason,old?old[4]:nowKst(),nowKst(),r[4],old?old[7]:'수동/외부 처리 대기'];if(at)all[at]=v;else{ix.set(r[0],all.length);all.push(v);}}if(rows.length)s.getRange(2,18,rows.length,2).setValues(rows.map(r=>[r[17]||'',r[18]||'']));ensureRowsV4(ex,all.length);if(all.length>1)ex.getRange(2,1,all.length-1,8).setValues(all.slice(1));}

function reconcileDecisionsV3(ss){
 const m=ss.getSheetByName('공고원장'),rows=safeMasterRows52A(m,40).filter(r=>r[0]),ds=new Map(ss.getSheetByName('공고상세').getDataRange().getValues().slice(1).map(r=>[r[0],r])),out=[],now=nowKst(),today=todayKst();
 for(const row of rows){const dr=ds.get(row[0]);let d=null;try{if(dr)d=JSON.parse(dr[16]||'{}');}catch(e){}const q={building:dr?dr[21]:'원문 확인 필요'},imp=assessV3(row,d,q),status=lifecycleV3(row,d,today);out.push([row[0],status,imp[0],imp[1],kstDayV3(d&&d.begin||row[17]),kstDayV3(d&&d.end||row[18]),row[1],d?'Y':'N',/^(?:SH:|GH:)/.test(String(row[0]))?classifySupplyV2(row,{title:row[5]})[0]:dr&&dr[19]||row[3],row[5],d&&d.address||row[8],row[26],'신청자격 확인 필요',String(row[0]).startsWith('SH:')?shProgram(row[5]):'',dr?dr[22]:'상세 미생성',now]);}
 const s=ss.getSheetByName('공고판정');if(out.length+1>s.getMaxRows())s.insertRowsAfter(s.getMaxRows(),out.length+1-s.getMaxRows());if(out.length)writeChangedRows42A(s,2,1,out,true);s.getRange('E:F').setNumberFormat('yyyy-mm-dd');
 reconcileNotificationV3(ss,new Map(out.map(r=>[r[0],r])));
}
function legacyNotification35(event,decision,firstSeen,v3Started){
 if(event[7]==='파생분류 보완')return ['파생분류 보완','N',event[9]||'공식 제목/게시일/상태/URL 동일·내부 분류 보완 이벤트 발송차단'];if(event[7]==='공식 변경 여부 별도검토')return [event[7],'N',event[9]||'원문 대조 요청·공식 변경 여부 미확인'];
 if(!kstDayV3(event[2]))return [event[7]||'생성시각 미검증','N','이벤트 생성시각 확인 전 발송차단'];
 if(stampV3(event[2])<stampV3(v3Started))return ['초기백필','N','3차 이전 초기 이벤트·변경 이력 포함 발송차단 유지'];
 if(event[3]!=='신규')return [event[7]||'중요변경 후보','Y','게시일과 무관한 변경 이벤트·외부발송 미연결'];
 if(stampV3(firstSeen)<stampV3(v3Started))return [event[7]||'초기백필','N','기존 초기 적재분 발송차단 유지'];
 if(!decision)return ['신규발견·확인대기','N','상세 접수기간 확인 필요'];
 if(decision[1]==='접수중')return [event[7]==='실시간신규'?'실시간신규':'신규발견·접수중','Y','과거 게시일이어도 이번에 발견한 접수중 공고'];
 if(decision[1]==='접수예정')return [event[7]==='실시간신규'?'실시간신규':'신규발견·접수예정','Y','공식 접수기간이 향후로 확인된 신규발견'];
 return [event[7]==='실시간신규'?'실시간신규':event[7]==='초기백필'?'초기백필':'신규발견·과거게시','N',decision[1]==='마감'||decision[1]==='취소'?'마감/취소 공고 초기알림 차단':'접수기간 미검증·알림 보류'];
}
function legacyReconcileNotification35(ss,decisions){const s=ss.getSheetByName('발송대기'),rows=s.getDataRange().getValues().slice(1),master=new Map(ss.getSheetByName('공고원장').getDataRange().getValues().slice(4).map(r=>[r[0],r])),v3=PropertiesService.getScriptProperties().getProperty('V3_STARTED');if(rows.length)s.getRange(2,8,rows.length,3).setValues(rows.map(r=>{const m=master.get(r[1]);return m?notificationV3(r,decisions.get(r[1]),m[1],v3):[r[7]||'',r[8]||'',r[9]||''];}));}

function legacyImportanceFormula35(states){return '=IFERROR(FILTER({\'공고판정\'!A2:A,\'공고판정\'!C2:C,\'공고판정\'!J2:J,\'공고판정\'!K2:K,\'공고판정\'!I2:I,IFERROR(IF(VLOOKUP(\'공고판정\'!A2:A,\'공고상세\'!A:H,8,FALSE)>0,VLOOKUP(\'공고판정\'!A2:A,\'공고상세\'!A:H,8,FALSE),"원문 확인 필요"),"원문 확인 필요"),IF(\'공고판정\'!F2:F<>"",\'공고판정\'!F2:F,"원문 확인 필요"),\'공고판정\'!D2:D,\'공고판정\'!M2:M,IF(\'공고판정\'!A2:A<>"","",""),\'공고판정\'!B2:B,\'공고판정\'!L2:L},\'공고판정\'!C2:C="★중요★",REGEXMATCH(\'공고판정\'!B2:B,"^('+states+')$")),"해당 공고 없음")';}
function legacyDashboard35(ss=SpreadsheetApp.openById(SPREADSHEET_ID)){
 v2QualityDashboard(ss);if(!ss.getSheetByName('공고판정'))return;reconcileExceptionsV3(ss);reconcileDecisionsV3(ss);
 const s=ss.getSheetByName('대시보드');s.getRange('A2').setValue('LH·청약홈·SH 공식 수집 / 현재 유효·마감·기간미확인 분리 / 전국 전체 수집 미완료 / 자격 별도 확인');
 s.getRange('A6:B7').setValues([['현재 유효 ★중요★','=COUNTIFS(\'공고판정\'!C2:C,"★중요★",\'공고판정\'!B2:B,"접수중")+COUNTIFS(\'공고판정\'!C2:C,"★중요★",\'공고판정\'!B2:B,"접수예정")'],['★검토 필요★ · 임시 포함','=COUNTIF(\'공고판정\'!C2:C,"★검토 필요★")']]);
 s.getRange('A29:B34').setValues([['마감/취소 ★중요★','=COUNTIFS(\'공고판정\'!C2:C,"★중요★",\'공고판정\'!B2:B,"마감")+COUNTIFS(\'공고판정\'!C2:C,"★중요★",\'공고판정\'!B2:B,"취소")'],['유효기간 미확인 ★중요★','=COUNTIFS(\'공고판정\'!C2:C,"★중요★",\'공고판정\'!B2:B,"기간 확인 필요")'],['상세 없는 임시 검토','=COUNTIFS(\'공고판정\'!C2:C,"★검토 필요★",\'공고판정\'!H2:H,"N")'],['첨부 별도처리 · 미해결','=COUNTIF(\'첨부파일\'!R2:R,"별도처리")'],['접수기간 확인 필요','=COUNTIF(\'공고판정\'!B2:B,"기간 확인 필요")'],['알림 허용 후보(미연결)','=COUNTIF(\'발송대기\'!I2:I,"Y")']]);
}
function installV3(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 수집 실행중');try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID);supportV2(ss);supportV3(ss);const imp=ss.getSheetByName('중요공고');imp.getRange('A2').setValue('A:L 현재 접수중/접수예정 중요 / N:R 검토(임시 포함) / T:X 중요·기간미확인. 마감 중요는 별도 탭. 자격 충족 판정 아님.');imp.getRange('A5').setFormula(importanceFormulaV3('접수중|접수예정'));imp.getRange('N4:R4').setValues([['검토공고ID','공고명','모집상태','판단근거','원문URL']]);imp.getRange('N5').setFormula('=IFERROR(FILTER({\'공고판정\'!A2:A,\'공고판정\'!J2:J,\'공고판정\'!B2:B,\'공고판정\'!D2:D,\'공고판정\'!L2:L},\'공고판정\'!C2:C="★검토 필요★"),"검토 공고 없음")');imp.getRange('T4:X4').setValues([['중요·기간미확인ID','공고명','모집상태','판단근거','원문URL']]);imp.getRange('T5').setFormula('=IFERROR(FILTER({\'공고판정\'!A2:A,\'공고판정\'!J2:J,\'공고판정\'!B2:B,\'공고판정\'!D2:D,\'공고판정\'!L2:L},\'공고판정\'!C2:C="★중요★",\'공고판정\'!B2:B="기간 확인 필요"),"기간미확인 중요 없음")');
 let archived=ss.getSheetByName('마감중요공고');if(!archived){archived=ss.insertSheet('마감중요공고');archived.getRange('A1').setValue('마감/취소 중요공고 · 검토 이력 보존');archived.getRange(4,1,1,12).setValues(imp.getRange(4,1,1,12).getValues());archived.setFrozenRows(4);}archived.getRange('A5').setFormula(importanceFormulaV3('마감|취소'));for(const tab of [imp,archived]){tab.getRange('G5:G').setNumberFormat('yyyy-mm-dd');tab.getRange('F5:F').setNumberFormat('0.00');}
 const m=ss.getSheetByName('공고원장');m.getRange('R5:T').setNumberFormat('yyyy-mm-dd');m.getRange('U5:U').setNumberFormat('yyyy-mm');
 const settings=ss.getSheetByName('시스템설정');settings.getRange('A2').setValue('3차: SH 공식 수집 추가 / 기존 시간 트리거 유지 / 원장 보존 / 마감·알림·별도처리 정책 보완');ss.getSheetByName('운영가이드').getRange('A2').setValue('3차 운영: 공고판정·SH게시판대조·별도처리대상 참조. 외부 알림 미연결. 과거공고도 공식 접수중/접수예정 확인 시 신규발견 후보로 분류. 기존 초기 적재 차단 유지.');
 refreshMonitor(ss);ss.getSheetByName('개발검증').appendRow(['3차 운영개선 설치','실제 반영',nowKst()]);console.log('V3_INSTALLED');}finally{lock.releaseLock();}}
function legacyRun35(){const started=Date.now();v2RunCollection();if(Date.now()-started<180000)runSHCollection();else{const ss=SpreadsheetApp.openById(SPREADSHEET_ID);supportV3(ss);for(const src of SH_ROUTES){sourceAttempt(ss,{...src,from:src.from},todayKst());sourceFinish(ss,{...src,agency:'SH',label:src.id,url:shUrl(src,1,todayKst())},[],'PARTIAL: 기존 수집 예산 소진·SH 다음 실행 재시도',todayKst());}}}
function verifyV3SH(){runSHCollection();}
function probeSHDownloadScript(){const s=SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName('SH수집검증'),text=fetchText(SH_ORIGIN+'/main/js/sh/sh_innorix.js');for(let i=0;i<text.length;i+=18000)s.appendRow(['SH첨부 공식 스크립트',nowKst(),200,text.length,text.slice(i,i+18000)]);}

// Batch only machine-derived columns; preserve source fields, retry counters and user cells.
function reconcileQualityV2(ss){
 const master=ss.getSheetByName('공고원장'),rows=safeMasterRows52A(master,40),ds=ss.getSheetByName('공고상세'),details=ds.getDataRange().getValues(),di=new Map(details.slice(1).map((r,i)=>[r[0],i+1])),raws=new Map(ss.getSheetByName('수집원본').getDataRange().getValues().slice(1).map(r=>[r[0],r])),js=ss.getSheetByName('상세작업'),jobs=js.getDataRange().getValues(),ji=new Map(jobs.slice(1).map((r,i)=>[r[0],i+1])),attachments=ss.getSheetByName('첨부파일').getDataRange().getValues().slice(1),af=new Map();
 const oldJobCount4=jobs.length;for(const a of attachments)af.set(a[1],(af.get(a[1])||0)+1);
 for(let i=0;i<rows.length;i++){const row=rows[i];if(!row[0])continue;const atd=di.get(row[0]),dr=atd?details[atd]:null;let d=null,raw={};try{if(dr)d=JSON.parse(dr[16]||'{}');const sr=raws.get(row[38]);if(sr)raw=JSON.parse(sr[5]);}catch(e){ss.getSheetByName('처리오류이력').appendRow([nowKst(),'분석상태',row[0],'JSON 파싱 오류','','',safeError(e)]);}
 const q=qualityEvidence(row,d,raw),imp=latestImportanceV2(row,d,q),n=af.get(row[0])||0;let at=ji.get(row[0]);if(!at){at=jobs.length;jobs.push([row[0],'미처리·순환 대기','','','','']);ji.set(row[0],at);}
 while(jobs[at].length<15)jobs[at].push('');jobs[at].splice(6,6,d?'Y':'N',q.core,q.done/8,q.missing,n?'첨부 '+n+'개: PDF/HWP/HWPX 조건·표 분석 미완료':'원문 첨부 확인 필요','신청자격 확인 필요·충족 미판정');
 if(dr){const oldSupply=dr[19];while(dr.length<26)dr.push('');dr.splice(17,9,...imp,...q.supply,q.building,q.core,q.done/8,q.missing,'신청자격 확인 필요');if(q.supply[0]!=='미확인'&&(/^(분양\(공공·민간 확인 필요\)|공급구분 확인 필요)$/.test(String(row[3]))||row[3]===oldSupply)&&row[3]!==q.supply[0])master.getRange(i+5,4).setValue(q.supply[0]);}
 }
 ensureRowsV4(js,jobs.length);if(jobs.length>oldJobCount4)js.getRange(oldJobCount4+1,1,jobs.length-oldJobCount4,6).setValues(jobs.slice(oldJobCount4).map(r=>r.slice(0,6)));if(jobs.length>1)js.getRange(2,7,jobs.length-1,6).setValues(jobs.slice(1).map(r=>Array.from({length:6},(_,i)=>r[i+6]===undefined?'':r[i+6])));
 if(details.length>1)ds.getRange(2,18,details.length-1,9).setValues(details.slice(1).map(r=>Array.from({length:9},(_,i)=>r[i+17]===undefined?'':r[i+17])));
}
function upsertSHMachineAudit(sheet,incoming){const all=sheet.getDataRange().getValues(),index=new Map(all.slice(1).map((r,i)=>[r[0],i+1]));for(const r of incoming){if(index.has(r[0]))all[index.get(r[0])]=r;else{index.set(r[0],all.length);all.push(r);}}if(all.length>sheet.getMaxRows())sheet.insertRowsAfter(sheet.getMaxRows(),all.length-sheet.getMaxRows());if(all.length>1)sheet.getRange(2,1,all.length-1,11).setValues(all.slice(1).map(r=>Array.from({length:11},(_,i)=>r[i]===undefined?'':r[i])));}

function verifySHAttachmentPaths(){const ss=SpreadsheetApp.openById(SPREADSHEET_ID),s=ss.getSheetByName('첨부파일'),rows=s.getDataRange().getValues().slice(1),log=ss.getSheetByName('개발검증');
 const url=SH_ORIGIN+'/main/com/file/innoFD.do?'+qs({brdId:'GS0401',seq:'311656',fileTp:'A',fileSeq:'1'}),res=UrlFetchApp.fetch(url,{muteHttpExceptions:true}),bytes=res.getBlob().getBytes();if(res.getResponseCode()!==200||String.fromCharCode(...bytes.slice(0,5))!=='%PDF-')throw Error('SH 공식 다운로드 PDF 검증 실패');const hash=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,bytes).map(b=>('0'+((b+256)%256).toString(16)).slice(-2)).join('');log.appendRow(['SH 실제 PDF 다운로드','통과',nowKst()+' | 311656:1 | '+bytes.length+' bytes | SHA256 '+hash]);
 for(const r of rows){if(!String(r[1]).startsWith('SH:'))continue;const f=String(r[2]).split(':');if(f.length!==3)continue;r[4]=SH_ORIGIN+'/main/com/file/innoFD.do?'+qs({brdId:f[0],seq:f[1],fileTp:'A',fileSeq:f[2]});r[17]=Number(r[16])>12000000?'별도처리':'자동점검';r[18]=Number(r[16])>12000000?'12MB 초과·외부 분석 필요':'';if(String(r[8]).startsWith('별도처리:'))r[8]='다운로드 해시 점검 대기';if(r[1]==='SH:311656'&&f[2]==='1'){r[5]=hash;r[6]=nowKst();r[7]=nowKst();r[8]='해시 확인·PDF 내용 원문 확인 필요';}}
 if(rows.length)s.getRange(2,1,rows.length,19).setValues(rows.map(r=>Array.from({length:19},(_,i)=>r[i]===undefined?'':r[i])));
 const ex=ss.getSheetByName('별도처리대상'),er=ex.getDataRange().getValues().slice(1);for(const r of er){if(String(r[1]).startsWith('SH:')&&/다운로드경로 미검증/.test(r[3])){r[7]='해결·공식 다운로드 경로 검증';r[5]=nowKst();}}if(er.length)ex.getRange(2,1,er.length,8).setValues(er);refreshMonitor(ss);console.log('SH_PDF_VERIFIED '+bytes.length+' '+hash);}

function suppressSHDerivedEventsV3(){const ss=SpreadsheetApp.openById(SPREADSHEET_ID),hs=ss.getSheetByName('정정이력').getDataRange().getValues(),derived=new Set();for(const h of hs){if(!String(h[0]).startsWith('SH:')||h[3]!=='수집내용 변경')continue;try{const a=JSON.parse(h[5]),b=JSON.parse(h[6]);if([2,5,25,26].every(i=>i===2?kstDayV3(a[i])===kstDayV3(b[i]):String(a[i]||'')===String(b[i]||'')))derived.add(h[10]);}catch(e){}}
 const q=ss.getSheetByName('발송대기'),rows=q.getDataRange().getValues().slice(1);let n=0;for(const r of rows){if(r[3]==='변경'&&derived.has(r[0])){r[7]='파생분류 보완';r[8]='N';r[9]='공식 제목/게시일/상태/URL 동일·원천변경 확인 전 차단';n++;}}if(rows.length)q.getRange(2,8,rows.length,3).setValues(rows.map(r=>[r[7]||'',r[8]||'',r[9]||'']));for(const sheet of ss.getSheets()){const c=sheet.getRange('A2');if(c.getValue()==='LH 1시간 자동수집 설치 완료 / 청약홈 인증키 대기. 수집범위·수집상태 탭 참조.')c.setValue('LH·청약홈·SH 공식 수집 운영. 최신 경로별 상태는 수집상태·수집감시 참조. 전국 전체수집 미완료.');}refreshMonitor(ss);ss.getSheetByName('개발검증').appendRow(['SH 파생분류 이벤트 발송차단','실제 보완',nowKst()+' | '+n+'건; 이력/이벤트 삭제 없음']);console.log('SH_DERIVED_SUPPRESSED '+n);}

// 3.5: no sender, no trigger creation. Same runCollection handler.
var TEXT_CACHE35=new Map();var SH_OFFICIAL35=null;var MASTER_CACHE35=null;var RAW_KEYS35=null;
function fetchText(url,options){const key=options?url+'|POST|'+qs(options.payload||{}):url;if(TEXT_CACHE35.has(key))return TEXT_CACHE35.get(key);return legacyFetch35(url,options);}
function prime3535V4(urls,deadline=Infinity){for(let i=0;i<urls.length;i+=5){if(Date.now()>deadline)return;const batch=urls.slice(i,i+5);try{const rs=UrlFetchApp.fetchAll(batch.map(url=>({url,muteHttpExceptions:true,followRedirects:true})));rs.forEach((r,k)=>{if(r.getResponseCode()===200)TEXT_CACHE35.set(batch[k],r.getContentText('UTF-8'));});}catch(e){/* each route retries independently; never mark success here */}}}
function classifyError(e){const t=safeError(e);return /인증키\s*미설정|API_AUTH|HTTP 401|API.*403/.test(t)?'API 인증 오류':/TIME_BUDGET|예산|제한시간|시간 초과|Timeout|timed out/i.test(t)?'수집 제한시간 초과':/PARSE|구조|파싱|스키마|표식|필터|식별자/.test(t)?'파싱 오류':/PARTIAL|불일치|누락|중간|상한|총건수 변경/.test(t)?'일부 누락 가능':'공식사이트 접근 실패';}
function health35(r,now){const normal=/^정상/.test(r[2]),last=Date.parse(stampV3(r[3]).replace(' ','T')+'+09:00'),attempt=Date.parse(stampV3(r[1]).replace(' ','T')+'+09:00');return {failure:!normal,stale:!Number.isFinite(last)||now-last>10800000,interrupted:r[2]==='시도중'&&(!Number.isFinite(attempt)||now-attempt>600000)};}
function refreshMonitor(ss,skipLegacyDerived=false){const props=PropertiesService.getScriptProperties(),rows=ss.getSheetByName('수집상태').getDataRange().getValues().slice(1).filter(r=>r[0]),s=ss.getSheetByName('수집감시'),now=Date.now();s.getRange(1,1,1,10).setValues([['수집경로','마지막 시도(KST)','마지막 정상(KST)','최근 결과','정상 후 경과(h)','현재 장애','미복구 시작(KST)','미복구 경과(h)','3시간 중단 감시','재시도 원인']]);const out=rows.map((r,i)=>{const h=health35(r,now),key='INCIDENT35_'+r[0];let since=props.getProperty(key)||'';if(h.failure&&!since){since=stampV3(r[1])||nowKst();props.setProperty(key,since);}if(!h.failure&&since){props.deleteProperty(key);since='';}const n=i+2;return [r[0],stampV3(r[1]),stampV3(r[3]),r[2],'=IF(C'+n+'="","",(NOW()-VALUE(C'+n+'))*24)',h.failure?(h.interrupted?'예약 실행 중단 또는 미실행':r[2]):'정상',since,'=IF(G'+n+'="","",MAX(0,(NOW()-VALUE(G'+n+'))*24))','=IF(C'+n+'="","경고: 정상 이력 없음",IF(E'+n+'>3,"경고: 3시간 초과","3시간 이내"))',h.failure?r[9]:''];});if(out.length)s.getRange(2,1,out.length,10).setValues(out);ss.setRecalculationInterval(SpreadsheetApp.RecalculationInterval.MINUTE);refreshDashboard(ss,skipLegacyDerived);}
function notificationV3(e,d,firstSeen,v3){const old=legacyNotification35(e,d,firstSeen,v3);if(e[7]==='초기백필')return ['초기백필','N','초기 대량 적재 차단 유지'];if(old[0]==='초기백필'||e[7]==='파생분류 보완'||!kstDayV3(e[2]))return old;if(e[3]!=='신규')return old;if(d&&/모집대상 제외|취소/.test(d[1]))return [e[7]||'신규발견','N','비주거·결과/취소 제외: 기록 보존'];if(e[7]==='실시간신규')return ['실시간신규','Y',d&&/접수중|접수예정/.test(d[1])?'신규 주거 모집공고·적합도/자격과 무관하게 알림 후보':'[신규 모집공고 · 접수기간 확인 필요]'];return old;}
function reconcileNotification35V4(ss,decisions){const s=ss.getSheetByName('발송대기'),rows=s.getDataRange().getValues().slice(1),master=ss.getSheetByName('공고원장').getDataRange().getValues().slice(4).filter(r=>r[0]),mi=new Map(master.map(r=>[r[0],r])),v3=PropertiesService.getScriptProperties().getProperty('V3_STARTED'),ids=new Set(rows.map(r=>r[1]));for(const m of master){if(String(m[0]).startsWith('HUG:ARCHIVE:'))continue;if(ids.has(m[0]))continue;const first=stampV3(m[1]),kind=first<v3?'초기백필':kstDayV3(m[2])>=kstDayV3(first)?'실시간신규':'신규발견·과거게시';rows.push([m[0]+':NOTICE_DISCOVERY',m[0],first,'신규','미발송','누락대조 복구·원래 최초발견시각 보존',m[26],kind,'N','재평가 대기']);}const followSheet=ss.getSheetByName('SH후속안내'),followTypes=new Map(followSheet?followSheet.getDataRange().getValues().slice(1).map(r=>[r[0],followupType35(r[1])]):[]);const derived=derivedEvents35(ss),pubs=new Map(ss.getSheetByName('SH게시판대조').getDataRange().getValues().slice(1).map(r=>['SH:'+r[5],kstDayV3(r[7])]));const seen=new Set();for(const r of rows){const m=mi.get(r[1]);if(String(r[1]).startsWith('HUG:ARCHIVE:')){r.splice(7,3,'HUG 과거자료','N','CSV 과거 기준선·신규 모집/전송 대상 아님');}else if(m){const policy=notificationV3(r,decisions.get(r[1]),m[1],v3);r.splice(7,3,...policy);}if(r[3]==='후속안내'&&['일반 안내','단순 결과'].includes(followTypes.get(r[1]))){r[7]='SH 일반/결과 안내';r[8]='N';r[9]='기존 계약자·재계약·랜선 집들이 또는 결과 안내: 신규 모집/중요 변경 알림 제외·기록 보존';}if(derived.has(r[0])&&r[7]!=='초기백필'){r[7]='파생분류 보완';r[8]='N';r[9]='공식 판단 핵심값 동일·내부 분류/경로 보완';}if(seen.has(r[0])){r[8]='N';r[9]='동일 이벤트ID 중복·기록 보존·전송 제외';}seen.add(r[0]);}if(rows.length){ensureRowsV4(s,rows.length+1);const old=s.getLastRow()-1;if(rows.length>old)s.getRange(old+2,1,rows.length-old,10).setValues(rows.slice(old).map(r=>r.slice(0,10)));s.getRange(2,8,rows.length,3).setValues(rows.map(r=>r.slice(7,10)));if(s.getMaxColumns()<14)s.insertColumnsAfter(s.getMaxColumns(),14-s.getMaxColumns());s.getRange(1,11,1,4).setValues([['최초발견시각(KST)','공식게시일','보류 감시','모집 세부유형']]);s.getRange(2,11,rows.length,4).setValues(rows.map(r=>{const m=mi.get(r[1]);return [m?stampV3(m[1]):'최초발견 미보존; 최초이벤트 '+stampV3(r[2]),m?kstDayV3(m[2]):pubs.get(r[1])||'',r[8]==='N'&&r[7]!=='초기백필'&&r[7]!=='파생분류 보완'&&r[7]!=='SH 일반/결과 안내'?(kstDayV3(r[2])<todayKst()?'장기 보류·원문 확인 필요':'명시적 보류·다음 실행 재평가'):'',m&&/정정공고|수정공고/.test(String(m[5]))?'공식 제목 정정공고':m&&/추가|재모집|재공급|무순위|잔여세대/.test(String(m[5]))?'추가모집·재공급·무순위·잔여세대':'일반 모집/후속'];}));}}
function refreshDashboard35V4(ss=SpreadsheetApp.openById(SPREADSHEET_ID)){legacyDashboard35(ss);prepareReminders35(ss);ss.getSheetByName('대시보드').getRange('A26').setValue('발송 비허용·보류 이벤트');const s=ss.getSheetByName('대시보드'),p=PropertiesService.getScriptProperties();s.getRange('B8').setFormula('="정상 "&COUNTIF(\'수집상태\'!C2:C,"정상*")&" / 전체 "&COUNTA(\'수집상태\'!A2:A)&" · 현재 장애 "&(COUNTIFS(\'수집상태\'!A2:A,"<>",\'수집상태\'!C2:C,"<>정상*",\'수집상태\'!C2:C,"<>시도중"))&" · 진행중 "&COUNTIF(\'수집상태\'!C2:C,"시도중")&" · 3시간 경고 "&COUNTIF(\'수집감시\'!I2:I,"경고*")');s.getRange('A35:B42').setValues([['전체 경로 / 실패·부분누락','=COUNTA(\'수집상태\'!A2:A)&" / "&(COUNTIFS(\'수집상태\'!A2:A,"<>",\'수집상태\'!C2:C,"<>정상*",\'수집상태\'!C2:C,"<>시도중"))'],['마지막 전체 정상 점검(KST)',p.getProperty('FULL_NORMAL35')||'3.5차 이후 전체 정상 점검 미완료'],['마지막 실행 시작(KST)',p.getProperty('RUN_STARTED35')||'미확인'],['마지막 실행 종료(KST)',p.getProperty('RUN_FINISHED35')||'미확인'],['전체 실행 중단 감시','=IF(B37="미확인","확인 필요",IF((NOW()-VALUE(B37))*24>3,"경고: 예약 실행 3시간 초과",IF(AND(B38<>"미확인",VALUE(B38)<VALUE(B37),(NOW()-VALUE(B37))*1440>10),"경고: 실행 중단 확인","최근 실행 있음")))'],['재시도/진행 경로·원인','=IFERROR(TEXTJOIN(CHAR(10),TRUE,FILTER(\'수집상태\'!A2:A&": "&\'수집상태\'!C2:C,\'수집상태\'!A2:A<>"",LEFT(\'수집상태\'!C2:C,2)<>"정상")),"없음")'],['접수 D-3 / D-1 · 중요만','=COUNTIFS(\'공고판정\'!C2:C,"★중요★",\'공고판정\'!F2:F,TEXT(TODAY()+3,"yyyy-mm-dd"))&" / "&COUNTIFS(\'공고판정\'!C2:C,"★중요★",\'공고판정\'!F2:F,TEXT(TODAY()+1,"yyyy-mm-dd"))'],['발송 정책','실시간 신규는 접수기간 미확인이어도 후보. 초기 백필 차단 유지. 외부 발송 없음']]);s.getRange('B40:B42').setWrap(true);s.getRange('A45:B46').setValues([['실제 시간트리거 마지막 시작',p.getProperty('SCHEDULED_STARTED35')||'3.5차 자동 실행 대기'],['시간트리거 미실행 감시','=IF(B45="3.5차 자동 실행 대기","자동 실행 검증 대기",IF((NOW()-VALUE(B45))*24>3,"경고: 예약 실행 3시간 초과","시간트리거 최근 실행"))']]);s.getRange('B19').setFormula('=IFERROR(SUM(\'상세작업\'!I2:I)/COUNTA(\'공고원장\'!A5:A),0)');}
function collectSH35(ss,cfg,to,deadline){const props=PropertiesService.getScriptProperties(),key='SH_PAGE35_'+cfg.id;let state;state=loadCheckpoint52A(props,key);if(!state||state.to!==to||state.from!==cfg.from)state={to,from:cfg.from,page:1,total:null,pages:null,ids:[],generation:nowKst()};const src={...cfg,agency:'SH',label:cfg.id,url:shUrl(cfg,1,to)};sourceAttempt(ss,src,to);while(state.page<=150){if(Date.now()>deadline){checkpoint42(props,key,state);throw Error('TIME_BUDGET: SH '+shProgress42(props,key));}if(state.page>1&&!TEXT_CACHE35.has(shUrl(cfg,state.page,to)))prime35(Array.from({length:Math.min(5,Math.max(1,(state.pages||state.page)-state.page+1))},(_,i)=>shUrl(cfg,state.page+i,to)),deadline);const requestUrl=shUrl(cfg,state.page,to),html=fetchText(requestUrl);let x;try{x=parseSHList(html);}catch(error){console.log('SH_PARSE_DIAG42A3 '+JSON.stringify(shResponseShape42A3(html,requestUrl)));if((state.page>1&&String(error&&error.message||error).includes('PARSE: SH 목록 행 추출 0건'))||String(error&&error.message||error).startsWith('PARTIAL: SH 페이지 범위 초과 ')){clearCheckpoint52A(props,key);throw Error('PARTIAL: SH 비어있는 후속 페이지·기존 원장/정상시각 보존·다음 실행 1페이지부터 재대조');}throw error;}if(x.page!==state.page||!shDateFilter35(html,cfg.from))throw Error('PARSE: SH 페이지/조회기간 미반영');if(state.total!==null&&(state.total!==x.total||state.pages!==x.pages)){clearCheckpoint52A(props,key);throw Error('PARTIAL: SH 총건수 변경·다음 실행 처음부터 재대조');}if(state.total===null){state.total=x.total;state.pages=x.pages;const urls=[];for(let n=state.page+1;n<=Math.min(x.pages,150);n++)urls.push(shUrl(cfg,n,to));prime35(urls,deadline);}const rr=[...new Map(x.records.concat(x.pinned).map(r=>[r.seq,r])).values()],audit=rr.map(r=>{const c=shDisposition(r.title);return [cfg.id+':'+r.seq,cfg.id,nowKst(),x.total,x.pages,r.seq,r.title,r.published,c[0],(r.pinned?'고정공지 별도; ':'')+c[1],normalizeSH(r,cfg.id).url];});upsertSHMachineAudit(ss.getSheetByName('SH게시판대조'),audit);const records=rr.filter(r=>shDisposition(r.title)[0]==='수집'||resultNotice52A(r.title)&&noticeKind52A(r.title)==='EXCLUDED').map(r=>normalizeSH(r,cfg.id));const changed=changedSH35(ss,records);const newlyFound=changed.filter(r=>!SH_OFFICIAL35.has(r.id)&&noticeKind52A(r.title)!=='EXCLUDED').length;state.discovered=Number(state.discovered||0)+newlyFound;state.changed=Number(state.changed||0)+changed.filter(r=>SH_OFFICIAL35.has(r.id)&&noticeKind52A(r.title)!=='EXCLUDED').length;state.resultEvidence=Number(state.resultEvidence||0)+changed.filter(r=>resultNotice52A(r.title)&&noticeKind52A(r.title)==='EXCLUDED').length;if(changed.length){const st=ss.getSheetByName('수집상태'),at=st.getDataRange().getValues().findIndex(r=>r[0]===cfg.id),last=st.getRange(at+1,4).getValue();saveResult(ss,{...src,partial35:true},changed,null,to);st.getRange(at+1,3,1,2).setValues([['일부 누락 가능',last]]);st.getRange(at+1,7).setValue('');classifyNew35(ss,changed);for(const r of changed){SH_OFFICIAL35.set(r.id,shOfficial35(JSON.parse(r.raw)));}}
state.ids.push(...x.records.map(r=>r.seq));state.page++;checkpoint42(props,key,state);if(state.page>x.pages||x.total===0){if(state.ids.length!==x.total||new Set(state.ids).size!==x.total){clearCheckpoint52A(props,key);throw Error('PARTIAL: SH 전체 행/고유ID 불일치');}sourceFinish(ss,src,[],null,to);const s=ss.getSheetByName('수집상태'),at=s.getDataRange().getValues().findIndex(r=>r[0]===cfg.id);s.getRange(at+1,7).setValue(x.total);if(state.discovered)s.getRange(at+1,3).setValue('정상·신규 발견');s.getRange(at+1,10).setValue('전체대조 완료; 이번 순환 신규 '+Number(state.discovered||0)+'건; 상세/첨부 별도');s.getRange(at+1,10).setValue('이번 순환 신규 '+Number(state.discovered||0)+'/변경 '+Number(state.changed||0)+'; 전체 '+x.total+'행/고유seq 대조 완료; 기간 '+cfg.from+'~'+to+'; PDF/과거 전기간/별도청약 미검증');clearCheckpoint52A(props,key);return;}}throw Error('PARTIAL: SH 페이지 상한');}
function classifyNew35V4(ss,records){const q=ss.getSheetByName('발송대기'),rows=q.getDataRange().getValues().slice(1),base=PropertiesService.getScriptProperties().getProperty('V3_STARTED'),map=new Map(records.map(r=>[r.id,r]));let changed=false;for(const e of rows){if(!map.has(e[1])||e[7])continue;const r=map.get(e[1]);e[7]=e[3]!=='신규'?'중요변경 후보':stampV3(e[2])<base?'초기백필':r.published>=todayKst()?'실시간신규':'신규발견·과거게시';[e[8],e[9]]=seedPolicy35(e[7],e[3]!=='신규');changed=true;}if(changed)q.getRange(2,8,rows.length,3).setValues(rows.map(r=>[r[7]||'',r[8]||'',r[9]||'']));}
function sources35(to,key){return ['lease','sale'].flatMap(k=>[{id:'LH_'+k,agency:'LH청약플러스',label:k+' 최근',url:lhUrl(k,1,to),run:()=>collectLh(k,to,fetchText)},{id:'LH_'+k+'_active',agency:'LH청약플러스',label:k+' 공고중',from:'2000-01-01',url:activeUrl(k,1,to),run:()=>collectActive(k,to)}]).concat(APPLY_ENDPOINTS.map(e=>({id:e,agency:'청약홈',label:e,url:'https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/'+e,run:()=>collectApply(e,to,key,fetchText)})),[1,2,5].map(branch=>({id:'LH_FIRSTCOME_'+branch,agency:'LH청약플러스',label:'수의계약 '+branch,url:'https://apply.lh.or.kr/lhapply/apply/bor_ctrt_psb_dst/'+branch+'/lfn_getTabChange.do?mi='+({1:'201526',2:'201529',5:'1201802'})[branch],branch})));}
function runCollection35V4(e){const lock=LockService.getScriptLock();if(!lock.tryLock(1000)){lockMiss52A('목록');return;}const started=Date.now(),props=PropertiesService.getScriptProperties();props.setProperty('RUN_STARTED35',nowKst());if(e&&e.triggerUid)props.setProperty('SCHEDULED_STARTED35',nowKst());try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID);ss.getSheetByName('대시보드').getRange('B37').setValue(props.getProperty('RUN_STARTED35'));if(e&&e.triggerUid)ss.getSheetByName('대시보드').getRange('B45').setValue(props.getProperty('SCHEDULED_STARTED35'));supportV2(ss);supportV3(ss);const to=todayKst(),key=props.getProperty('APPLYHOME_SERVICE_KEY'),sources=sources35(to,key),urls=sources.filter(s=>!s.id.startsWith('get')).map(s=>s.url).concat(APPLY_ENDPOINTS.flatMap(e=>{const base='https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/'+e;return [base+'?'+qs({page:1,perPage:1,serviceKey:key}),base+'?'+qs({page:1,perPage:100,serviceKey:key,'cond[RCRIT_PBLANC_DE::GTE]':INITIAL_FROM.replace(/-/g,''),'cond[RCRIT_PBLANC_DE::LTE]':to.replace(/-/g,'')})];}));prime35(urls);
const previous=new Map(ss.getSheetByName('수집상태').getDataRange().getValues().slice(1).map(r=>[r[0],r]));sources.sort((a,b)=>Number(/^정상/.test((previous.get(a.id)||[])[2]))-Number(/^정상/.test((previous.get(b.id)||[])[2])));for(const src of sources){sourceAttempt(ss,src,to);try{if(Date.now()-started>170000)throw Error('TIME_BUDGET: LH/API 다음 실행 재시도');if(src.branch){const p=parseFirstCome(fetchText(src.url),src.branch);upsertTable(ss.getSheetByName('수의계약점검'),p.rows.map((r,i)=>[src.branch+':'+i,nowKst(),src.branch,r.region,r.district,r.block,r.area,r.unsold,r.priceThousand,r.contact,r.note,src.url,'재고표시 행']));sourceFinish(ss,src,[],null,to);const state=ss.getSheetByName('수집상태'),at=state.getDataRange().getValues().findIndex(r=>r[0]===src.id);state.getRange(at+1,7).setValue(p.total);}else sourceFinish(ss,src,src.run(),null,to);}catch(e){sourceFinish(ss,src,[],safeError(e),to);}}
prime35(SH_ROUTES.map(c=>shUrl(c,1,to)));const sh=[...SH_ROUTES].sort((a,b)=>Number(/^정상/.test((previous.get(a.id)||[])[2]))-Number(/^정상/.test((previous.get(b.id)||[])[2])));for(const cfg of sh){try{collectSH35(ss,cfg,to,started+235000);}catch(e){sourceFinish(ss,{...cfg,agency:'SH',label:cfg.id,url:shUrl(cfg,1,to)},[],safeError(e),to);}}
if(Date.now()-started<220000)processFollowups35(ss,2);if(Date.now()-started<245000)processDetailJobs(ss,Date.now()-190000);if(Date.now()-started<270000)processAttachmentJob(ss);const states=ss.getSheetByName('수집상태').getDataRange().getValues().slice(1).filter(r=>r[0]);if(states.length===18&&states.every(r=>/^정상/.test(r[2])&&stampV3(r[1])>=props.getProperty('RUN_STARTED35')))props.setProperty('FULL_NORMAL35',nowKst());refreshMonitor(ss);ss.getSheetByName('개발검증').appendRow(['3.5 실행','실제 운영',nowKst()+' | '+((Date.now()-started)/1000).toFixed(3)+'초 | 정상 '+states.filter(r=>/^정상/.test(r[2])).length+'/18']);props.setProperty('RUN_FINISHED35',nowKst());ss.getSheetByName('대시보드').getRange('B38').setValue(props.getProperty('RUN_FINISHED35'));console.log('V35_FINISHED '+((Date.now()-started)/1000).toFixed(3)+' seconds');}finally{TEXT_CACHE35.clear();SH_OFFICIAL35=null;MASTER_CACHE35=null;RAW_KEYS35=null;lock.releaseLock();}}
function installV35(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 실행중');try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID);supportV3(ss);ss.getSheetByName('중요공고').getRange('A5').setFormula(importanceFormulaV3('접수중|접수예정'));refreshMonitor(ss);ss.getSheetByName('시스템설정').getRange('A2').setValue('3.5차: 현재 장애/3시간 경고 분리·실시간 신규 기간 미확인 후보 유지·단일 시간트리거 유지');ss.getSheetByName('시스템설정').getRange('B11').setValue('LH·청약홈·SH 1시간 자동수집 활성');ss.getSheetByName('수집범위').getRange('D3').setValue('LH 공식 목록/공고중 대조·최신 경로별 수집상태 참조');ss.getSheetByName('수집범위').getRange('A7:F7').setValues([['SH','주택임대·분양·매입·입주안내·전체모집·최근전체','공식 6개 경로·SH 후속안내 순환','설정기간 총행/고유seq 대조','2025년 이전 원모집·별도 인터넷청약·PDF 조건 미검증','https://www.i-sh.co.kr/']]);ss.getSheetByName('수집범위').getRange('A11:F11').setValues([['추가 기관','GH·HUG·청년안심주택','후속 단계','이번 미수집','전국 전체수집 미완료','GH는 4차 개발']]);ss.getSheetByName('개발검증').appendRow(['3.5 설치','실제 운영',nowKst()+' | 트리거 생성/재설치 없음']);console.log('V35_INSTALLED');}finally{lock.releaseLock();}}
function mockBundle35(){const ss=SpreadsheetApp.openById(SPREADSHEET_ID),rows=ss.getSheetByName('발송대기').getDataRange().getValues().slice(1),unique=new Map();for(const e of rows)if(e[8]==='Y'&&e[4]==='미발송'&&!unique.has(e[0]))unique.set(e[0],e);const entries=[...unique.values()].map(e=>'['+e[7]+'] '+e[1]+' | '+e[9]+' | '+e[6]);ss.getSheetByName('개발검증').appendRow(['모의 묶음 알림·외부 발송 없음',entries.length,nowKst()+' | 이벤트ID 중복 제거 | '+entries.join('\n').slice(0,45000)]);console.log('MOCK_ONLY '+entries.length);}
function probeFollowup35(){const ss=SpreadsheetApp.openById(SPREADSHEET_ID);let s=ss.getSheetByName('SH후속안내');if(!s){s=ss.insertSheet('SH후속안내');s.appendRow(['후속ID','제목','분류','원모집ID','연결근거','확인시각','원문본문','원문URL','변경전','변경후','상태']);}for(const id of ['311484','311651','311656']){const url=SH_ORIGIN+'/main/lay2/program/S1T294C295/www/brd/m_241/view.do?seq='+id;try{const html=fetchText(url),d=parseSHDetail(html,{id:'SH:'+id,number:id,published:'2026-10-19',url}),title=textOf((html.match(/<th[^>]*class=["'][^"']*title[^"']*["'][^>]*>([\s\S]*?)<\/th>/i)||[])[1]||'원문 제목 확인 필요');upsertTable(s,[['SH:'+id,title,id==='311484'?'중요 정정':id==='311651'?'중요 안내':'연결용 원 모집','','원문 확인 후 연결 판정',nowKst(),d.bodyEvidence,url,'원문 확인 필요','원문 확인 필요','연결 검토']]);}catch(e){ss.getSheetByName('처리오류이력').appendRow([nowKst(),'SH 후속','SH:'+id,'원문 접근 실패','','',safeError(e)]);}}}
function sourceFinish(ss,src,records,error,to){if(error&&src.agency==='청약홈'&&/HTTP (401|403)|인증키\s*미설정/.test(String(error)))error='API_AUTH: '+error;const props=PropertiesService.getScriptProperties(),incident='INCIDENT35_'+src.id;const before=props.getProperty(incident);if(error||unchanged35(ss,records))finishUnchanged35(ss,src,records,error,to);else{legacySourceFinish35(ss,src,records,error,to);MASTER_CACHE35=null;}if(error&&!before)props.setProperty(incident,nowKst());if(!error&&before){ss.getSheetByName('처리오류이력').appendRow([nowKst(),'수집경로',src.id,'복구',before,'','이전 장애 이후 전체 경로 재검증 정상']);props.deleteProperty(incident);}}
function followupType35(title){if(resultNotice52A(title))return noticeKind52A(title)==='EXCLUDED'?'단순 결과':'연결 불명';if(/계약자.*입주안내|재계약.*(?:대상|심사|서류)|랜선\s*집들이/.test(title))return '일반 안내';if(/당첨자|경쟁률|선정결과|계약결과|접수결과|대상자.*발표/.test(title)&&!/추가접수|2순위.*접수|일정.*변경|자격.*완화/.test(title))return '단순 결과';if(/채용|입찰|감리|시스템|점검|상가|운영기관|매도신청/.test(title))return '일반 안내';if(/일정.*변경|기간.*변경|연장|자격.*완화|정정|공급.*변경|가격.*변경/.test(title))return '중요 정정';if(/분양가격|건물분양가격|공급가격|주택.*공개|계약.*안내|예비자.*공급/.test(title))return '중요 안내';return '연결 불명';}
function followupLink35(text,url,master,published){const refs=[...String(text).matchAll(/(?:seq=|공고번호\s*[:：]?\s*)(\d{5,8})/g)].map(m=>'SH:'+m[1]),found=master.filter(r=>refs.includes(r[0])&&!url.includes('seq='+String(r[0]).split(':')[1]));if(found.length===1)return {id:found[0][0],proof:'공식 원문에서 원 공고 seq/공고번호 직접 참조 확인',status:'연결 확인'};const complex=(text.match(/고덕강일(?:지구)?\s*3\s*단지/)||[])[0];if(complex){const candidates=master.filter(r=>/고덕강일(?:지구)?\s*3\s*단지/.test(r[5]));if(candidates.length===1&&published&&kstDayV3(candidates[0][2])===kstDayV3(published)&&/토지임대부\s*분양주택/.test(text)&&/토지임대부\s*분양주택/.test(candidates[0][5]))return {id:candidates[0][0],proof:'공식 본문 고덕강일지구3단지·토지임대부 분양 사업 명시 + 원모집 공식게시일 '+kstDayV3(published)+' 일치 + 해당 사업 원모집 고유ID 1건 확인. 가격 수치/변경 전후는 미확인',status:'연결 확인·동일사업/게시일 근거'};if(candidates.length===1)return {id:candidates[0][0],proof:'동일 단지와 토지임대부 분양 사업 후보; 직접 원공고 참조 확인 전 확정 금지',status:'연결 후보·원문 확인 필요'};}return {id:'',proof:'제목 유사성만으로 연결 확정하지 않음. 원 공고번호/모집차수·게시일 원문 확인 필요',status:'연결 불명·중요 변경 검토 유지'};}
function processFollowups35(ss,limit=2){let s=ss.getSheetByName('SH후속안내');if(!s){s=ss.insertSheet('SH후속안내');s.getRange(1,1,1,11).setValues([['후속ID','제목','분류','원모집ID','연결근거','확인시각','원문본문','원문URL','변경전','변경후','상태']]);s.setFrozenRows(1);}const master=ss.getSheetByName('공고원장').getDataRange().getValues().slice(4).filter(r=>r[0]),all=ss.getSheetByName('SH게시판대조').getDataRange().getValues().slice(1).filter(r=>r[8]==='별도검토'),candidates=[...new Map(all.map(r=>['SH:'+r[5],r])).values()],existing=new Map(s.getDataRange().getValues().slice(1).map(r=>[r[0],r])),p=PropertiesService.getScriptProperties();let cursor=Number(p.getProperty('FOLLOWUP_CURSOR35')||0)%Math.max(1,candidates.length);const corrections=candidates.filter(r=>existing.has('SH:'+r[5])&&existing.get('SH:'+r[5])[2]!==followupType35(r[6])).map(r=>{const v=existing.get('SH:'+r[5]).slice(0,11);v[2]=followupType35(r[6]);existing.set(v[0],v);return v;});upsertTable(s,corrections);upsertTable(s,candidates.filter(r=>!existing.has('SH:'+r[5])).map(r=>['SH:'+r[5],r[6],followupType35(r[6]),'','원 공고 연결 미검증',nowKst(),'원문 확인 필요',r[10],'원문 확인 필요','원문 확인 필요','원문 분석 대기']));const priority=candidates.filter(r=>followupPriority35(r,existing)).sort((a,b)=>kstDayV3(b[7]).localeCompare(kstDayV3(a[7])));const used=new Set();for(let n=0;n<limit&&candidates.length;n++){let r;if(priority.length&&Number(p.getProperty('FOLLOWUP_TURN52A')||0)%4!==3){r=priority.shift();}else{let scanned=0;do{r=candidates[cursor];cursor=(cursor+1)%candidates.length;scanned++;}while(used.has('SH:'+r[5])&&scanned<candidates.length);p.setProperty('FOLLOWUP_CURSOR35',String(cursor));}if(used.has('SH:'+r[5]))continue;used.add('SH:'+r[5]);p.setProperty('FOLLOWUP_TURN52A',String(Number(p.getProperty('FOLLOWUP_TURN52A')||0)+1));const id='SH:'+r[5],kind=followupType35(r[6]);let body='',link={id:'',proof:'모집 판단 영향 낮음 또는 결과 안내',status:'분류·기록 보존'};try{if(kind!=='단순 결과'&&kind!=='일반 안내'){const html=fetchText(r[10]),d=parseSHDetail(html,{id,number:String(r[5]),published:kstDayV3(r[7]),url:r[10]});body=d.bodyEvidence;const bodyHTML=(html.match(/<td\b[^>]*class=["'][^"']*\bcont\b[^"']*["'][^>]*>([\s\S]*?)<\/td>/i)||[])[1]||'';const hrefs=[...bodyHTML.matchAll(/href=["']([^"']*(?:seq=\d+)[^"']*)["']/g)].map(m=>m[1]).join('\n');link=followupLink35(body+'\n'+hrefs,r[10],master,r[7]);saveSHAttachments(ss,{id},d);}const previous=existing.get(id),hash=digest(JSON.stringify([r[6],kind,body])),key=id+':FOLLOWUP:'+hash;upsertTable(s,[[id,r[6],kind,link.id,link.proof,nowKst(),body||'원문 확인 필요',r[10],previous&&previous[6]!==body?String(previous[6]).slice(0,18000):'원문 확인 필요',body||'원문 확인 필요',link.status]]);if(kind==='중요 정정'||kind==='중요 안내'){const q=ss.getSheetByName('발송대기');const priorEvent=q.getDataRange().getValues().findIndex(e=>e[0]===key);if(priorEvent>=1)q.getRange(priorEvent+1,8,1,3).setValues([[kind,'Y','공식 후속안내·변경내용/신청자격 확정 아님. '+link.proof]]);else q.appendRow([key,id,nowKst(),'후속안내','미발송',kind+' · '+link.status,r[10],kind,'Y','공식 후속안내·변경내용/신청자격 확정 아님. '+link.proof]);if(previous&&previous[6]&&previous[6]!=='원문 확인 필요'&&previous[6]!==body)upsertTable(ss.getSheetByName('정정이력'),[[id,nowKst(),r[7],'SH 후속안내 변경','후속 원문',previous[6],body,'원문 확인 필요',r[10],link.status,key]],10);}existing.set(id,[id,r[6],kind,link.id,link.proof,nowKst(),body]);}catch(e){ss.getSheetByName('처리오류이력').appendRow([nowKst(),'SH 후속안내',id,'원문 접근/파싱 실패','','다음 순환',safeError(e)]);upsertTable(s,[[id,r[6],kind,'','원문 접근 실패·연결 미확인',nowKst(),'원문 확인 필요',r[10],'원문 확인 필요','원문 확인 필요','재시도 필요']]);}}ss.getSheetByName('대시보드').getRange('A43:B44').setValues([['SH 별도검토 고유 공고',candidates.length],['SH 후속 관리 레코드·분석완료 아님',s.getLastRow()-1]]);const fr=s.getDataRange().getValues().slice(1);ss.getSheetByName('대시보드').getRange('A47:B49').setValues([['SH 후속 원문 본문 확인',fr.filter(r=>r[6]&&r[6]!=='원문 확인 필요').length],['중요 후속 원문 대기',fr.filter(r=>/^중요/.test(r[2])&&(!r[6]||r[6]==='원문 확인 필요')).length],['중요 후속 연결 추가검토',fr.filter(r=>/^중요/.test(r[2])&&!/^연결 확인/.test(r[10])).length]]);}
function verifyFollowups35(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 실행중');try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID);processFollowups35(ss,5);refreshMonitor(ss);mockBundle35();}finally{lock.releaseLock();}}

function shOfficial35(x){return JSON.stringify([String(x.seq),x.title,x.published,x.department||'']);}
function changedSH35(ss,records){if(!SH_OFFICIAL35){SH_OFFICIAL35=new Map();const raw=new Map(ss.getSheetByName('수집원본').getDataRange().getValues().slice(1).map(r=>[r[0],r]));RAW_KEYS35=new Set(raw.keys());for(const m of ss.getSheetByName('공고원장').getDataRange().getValues().slice(4)){if(!String(m[0]).startsWith('SH:'))continue;try{SH_OFFICIAL35.set(m[0],shOfficial35(JSON.parse(raw.get(m[38])[5])));}catch(e){}}}return records.filter(r=>!(resultNotice52A(r.title)&&noticeKind52A(r.title)==='EXCLUDED'&&RAW_KEYS35&&RAW_KEYS35.has(r.id+':RESULT:'+digest(semantic(r))))&&SH_OFFICIAL35.get(r.id)!==shOfficial35(JSON.parse(r.raw)));}
function prepareReminders35(ss){const rows=ss.getSheetByName('공고판정').getDataRange().getValues().slice(1),q=ss.getSheetByName('발송대기'),keys=new Set(q.getDataRange().getValues().slice(1).map(r=>r[0])),today=Date.parse(todayKst()+'T00:00:00Z');for(const r of rows){if(r[2]!=='★중요★'||!['접수중','접수예정'].includes(r[1])||!kstDayV3(r[5]))continue;const end=kstDayV3(r[5]),days=Math.round((Date.parse(end+'T00:00:00Z')-today)/86400000);if(![1,3].includes(days))continue;const key=r[0]+':DEADLINE:'+end+':D'+days;if(keys.has(key))continue;q.appendRow([key,r[0],nowKst(),'마감 D-'+days,'미발송','공식 확인된 마감일 '+end+' · 정확한 마감시각 원문 확인 필요',r[11],'마감 리마인더','Y','유효 중요공고 D-'+days+' · 외부 발송 없음']);keys.add(key);}}
function importanceFormulaV3(states){return legacyImportanceFormula35(states).replace('=IFERROR(FILTER(','=IFERROR(SORT(FILTER(').replace('),"해당 공고 없음")','),11,FALSE,7,TRUE),"해당 공고 없음")');}

function derivedEvents35(ss){const out=new Set();for(const h of ss.getSheetByName('정정이력').getDataRange().getValues().slice(4)){if(h[3]!=='수집내용 변경')continue;try{const a=JSON.parse(h[5]),b=JSON.parse(h[6]);if([2,5,14,15,16,17,18,19,23,25,26].every(i=>i===2||[17,18,19].includes(i)?kstDayV3(a[i])===kstDayV3(b[i]):String(a[i]||'')===String(b[i]||'')))out.add(h[10]);}catch(e){}}return out;}

function unchanged35(ss,records){if(!records.length)return true;if(!MASTER_CACHE35){const rows=ss.getSheetByName('공고원장').getDataRange().getValues().slice(4).filter(r=>r[0]);MASTER_CACHE35=new Map(rows.map(r=>[r[0],r]));if(MASTER_CACHE35.size!==rows.length)throw Error('PARSE: 기존 공고ID 중복');RAW_KEYS35=new Set(ss.getSheetByName('수집원본').getDataRange().getValues().slice(1).map(r=>r[0]));}return records.every(r=>{if(resultNotice52A(r.title)&&noticeKind52A(r.title)==='EXCLUDED')return RAW_KEYS35.has(r.id+':RESULT:'+digest(semantic(r)))||!!(MASTER_CACHE35.get(r.id)&&MASTER_CACHE35.get(r.id)[36]===digest(semantic(r))&&RAW_KEYS35.has(MASTER_CACHE35.get(r.id)[38]));if(/가정어린이집|상가|토지/.test(r.type)||/당첨자발표|선정결과발표|신청현황/.test(r.title))return RAW_KEYS35.has(r.id);const old=MASTER_CACHE35.get(r.id);return old&&old[36]===digest(semantic(r));});}
function finishUnchanged35(ss,src,records,error,to){const now=nowKst(),state=ss.getSheetByName('수집상태'),data=state.getDataRange().getValues();let at=data.findIndex(r=>r[0]===src.id);if(at<1)at=data.length;const old=data[at]||[],status=error?classifyError(error):'정상·신규 0건';state.getRange(at+1,1,1,10).setValues([[src.id,now,status,error?old[3]||'':now,src.from||INITIAL_FROM,to,error?'':records.length,old[7]||0,old[8]||0,error||'공식 목록 동일·고유ID/내용해시 대조; 상세/첨부 미검증']]);ss.getSheetByName('기관점검').appendRow([now.slice(0,10),now.slice(11),src.agency,src.label,src.url,'자동수집 / '+src.id,src.from||INITIAL_FROM,to,status,error?'':records.length,error?'':0,error?'':0,error||'공식 원천 동일·내부 분류와 분리',to,'이력/발송대기/사용자 셀 보존']);if(!error)PropertiesService.getScriptProperties().setProperty('BASELINE_'+src.id,to);}

function seedPolicy35(kind,changed){if(kind==='초기백필')return ['N','초기 백필 차단 유지'];if(changed)return ['Y','원천 변경 후보·공식 정정 여부 원문 확인 필요'];if(kind==='실시간신규')return ['Y','[신규 모집공고 · 접수기간 확인 필요]'];return ['N','과거 신규발견·접수기간 미확인 명시적 보류·다음 실행 재평가'];}
function shDateFilter35(html,from){return new RegExp(`name=["']srchFr["'][^>]*value=["']${from}["']|value=["']${from}["'][^>]*name=["']srchFr["']`).test(html);}

function followupPriority35(row,existing){const old=existing.get('SH:'+row[5]);return /^중요/.test(followupType35(row[6]))&&(!old||!old[6]||old[6]==='원문 확인 필요');}

// Phase 4: regional policy, independent enrichment worker, bounded budgets.
// No notification transport. No secret values are written into sheets or logs.
var V4_GH_WORK=false,V4_MODE='',V4_ROUTE='',V4_HTTP=[],V4_SHEETS=[],V4_STAGE=[],V4_END=Infinity;
function regionV4(row,detail){
 if(String(row[0]||'').startsWith('HUG:ARCHIVE:'))return {group:'과거 참고자료',eligible:false,reason:'HUG CSV 과거 기준선·신규 모집공고 아님',priority:0};
 // An address must be supplied by an adapter as housing supply data, never applicant residency.
 const address=String(detail&&detail.address||'').trim(),region=String(detail&&detail._supplyRegion!==undefined?detail._supplyRegion:/^GH:(?:WEB|NOTICE):/.test(String(row[0]))&&String(row[8]||'').trim()==='경기도'?'':row[8]||'').trim();
 const a=supplyGeo52A(address),r=supplyGeo52A(region),geo=a.known?a:r;
 if(geo.target)return {group:geo.other||geo.open?'서울·경기 포함/복수':'서울·경기',eligible:true,reason:a.known?'공식 공급 소재지 근거':'공식 목록 공급지역 근거·제목 언급 제외',priority:95};
 if(geo.other&&!geo.open)return {group:'서울·경기 외',eligible:false,reason:'공식 공급 소재지/지역에 타지역만 확인·기록 보존',priority:0};
 return {group:'지역 확인 필요',reviewGroup:String(row[0]).startsWith('SH:')?'서울권 잠정후보/주소확인':'공급소재지 확인',eligible:true,reason:'공급 소재지 미확인·제목/신청자 거주지로 추정하지 않음·맞춤 알림 보류',priority:85};
}
function notificationRegionV4(event,row,policy,detail){
 if(['발송완료','발송 완료'].includes(event[4]))return policy;
 const geo=regionV4(row,detail);
 if(!geo.eligible||geo.group==='지역 확인 필요')return [policy[0],'N','5.2-A: '+geo.reason];
 return policy;
}
function readV4(sheet){const t=Date.now();try{return sheet.getDataRange().getValues();}finally{V4_SHEETS.push(['read',sheet.getName(),Date.now()-t]);}}
function measureV4(name,fn){const t=Date.now();if(V4_MODE==='후처리')PropertiesService.getScriptProperties().setProperty('WORKER_STAGE4',name);try{return fn();}finally{V4_STAGE.push([name,Date.now()-t]);if(V4_MODE==='후처리'){PropertiesService.getScriptProperties().setProperty('WORKER_STAGE_TIMES4',JSON.stringify(V4_STAGE.slice(-20)));console.log('STAGE4 '+name+' '+(Date.now()-t)+'ms');}}}
function ensureV4(ss){
 const defs={'지역정책':['공고ID','지역 분류','처리허용','상세 우선점수','판단근거','공식 지역','단지/주소 확인','최초발견','공식게시일','정책 갱신(KST)'],
 '실행계측':['실행ID','역할','단계/작업','경로/대상','소요(ms)','시각(KST)','결과/계측범위'],
 '작업운영':['작업','마지막 시도','마지막 정상','상태','다음 처리 위치/근거','마지막 자동시도']};
 for(const n of Object.keys(defs))if(!ss.getSheetByName(n)){const s=ss.insertSheet(n);s.getRange(1,1,1,defs[n].length).setValues([defs[n]]);s.setFrozenRows(1);}
}
function policyRowsV4(master,details,now){const dm=new Map(details.map(d=>[d[0],d]));return master.filter(m=>m[0]).map(m=>{let d;try{d=JSON.parse((dm.get(m[0])||[])[16]||'null');}catch(e){}const x=regionV4(m,d);return [m[0],x.group,x.eligible?'Y':'N',x.priority,x.reason,m[8]||'',d&&d.address||'원문 확인 필요',stampV3(m[1]),kstDayV3(m[2]),now];});}
function refreshRegionV4(ss){
 const master=readRows52A(ss,'공고원장',5,40).filter(r=>r[0]),dm=new Map(readRows52A(ss,'공고상세',2,23).map(r=>[r[0],r])),raw=new Map(readRows52A(ss,'수집원본',2,6).map(r=>[r[0],r])),now=nowKst();
 const rows=master.map(m=>{let d=null;try{d=JSON.parse((dm.get(m[0])||[])[16]||'null');}catch(_){}d=supplyDetail52A(m,d,raw);const g=regionV4(m,d);return [m[0],g.group,g.eligible?'Y':'N',g.priority,g.reason,m[8]||'',d.address||'원문 확인 필요',stampV3(m[1]),kstDayV3(m[2]),now];});
 const s=ss.getSheetByName('지역정책');ensureRowsV4(s,rows.length+1);if(rows.length)writeChangedRows42A(s,2,1,rows,true);return rows;
}
function reconcileNotificationV3(ss,decisions){return queuePolicyView52A(ss,v=>{reconcileNotification35V4(v,decisions);const s=v.getSheetByName('발송대기'),rows=readV4(s).slice(1),master=new Map(readV4(v.getSheetByName('공고원장')).slice(4).map(r=>[r[0],r]));if(rows.length)s.getRange(2,8,rows.length,3).setValues(rows.map(e=>master.has(e[1])?notificationRegionV4(e,master.get(e[1]),e.slice(7,10)):e.slice(7,10)));filterConfirmedAliasesV4(v);protectGHFollowupsV4(v);reconcileGHChangesV4(v);protectDetailEvents42A(v);finalQueueGuard52A(v);});}
function classifyNew35(ss,records){classifyNew35V4(ss,records);const s=ss.getSheetByName('발송대기'),rows=readV4(s).slice(1),rm=new Map(records.map(r=>{const m=Array(40).fill('');m[0]=r.id;m[5]=r.title;m[8]=r.region;return[r.id,m];}));if(rows.length&&records.length)s.getRange(2,8,rows.length,3).setValues(rows.map(e=>rm.has(e[1])?['EXCLUDED','REVIEW'].includes(noticeKind52A(rm.get(e[1])[5]))?[e[7],'N','공통 결과/혼합 공지·주거 모집 근거 확인 필요']:notificationRegionV4(e,rm.get(e[1]),e.slice(7,10)):e.slice(7,10)));}
function legacyFetch35(url,options){
 const t=Date.now();let status='실패';if(V4_MODE==='후처리')PropertiesService.getScriptProperties().setProperty('WORKER_HTTP4',JSON.stringify({at:nowKst(),stage:V4_ROUTE,url:url.replace(/([?&]serviceKey=)[^&]*/gi,'$1[비공개]')}));try{let res=UrlFetchApp.fetch(url,{...options,muteHttpExceptions:true,followRedirects:true});if([429,500,502,503,504].includes(res.getResponseCode())&&Date.now()+10000<V4_END){res=UrlFetchApp.fetch(url,{...options,muteHttpExceptions:true,followRedirects:true});status='제한 재시도 ';}const code=res.getResponseCode();status=(code===200?'정상 ':'실패 ')+(status==='제한 재시도 '?'제한 재시도 ':'')+'HTTP '+code;if(code!==200)throw Error('HTTP '+code);const text=res.getContentText('UTF-8');TEXT_CACHE35.set(options?url+'|POST|'+qs(options.payload||{}):url,text);return text;}finally{V4_HTTP.push([V4_ROUTE||'상세/목록',url.replace(/([?&]serviceKey=)[^&]*/gi,'$1[비공개]'),Date.now()-t,status]);}
}
function prime35(urls,deadline=Infinity){for(let i=0;i<urls.length;i+=5){if(Date.now()+10000>Math.min(deadline,V4_END))return;const batch=urls.slice(i,i+5),t=Date.now();try{const rs=UrlFetchApp.fetchAll(batch.map(url=>({url,muteHttpExceptions:true,followRedirects:true})));rs.forEach((r,k)=>{if(r.getResponseCode()===200)TEXT_CACHE35.set(batch[k],r.getContentText('UTF-8'));});V4_HTTP.push([V4_ROUTE||'병렬 목록',batch.map(u=>u.replace(/([?&]serviceKey=)[^&]*/gi,'$1[비공개]')).join('\n'),Date.now()-t,'fetchAll '+batch.length+'개·묶음 경과시간']);}catch(e){V4_HTTP.push(['병렬 목록','경로별 독립 재시도',Date.now()-t,safeError(e)]);}}}
function batch(requests){const t=Date.now();try{return batch35V4(requests);}finally{V4_SHEETS.push(['write','Sheets API batch '+requests.length,Date.now()-t]);}}
function upsertTable(s,rows,keycol=0){const t=Date.now();try{return upsertTable35V4(s,rows,keycol);}finally{V4_SHEETS.push(['read/write',s.getName(),Date.now()-t]);}}
function flushMetricsV4(ss,id,role,result){const now=nowKst(),rows=V4_STAGE.map(r=>[id,role,'단계',r[0],r[1],now,result]).concat(V4_HTTP.map(r=>[id,role,'HTTP',r[0],r[2],now,r[3]+' | '+r[1]]),V4_SHEETS.map(r=>[id,role,'Sheets '+r[0],r[1],r[2],now,'계측된 호출·중첩 합산 금지; 나머지는 단계 총시간에 포함']));if(rows.length){const s=ss.getSheetByName('실행계측'),at=s.getLastRow()+1;if(at+rows.length>s.getMaxRows())s.insertRowsAfter(s.getMaxRows(),at+rows.length-s.getMaxRows());s.getRange(at,1,rows.length,7).setValues(rows);}V4_HTTP=[];V4_STAGE=[];V4_SHEETS=[];}
function resetV4(){V52A4_ACTIVE=false;GH_COMPARE_CACHE4=null;TEXT_CACHE35.clear();SH_OFFICIAL35=null;MASTER_CACHE35=null;RAW_KEYS35=null;V4_ROUTE='';V4_MODE='';V4_GH_WORK=false;V4_END=Infinity;}
function refreshDashboard(ss=SpreadsheetApp.openById(SPREADSHEET_ID),skipLegacyDerived=false){
 const dateView=ss.getSheetByName('대시보드');dateView.getRange('B36').setValue(PropertiesService.getScriptProperties().getProperty('FULL_NORMAL35')||'확인 필요');dateView.getRange('B10').setFormula('=IFERROR(TEXT(MAX(FILTER(VALUE(수집상태!D2:D1000),REGEXMATCH(수집상태!A2:A1000,"^LH_"))),"yyyy-mm-dd hh:mm:ss"),"정상 이력 확인 필요")');const handlers=ScriptApp.getProjectTriggers().map(t=>t.getHandlerFunction());dateView.getRange('B11').setValue('시간 트리거 '+handlers.length+'개 · 목록 '+handlers.filter(n=>n==='runCollection').length+' / 후처리 '+handlers.filter(n=>n==='runEnrichmentV4').length+' · 주기는 작업운영/운영매뉴얼 참조');dateView.getRange('A51:B52').setValues([['후처리 현재 장애/중단 감시','=IFERROR(IF(AND(작업운영!D2="시도중",(NOW()-VALUE(작업운영!B2))*1440>7),"경고: 후처리 비정상 종료/장시간 실행 확인",작업운영!D2),"후처리 상태 확인 필요")'],['후처리 마지막 정상/3시간 감시','=IFERROR(IF((NOW()-VALUE(작업운영!C2))*24>3,"경고: 후처리 3시간 정상 없음",작업운영!C2),"정상 이력 확인 필요")']]);dateView.getRange('B36:B38').setNumberFormat('yyyy-mm-dd hh:mm:ss');dateView.getRange('B45').setNumberFormat('yyyy-mm-dd hh:mm:ss');dateView.getRange('B52').setNumberFormat('yyyy-mm-dd hh:mm:ss');
 if(V4_MODE!=='목록'){if(!skipLegacyDerived)runDerivedStageV4(ss);dateView.getRange('A2').setValue('LH·청약홈·SH·GH 공식 경로 수집 / 파생지표 분할 갱신 / 전국·기관 전체 보장 아님 / 자격 별도 확인');return;}
 const s=ss.getSheetByName('대시보드'),p=PropertiesService.getScriptProperties();s.getRange('A36:B38').setValues([['마지막 전체 정상 점검(KST)',p.getProperty('FULL_NORMAL35')||'확인 필요'],['마지막 실행 시작(KST)',p.getProperty('RUN_STARTED35')||'미확인'],['마지막 실행 종료(KST)',p.getProperty('RUN_FINISHED35')||'미확인']]);s.getRange('B45').setValue(p.getProperty('SCHEDULED_STARTED35')||'확인 필요');
}
function processDetailJobs(ss,start){
 const master=readV4(ss.getSheetByName('공고원장')).slice(4).filter(r=>r[0]),details=readV4(ss.getSheetByName('공고상세')).slice(1),dm=new Map(details.map(r=>[r[0],r])),jobs=new Map(readV4(ss.getSheetByName('상세작업')).slice(1).map(r=>[r[0],r])),props=PropertiesService.getScriptProperties();
 const eligible=master.filter(r=>{let d;try{d=JSON.parse((dm.get(r[0])||[])[16]||'null');}catch(e){}return regionV4(r,d).eligible;});if(!eligible.length)return;
 let cursor=Number(props.getProperty('DETAIL_CURSOR4')||0)%eligible.length;const now=nowKst(),due=r=>{const j=jobs.get(r[0]);return !j||!/^20\d{2}-/.test(stampV3(j[5]))||stampV3(j[5])<=now;};
 const priority=eligible.filter(due).sort((a,b)=>{const score=r=>regionV4(r).priority+(!dm.has(r[0])?70:0)+(/접수중|접수예정/.test(r[25])?30:0)+(kstDayV3(r[1])>=todayKst()?40:0)+(dayDiffV4(todayKst(),kstDayV3(r[2]))<=7?80:0)-(/접수마감|마감|취소/.test(r[25])?150:0);return score(b)-score(a)||stampV3(b[1]).localeCompare(stampV3(a[1]));});
 const used=new Set();for(let i=0;i<2&&Date.now()<Math.min(start+210000,V4_END-100000);i++){
  let row=i<1?priority.find(r=>!used.has(r[0])):null;if(!row){for(let n=0;n<eligible.length;n++){const candidate=eligible[cursor];cursor=(cursor+1)%eligible.length;props.setProperty('DETAIL_CURSOR4',String(cursor));if(due(candidate)&&!used.has(candidate[0])){row=candidate;break;}}}if(!row)break;used.add(row[0]);
  const r={id:row[0],number:String(row[34]),title:row[5],type:row[11],region:row[8],url:row[26],published:kstDayV3(row[2])};detailAttempt(ss,r.id);V4_ROUTE='상세 '+r.id;
  try{let d;if(r.id.startsWith('GH:'))d=parseGHDetailV4(fetchText(r.url),r);else if(r.id.startsWith('SH:'))d=parseSHDetail(fetchText(r.url),r);else if(r.id.startsWith('LH:'))d=parseLhDetail(fetchText(r.url),r);else{const raw=readV4(ss.getSheetByName('수집원본')).find(x=>x[0]===row[38]);if(!raw)throw Error('PARSE: 원천 스냅샷 없음');d=collectApplyModels(normalizeApply(JSON.parse(raw[5]),row[33]),props.getProperty('APPLYHOME_SERVICE_KEY'),fetchText);}saveDetail(ss,r,d);if(r.id.startsWith('SH:'))saveSHAttachments(ss,r,d);detailRecovered(ss,r.id);const job=readV4(ss.getSheetByName('상세작업')).findIndex(j=>j[0]===r.id);if(job>0)ss.getSheetByName('상세작업').getRange(job+1,6).setValue(Utilities.formatDate(new Date(Date.now()+3600000),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'));}catch(e){detailFailed(ss,r.id,e);}
 }
}
function processAttachmentJob(ss){
 const master=new Map(readV4(ss.getSheetByName('공고원장')).slice(4).map(r=>[r[0],r])),s=ss.getSheetByName('첨부파일'),rows=readV4(s).slice(1),props=PropertiesService.getScriptProperties(),now=nowKst();let cursor=Number(props.getProperty('ATTACH_CURSOR4')||0)%Math.max(1,rows.length);
 for(let n=0;n<rows.length;n++){const at=cursor;cursor=(cursor+1)%rows.length;props.setProperty('ATTACH_CURSOR4',String(cursor));const r=rows[at],m=master.get(r[1]);if(!m||!regionV4(m).eligible||attachmentDispositionV3(r)||r[15]&&stampV3(r[15])>now)continue;
  // Reuse proven binary checker on a one-record sheet facade; writes go to real sheets.
  const single={getDataRange:()=>({getValues:()=>[[],r]})},view={getSheetByName:name=>name==='첨부파일'?single:ss.getSheetByName(name)},realUpsert=upsertTable;try{upsertTable=function(sheet,incoming,keycol){return realUpsert(sheet===single?s:sheet,incoming,keycol);};processAttachment35V4(view);}finally{upsertTable=realUpsert;}break;
 }
}
function runCollection(e){
 const lock=LockService.getScriptLock();if(!lock.tryLock(1000)){lockMiss52A('목록');return;}
 const started=Date.now(),props=PropertiesService.getScriptProperties();V4_MODE='목록';V4_END=started+230000;props.setProperty('RUN_STARTED35',nowKst());if(e&&e.triggerUid)props.setProperty('SCHEDULED_STARTED35',nowKst());let ss,result='시작';
 try{ss=SpreadsheetApp.openById(SPREADSHEET_ID);ensureV4(ss);const to=todayKst(),key=props.getProperty('APPLYHOME_SERVICE_KEY'),sources=sources35(to,key),previous=new Map(readV4(ss.getSheetByName('수집상태')).slice(1).map(r=>[r[0],r]));ss.getSheetByName('대시보드').getRange('B37').setValue(props.getProperty('RUN_STARTED35'));if(e&&e.triggerUid)ss.getSheetByName('대시보드').getRange('B45').setValue(props.getProperty('SCHEDULED_STARTED35'));
  measureV4('기존 12경로 목록',()=>{prime35(sources.filter(s=>!s.id.startsWith('get')).map(s=>s.url).concat(APPLY_ENDPOINTS.flatMap(endpoint=>{const base='https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/'+endpoint;return[base+'?'+qs({page:1,perPage:1,serviceKey:key}),base+'?'+qs({page:1,perPage:100,serviceKey:key,'cond[RCRIT_PBLANC_DE::GTE]':INITIAL_FROM.replace(/-/g,''),'cond[RCRIT_PBLANC_DE::LTE]':to.replace(/-/g,'')})];})),V4_END-35000);
   sources.sort((a,b)=>Number(/^정상/.test((previous.get(a.id)||[])[2]))-Number(/^정상/.test((previous.get(b.id)||[])[2])));
   for(const src of sources){V4_ROUTE=src.id;sourceAttempt(ss,src,to);try{if(Date.now()+15000>V4_END)throw Error('TIME_BUDGET: 목록 다음 실행 우선 재시도');measureV4(src.id,()=>{if(src.branch){const x=parseFirstCome(fetchText(src.url),src.branch);upsertTable(ss.getSheetByName('수의계약점검'),x.rows.map((r,i)=>[src.branch+':'+i,nowKst(),src.branch,r.region,r.district,r.block,r.area,r.unsold,r.priceThousand,r.contact,r.note,src.url,'재고표시 행']));sourceFinish(ss,src,[],null,to);const s=ss.getSheetByName('수집상태'),at=readV4(s).findIndex(r=>r[0]===src.id);s.getRange(at+1,7).setValue(x.total);}else sourceFinish(ss,src,src.run(),null,to);});}catch(err){sourceFinish(ss,src,[],safeError(err),to);}}
  });
  measureV4('SH 6경로 목록',()=>{const configs=[...SH_ROUTES].sort((a,b)=>Number(/^정상/.test((previous.get(a.id)||[])[2]))-Number(/^정상/.test((previous.get(b.id)||[])[2])));prime35(configs.map(c=>shUrl(c,1,to)),V4_END-20000);for(const cfg of configs){V4_ROUTE=cfg.id;try{collectSH35(ss,cfg,to,V4_END-15000);}catch(err){sourceFinish(ss,{...cfg,agency:'SH',label:cfg.id,url:shUrl(cfg,1,to)},[],safeError(err),to);}}});
  const states=readV4(ss.getSheetByName('수집상태')).slice(1).filter(r=>r[0]),existing=states.filter(r=>!String(r[0]).startsWith('GH_'));if(existing.length===18&&existing.every(r=>/^정상/.test(r[2])&&stampV3(r[1])>=props.getProperty('RUN_STARTED35'))){props.setProperty('EXISTING_FULL_NORMAL4',nowKst());if(e&&e.triggerUid){const n=Number(props.getProperty('LIST_AUTO_OK4')||0)+1;props.setProperty('LIST_AUTO_OK4',String(n));if(n>=2)props.setProperty('LIST_AUTO_VERIFIED4',nowKst());}}if(states.every(r=>/^정상/.test(r[2])&&Date.now()-Date.parse(stampV3(r[1]).replace(' ','T')+'+09:00')<10800000))props.setProperty('FULL_NORMAL35',nowKst());
  measureV4('즉시 장애 감시',()=>{filterQueueRegionV4(ss);refreshMonitor(ss);});result='기존 '+existing.filter(r=>/^정상/.test(r[2])).length+'/18 정상';
 }catch(err){result='실패 '+safeError(err);throw err;}finally{if(ss){props.setProperty('RUN_FINISHED35',nowKst());ss.getSheetByName('대시보드').getRange('B38').setValue(props.getProperty('RUN_FINISHED35'));ss.getSheetByName('개발검증').appendRow(['4차 목록',e&&e.triggerUid?'실제 시간 기반':'수동 실행',nowKst()+' | '+((Date.now()-started)/1000).toFixed(3)+'초 | '+result]);V4_STAGE.push(['총 실행',Date.now()-started]);flushMetricsV4(ss,props.getProperty('RUN_STARTED35'),'목록',result);}resetV4();lock.releaseLock();}
}
function legacyRunEnrichmentV4Before42(e){
 if(e&&e.triggerUid&&!PropertiesService.getScriptProperties().getProperty('LIST_AUTO_VERIFIED4')){runCollection(e);return;}
 const lock=LockService.getScriptLock();if(!lock.tryLock(1000)){console.log('LOCK_BUSY: 목록/다른 작업 우선·다음 10분 재시도');return;}
 const start=Date.now(),props=PropertiesService.getScriptProperties();V4_MODE='후처리';V4_END=start+210000;let ss,result='시작',enrichmentToken=null;
 try{ss=SpreadsheetApp.openById(SPREADSHEET_ID);ensureV4(ss);detectWorkerAbortV4(ss);upsertTable(ss.getSheetByName('작업운영'),[['후처리',nowKst(),props.getProperty('WORKER_OK4')||'','시도중','목록 실행과 동일 잠금',e&&e.triggerUid?nowKst():props.getProperty('WORKER_AUTO4')||'']]);if(e&&e.triggerUid)props.setProperty('WORKER_AUTO4',nowKst());
  if(props.getProperty('GH_ENABLED4')==='true')measureV4('GH 목록',()=>runGHJobsV4(ss,start+100000));
  if(!V4_GH_WORK){enrichmentToken=reserveEnrichmentV4(props,Date.now());if(enrichmentToken===null){result='대기·상세/첨부 24시간 예산·목록 수집 별도';upsertTable(ss.getSheetByName('작업운영'),[['후처리',Utilities.formatDate(new Date(start),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'),props.getProperty('WORKER_OK4')||'',result,'GH 목록 유지·다음 실행에서 예산 재평가; ENRICH_BUDGET_MS4 기본 600000ms',props.getProperty('WORKER_AUTO4')||'']]);return;}}
  if(!V4_GH_WORK&&Date.now()<start+70000)measureV4('상세',()=>processDetailJobs(ss,Date.now()-150000));
  if(!V4_GH_WORK&&Date.now()<start+70000)measureV4('SH 후속',()=>processFollowups35(ss,1));
  if(!V4_GH_WORK&&Date.now()<start+80000)measureV4('첨부',()=>processAttachmentJob(ss));
  measureV4('파생지표/대시보드',()=>{const status=readV4(ss.getSheetByName('수집상태')).slice(1).filter(r=>r[0]);if(status.every(r=>/^정상/.test(r[2])&&Date.now()-firstMsV4(r[1])<10800000))props.setProperty('FULL_NORMAL35',nowKst());refreshMonitor(ss);refreshRegionV4(ss);if(typeof refreshUserDashboardV4==='function')refreshUserDashboardV4(ss);});
  props.setProperty('WORKER_OK4',nowKst());result='완료·외부 발송 없음';upsertTable(ss.getSheetByName('작업운영'),[['후처리',Utilities.formatDate(new Date(start),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'),nowKst(),result,'상세/첨부 커서 이어받기',props.getProperty('WORKER_AUTO4')||'']]);
 }catch(err){result='실패 '+safeError(err);if(ss)ss.getSheetByName('처리오류이력').appendRow([nowKst(),'4차 후처리','',result,'','다음 10분 재시도',safeError(err)]);throw err;}finally{if(enrichmentToken!==null)finishEnrichmentV4(props,enrichmentToken,Date.now()-enrichmentToken);if(ss){V4_STAGE.push(['총 실행',Date.now()-start]);flushMetricsV4(ss,Utilities.formatDate(new Date(start),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'),'후처리',result);ss.getSheetByName('개발검증').appendRow(['4차 후처리',e&&e.triggerUid?'실제 시간 기반':'수동 실행',nowKst()+' | '+((Date.now()-start)/1000).toFixed(3)+'초 | '+result]);}resetV4();lock.releaseLock();}
}
function installPhase4(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 수집 실행중');try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID);ensureV4(ss);const p=PropertiesService.getScriptProperties();if(!p.getProperty('REGION_STARTED4'))p.setProperty('REGION_STARTED4',nowKst());refreshRegionV4(ss);refreshMonitor(ss);if(!ScriptApp.getProjectTriggers().some(t=>t.getHandlerFunction()==='runEnrichmentV4'))ScriptApp.newTrigger('runEnrichmentV4').timeBased().everyMinutes(10).create();ss.getSheetByName('시스템설정').getRange('A2').setValue('4차: 서울·경기/지역미상 우선. 기존 목록 1시간 트리거 보존 + 후처리 10분 독립 작업. 외부 발송 없음.');ss.getSheetByName('개발검증').appendRow(['4차 구조 설치','실제 운영',nowKst()+' | 기존 runCollection 보존·후처리 역할 1개만 보장']);console.log('PHASE4_INSTALLED');}finally{lock.releaseLock();}}

function filterQueueRegionBaseV4(ss){const q=ss.getSheetByName('발송대기'),rows=readV4(q).slice(1),m=new Map(readV4(ss.getSheetByName('공고원장')).slice(4).map(r=>[r[0],r]));if(rows.length)q.getRange(2,8,rows.length,3).setValues(rows.map(e=>m.has(e[1])?notificationRegionV4(e,m.get(e[1]),e.slice(7,10)):e.slice(7,10)));}
function assessV3(row,d,q){if(String(row[0]).startsWith('GH:')&&ghDispositionV4(String(row[5]),{kind:String(row[0]).startsWith('GH:APPLY:')?'apply':'web'})[0]==='제외')return ['','GH 공식 목록 재판정: 비주거/단순 결과/명시적 테스트. 원장 보존·모집 후보 제외'];if(String(row[0]).startsWith('GH:')&&regionV4(row,d).eligible&&/장기전세|든든전세|신혼희망타운|공공분양|신혼.*(?:매입|전세)임대/.test(String(row[5])))return ['★중요★','GH 공식 모집명에서 관심 공급유형 확인; 경기 주거용 모집. 면적·아파트 여부·비용·입주일·신청자격 원문 확인 필요'];return assess35V4(row,d,q);}

function masterRow(r,now,hash,snapshot){const row=masterRow35V4(r,now,hash,snapshot);if(String(r.id).startsWith('GH:'))row[30]='GH 공식 HTML 목록·접수기간/면적/가격/자격은 상세 근거 별도·교차게시 임의 병합 금지';return row;}
function lifecycleV3(row,d,today){if(String(row[0]).startsWith('GH:')){const cfg={kind:String(row[33]).includes('청약공지')?'notice':String(row[0]).startsWith('GH:APPLY:')?'apply':'web'};if(ghDispositionV4(String(row[5]),cfg)[0]==='제외')return '모집대상 제외';if(/^(접수마감|모집마감|마감)$/.test(String(row[25]).trim())||/^\s*[\[(](?:접수)?마감[\])]/.test(String(row[5])))return '마감';}return lifecycle35V4(row,d,today);}
function classifySupplyV2(row,raw){if(String(row[0]).startsWith('GH:')&&/민영주택|국민 및 민영/.test(String(row[5])))return ['미확인','공식 제목의 국민/민영 청약주택 구분만 확인·공공분양/민간분양 사업구분은 원문 근거 추가 확인 필요'];if(String(row[0]).startsWith('GH:'))return [String(row[3]).includes('확인')?'미확인':row[3],'GH 공식 게시판 주택유형/모집명 근거. 위탁운영 모집주체 및 개별 신청조건 별도 확인'];return classify35V4(row,raw);}

function filterConfirmedAliasesV4(ss){const q=ss.getSheetByName('발송대기'),rows=readV4(q).slice(1),aliases=new Map(validAliasesV4(ss,readV4(ss.getSheetByName('공고원장')).slice(4)));if(rows.length&&aliases.size)q.getRange(2,8,rows.length,3).setValues(rows.map(e=>e[3]==='신규'&&aliases.has(e[1])&&e[8]==='Y'?[e[7],'N','동일 모집 교차게시 확인·대표ID '+aliases.get(e[1])+' 후보 사용·기록 보존']:e.slice(7,10)));}

function filterQueueRegionV4(ss){return queuePolicyView52A(ss,v=>{filterQueueRegionBaseV4(v);filterConfirmedAliasesV4(v);protectGHFollowupsV4(v);reconcileGHChangesV4(v);protectDetailEvents42A(v);finalQueueGuard52A(v);});}

function workerInterruptedV4(row,now){return !!(row&&row[3]==='시도중'&&Number.isFinite(firstMsV4(row[1]))&&now-firstMsV4(row[1])>7*60000);}
function detectWorkerAbortV4(ss){const p=PropertiesService.getScriptProperties(),row=readV4(ss.getSheetByName('작업운영')).find(r=>r[0]==='후처리');if(workerInterruptedV4(row,Date.now())&&p.getProperty('WORKER_ABORT_RECORDED4')!==stampV3(row[1])){ss.getSheetByName('처리오류이력').appendRow([nowKst(),'4차 후처리','이전 실행 '+stampV3(row[1]),'비정상 종료 의심·실제 실행기록 확인','','체크포인트부터 재개','7분 이상 시도중·종료 기록 없음; 마지막 정상 '+stampV3(row[2])+'; 마지막 단계 '+(p.getProperty('WORKER_STAGE4')||'이전 버전 계측 없음')+'; 마지막 HTTP 시도 '+(p.getProperty('WORKER_HTTP4')||'이전 버전 계측 없음')]);p.setProperty('WORKER_ABORT_RECORDED4',stampV3(row[1]));}}

function ensureRowsV4(sheet,need){if(need>sheet.getMaxRows())sheet.insertRowsAfter(sheet.getMaxRows(),need-sheet.getMaxRows());}

function updatePhase4GuideV4(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 수집 실행중');try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID);ss.getSheetByName('시스템설정').getRange('B11:C11').setValues([['LH·청약홈·SH 목록 1시간 / GH·후처리 10분 역할','기존 runCollection 1개 보존·runEnrichmentV4 1개·동일 ScriptLock·키는 속성만 사용']]);ss.getSheetByName('수집범위').getRange('A10:F12').setValues([['자동실행','기존 목록 1시간 + 후처리 10분','서로 다른 역할 각1개·동일 잠금','실제 실행기록/작업운영/수집감시','단일 요청 지연·강제종료 위험 잔존','운영매뉴얼 참조'],['GH','기관주택·청약임대·청약매입임대·청약공지','공식 HTML 4경로·전체이력/증분','정상/부분누락은 수집상태 기준','외부 위탁/별도 청약 전수·첨부 자격 미검증','https://www.gh.or.kr/gh/housing.do'],['다음 기관','HUG·서울 청년안심주택','후속 개발','이번 미수집','서울·경기 전체 수집 미완료','4차 보고서 참조']]);reclassifyGHAuditV4(ss);ss.getSheetByName('개발검증').appendRow(['4차 운영 안내 최신화','실제 운영',nowKst()+' | 설정/수집범위 갱신·기존 데이터/트리거 보존']);console.log('PHASE4_GUIDE_UPDATED');}finally{resetV4();lock.releaseLock();}}

function enrichmentWindowV4(entries,now){return entries.filter(r=>Array.isArray(r)&&Number.isFinite(r[0])&&Number.isFinite(r[1])&&r[0]>now-86400000&&r[0]<=now);}
function reserveEnrichmentV4(props,now){let entries;try{entries=enrichmentWindowV4(JSON.parse(props.getProperty('ENRICH_WINDOW4')||'[]'),now);}catch(e){throw Error('PARSE: 상세 예산 이력 오류·임의 초기화하지 않음');}const configured=props.getProperty('ENRICH_BUDGET_MS4'),budget=configured===null?600000:Number(configured);if(!Number.isFinite(budget)||budget<0)throw Error('PARSE: 상세 예산 설정');if(entries.reduce((n,r)=>n+r[1],0)+360000>budget){props.setProperty('ENRICH_WINDOW4',JSON.stringify(entries));return null;}entries.push([now,360000]);props.setProperty('ENRICH_WINDOW4',JSON.stringify(entries));return now;}
function finishEnrichmentV4(props,token,elapsed){const entries=JSON.parse(props.getProperty('ENRICH_WINDOW4')||'[]'),row=entries.find(r=>r[0]===token);if(row){row[1]=Math.max(0,elapsed);props.setProperty('ENRICH_WINDOW4',JSON.stringify(entries));}}
function inspectWorkerV4(){const p=PropertiesService.getScriptProperties();let request=null,entries=[];try{request=JSON.parse(p.getProperty('WORKER_HTTP4')||'null');if(request&&request.url)request.url=request.url.replace(/([?&]serviceKey=)[^&]*/gi,'$1[비공개]');entries=enrichmentWindowV4(JSON.parse(p.getProperty('ENRICH_WINDOW4')||'[]'),Date.now());}catch(e){console.log('진단 JSON 파싱 확인 필요');}console.log(JSON.stringify({stage:p.getProperty('WORKER_STAGE4')||'미계측',completedStages:p.getProperty('WORKER_STAGE_TIMES4')||'[]',derived:p.getProperty('DERIVED_LAST4')||'',lastRequest:request,lastSuccess:p.getProperty('WORKER_OK4')||'',reservedOrUsedMs:entries.reduce((n,r)=>n+r[1],0),budgetMs:Number(p.getProperty('ENRICH_BUDGET_MS4')||600000),reservations:entries.length}));}

function runDerivedStageV4(ss){const p=PropertiesService.getScriptProperties(),phase=Number(p.getProperty('DERIVED_PHASE4')||0)%4,steps=[['핵심정보/작업큐',reconcileQualityV2],['첨부 예외',reconcileExceptionsV3],['접수상태/발송정책',reconcileDecisionsV3],['마감 리마인더',prepareReminders35]];if(Date.now()+50000>V4_END){p.setProperty('DERIVED_PENDING4',nowKst()+' | 잔여 예산 부족·다음 단계 '+phase);return false;}measureV4('파생 분할 '+steps[phase][0],()=>steps[phase][1](ss));p.setProperty('DERIVED_PHASE4',String((phase+1)%4));p.setProperty('DERIVED_LAST4',nowKst()+' | 완료 '+steps[phase][0]+' / 다음 '+((phase+1)%4));p.deleteProperty('DERIVED_PENDING4');return true;}

const GH_ROUTES4=[
 {id:'GH_기관주택',kind:'web',url:'https://www.gh.or.kr/gh/housing.do',limit:100},
 {id:'GH_청약임대',kind:'apply',url:'https://apply.gh.or.kr/sb/sr/sr7150/selectPbancRentHouseList.do',detail:'https://apply.gh.or.kr/sb/sr/sr7150/selectPbancDetailView.do',limit:10},
 {id:'GH_청약매입임대',kind:'apply',url:'https://apply.gh.or.kr/sb/sr/sr7155/selectPbancRentHouseList.do',detail:'https://apply.gh.or.kr/sb/sr/sr7155/selectPbancDetailView.do',limit:10},
 {id:'GH_청약공지',kind:'notice',url:'https://apply.gh.or.kr/sr/sr7190/selectNoticeList.do',detail:'https://apply.gh.or.kr/sr/sr7190/selectNoticeDetailView.do',limit:10}
];
function ghTextV4(s){return textOf(String(s).replace(/&#(x[0-9a-f]+|\d+);/gi,(_,x)=>String.fromCodePoint(x[0].toLowerCase()==='x'?parseInt(x.slice(1),16):Number(x))));}
function ghDateV4(s){const m=String(s||'').trim().match(/^(\d{2}|20\d{2})[.\/-](\d{1,2})[.\/-](\d{1,2})$/);return m?dateClean((m[1].length===2?'20':'')+m[1]+'-'+m[2]+'-'+m[3]):'';}
function ghUrlV4(cfg,page){return cfg.url+'?'+qs(cfg.kind==='web'?{mode:'list','article.offset':(page-1)*cfg.limit,articleLimit:cfg.limit}:{pageIndex:page});}
function ghDispositionV4(title,cfg){
 if(/테스트용|테스트지구/.test(title))return ['제외','공식 게시판의 명시적 테스트 공고'];
 if(/상가|택지|산업단지|토지.*매각|주택\s*매입\s*공고|매도신청|매입약정|감리|입찰|채용/.test(title))return ['제외','비주거/주택 매도자·사업자 모집'];
 const common=noticeKind52A(title);if(resultNotice52A(title)){if(common==='EXCLUDED')return ['제외','공통 결과/대상자 발표 판정·원장/원천 보존'];if(common==='REVIEW')return ['별도검토','결과 및 실제 모집변경 혼합·원문 근거 확인 필요'];}
 if(/(?:당첨자|예비당첨자|입주대상자|서류제출\s*대상자|예비입주자).{0,30}(?:발표|당첨결과)|(?:당첨|접수|모집(?:시행|접수)?)\s*결과/.test(title))return /결과.*(?:추가모집|재공급|무순위).*공고/.test(title)?['별도검토','결과 및 추가모집 혼합 제목·원문 분리 확인 필요']:['제외','당첨/서류대상/접수·모집 결과 안내·원장 보존'];
 if(cfg&&cfg.kind==='notice'&&/정정|일정.*(?:변경|연기)|마감안내/.test(title))return ['중요후속','정정/일정·마감 변경 안내·원 모집 연결 확인 필요'];
 if(/당첨자|경쟁률|접수현황|선정결과|심사대상|서류제출.*대상|계약체결.*결과|입주자.*발표|예비자.*발표|입주대상자.*발표|결과\s*발표|신청접수.*현황/.test(title)&&!/일정.*(?:변경|연기)|추가.*모집|정정|자격.*완화/.test(title))return ['제외','단순 결과/심사대상'];
 if(/입주자|예비입주자|입주대상자|거주자|임차인|잔여세대|무순위|추가모집|재공급/.test(title)&&/모집|공고|접수|공급/.test(title))return ['수집','주거용 신규/정정/추가모집'];
 if(/주택|장기전세|아파트|기숙사|푸르지오/.test(title)&&/모집/.test(title))return ['수집','공식 주거용 모집명·입주자 단어 생략도 포함'];
 if(/자격.*완화|일정.*(?:변경|연기)|가격.*공개|분양가격|정정|모집.*연장/.test(title))return ['중요후속','원 모집 연결/변경내용 원문 확인 필요'];
 if(cfg&&cfg.kind==='apply')return ['수집','공식 주택 청약 전용 게시판·상세 모집대상 원문 확인 필요'];
 return ['별도검토','주거용 모집 여부 원문 확인 필요'];
}
function parseGHListV4(html,cfg){
 if(cfg.kind==='notice')return parseGHNoticeV4(html,cfg);
 const text=ghTextV4(html),m=cfg.kind==='web'?text.match(/총\s*([\d,]+)\s*건,\s*(\d+)\s*\/\s*(\d+)\s*페이지/):text.match(/총게시물\s*:\s*([\d,]+)\s*페이지\s*:\s*(\d+)\s*\/\s*(\d+)/);
 if(!m)throw Error('PARSE: GH 공식 총건수/페이지 표식 없음');const rows=[];
 for(const tr of html.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)){
  const inner=tr[1],a=cfg.kind==='web'?inner.match(/<a\b[^>]*href=["']([^"']*articleNo=(\d+)[^"']*)["'][^>]*>([\s\S]*?)<\/a>/i):inner.match(/<a\b[^>]*data-pbancNo=["'](\d+)["'][^>]*>([\s\S]*?)<\/a>/i);
  if(!a)continue;const td=[...inner.matchAll(/<td\b[^>]*>([\s\S]*?)(?=<td\b|$)/gi)].map(x=>ghTextV4(x[1]));
  const number=cfg.kind==='web'?a[2]:a[1],title=ghTextV4(cfg.kind==='web'?a[3]:a[2]),published=ghDateV4(cfg.kind==='web'?td[4]:td[5]);
  if(!number||!title||!published)throw Error('PARSE: GH 공고번호/제목/게시일 누락');
  const record={number,title,published,type:cfg.kind==='web'?'주택':td[1],region:'',boardDeadline:cfg.kind==='web'?'':ghDateV4(td[6]),boardStatus:cfg.kind==='web'?'':td[7],url:cfg.kind==='web'?cfg.url+'?mode=view&articleNo='+number:cfg.detail+'?pbancNo='+number};record._parserVersion='GH_LIST52A3';Object.assign(record,ghListRegionEvidence52A(html,tr[0],record.url));rows.push(record);
 }
 const total=Number(m[1].replace(/,/g,'')),page=Number(m[2]),pages=Number(m[3]),expected=Math.min(cfg.limit,Math.max(0,total-(page-1)*cfg.limit));
 if(rows.length!==expected||new Set(rows.map(r=>r.number)).size!==rows.length)throw Error('PARSE: GH 페이지 행/고유번호 불일치 '+rows.length+'/'+expected);
 return {total,page,pages,records:rows};
}
function normalizeGHV4(raw,cfg){const title=raw.title,disp=ghDispositionV4(title,cfg),supply=/민영주택|국민 및 민영/.test(title)?'공급구분 확인 필요':/전세임대/.test(title)?'보증금지원':/민간임대/.test(title)?'민간임대':/분양주택|공공분양|신혼희망타운/.test(title)?'공공분양':/임대|행복주택|장기전세/.test(title)||cfg.kind==='apply'?'공공임대':'공급구분 확인 필요';return {id:'GH:'+(cfg.kind==='web'?'WEB:':cfg.kind==='notice'?'NOTICE:':'APPLY:')+raw.number,number:raw.number,system:'GH_'+cfg.kind,source:cfg.id,agency:'경기주택도시공사(GH)',title,published:raw.published,region:String(raw.region||''),type:raw.type,supply,status:raw.boardStatus||'접수기간 원문 확인 필요',url:raw.url,change:/정정|수정/.test(title)?'정정공고':/추가|재공급|무순위|잔여|자격완화/.test(title)?'추가모집':'신규',boardDeadline:raw.boardDeadline,raw:JSON.stringify(raw),disposition:disp[0]};}
function ensureGHV4(ss){if(!ss.getSheetByName('GH게시판대조')){const s=ss.insertSheet('GH게시판대조');s.appendRow(['대조키','공식경로','확인시각','공식총건수','전체페이지','공식ID','제목','게시일','처리','근거','공식URL','주기ID','처리페이지']);s.setFrozenRows(1);}if(!ss.getSheetByName('교차게시검토')){const s=ss.insertSheet('교차게시검토');s.appendRow(['공고ID','관련ID/URL','근거','확인시각','병합상태']);s.setFrozenRows(1);}}
function saveGHPageV4(ss,cfg,x,generation){
 const src={...cfg,agency:'GH',label:cfg.id,from:'전체 게시 이력',partial35:true},records=[...new Map(x.records.concat(x.pinned||[]).filter(r=>ghDispositionV4(r.title,cfg)[0]==='수집'||resultNotice52A(r.title)&&noticeKind52A(r.title)==='EXCLUDED').map(r=>[r.number,r])).values()].map(r=>normalizeGHV4(r,cfg)),s=ss.getSheetByName('수집상태'),old=readV4(s).find(r=>r[0]===cfg.id)||[],last=old[3]||'';
 let summary={added:0,changed:0};const changed=!!(records.length&&!ghRecordsUnchangedV4(ss,records));if(changed){summary=saveResult(ss,src,records,null,todayKst());classifyNew35(ss,records);reconcileGHChangesV4(ss);MASTER_CACHE35=null;GH_COMPARE_CACHE4=null;}
 const audit=x.records.concat(x.pinned||[]).map(r=>[cfg.id+':'+r.number,cfg.id,nowKst(),x.total,x.pages,r.number,r.title,r.published,...ghDispositionV4(r.title,cfg),r.url,generation,r.pinned?'고정공지 별도':x.page]);upsertGHAuditV4(ss.getSheetByName('GH게시판대조'),audit);
 const at=readV4(s).findIndex(r=>r[0]===cfg.id);s.getRange(at+1,3,1,2).setValues([['일부 누락 가능',last]]);s.getRange(at+1,5).setValue('전체 게시 이력');s.getRange(at+1,7).setValue('');s.getRange(at+1,10).setValue('백필/전체대조 '+x.page+'/'+x.pages+'페이지 저장·전체 완료 전 정상 처리 안 함');
 const origins=ss.getSheetByName('발견구분'),knownOrigins=new Set(origins?readV4(origins).slice(1).map(r=>r[0]):[]);if(!ghPageNeedsPolicyV4(records,changed,knownOrigins)){saveGHFollowupsV4(ss,cfg,x.records.concat(x.pinned||[]));finalQueueGuard52A(ss);return summary;}
 const q=ss.getSheetByName('발송대기'),events=readV4(q).slice(1),ids=new Set(records.map(r=>r.id)),p=PropertiesService.getScriptProperties(),initial=!!p.getProperty('GH_INITIAL4_'+cfg.id);
 if(events.length)q.getRange(2,8,events.length,3).setValues(events.map(e=>{if(!ids.has(e[1])||e[3]!=='신규')return e.slice(7,10);if(initial||e[7]==='GH초기연결·유효성확인대기'){const r=records.find(r=>r.id===e[1]);if(r.published>=kstDayV3(p.getProperty('GH_STARTED4_'+cfg.id)))return ['실시간신규','Y','[신규 모집공고 · 접수기간 확인 필요]'];return ['GH초기연결·유효성확인대기','N','초기 대량 백필과 구분: 현재/향후 접수 확인 시 신규발견 후보로 재평가'];}if(!e[7]){const r=records.find(r=>r.id===e[1]);return r.published>=kstDayV3(p.getProperty('GH_STARTED4_'+cfg.id))?['실시간신규','Y','[신규 모집공고 · 접수기간 확인 필요]']:['신규발견·과거게시','N','과거 신규발견·접수기간 확인 후 재평가'];}return e.slice(7,10);}));
 if(typeof ensureOriginsV4==='function')ensureOriginsV4(ss);
 saveGHFollowupsV4(ss,cfg,x.records.concat(x.pinned||[]));finalQueueGuard52A(ss);return summary;
}
function runGHJobsV4(ss,deadline){
 ensureGHV4(ss);const props=PropertiesService.getScriptProperties(),to=todayKst();if(props.getProperty('GH_CLASSIFIER4')!=='20261020.3'){if(props.getProperty('GH_CLASSIFIER4')==='20261020.2'){reclassifyGHAuditV4(ss);}else{for(const cfg of GH_ROUTES4){props.deleteProperty('GH_DUE4_'+cfg.id);clearCheckpoint52A(props,'GH_PAGE4_'+cfg.id);props.setProperty('GH_INITIAL4_'+cfg.id,'true');}}props.setProperty('GH_CLASSIFIER4','20261020.3');ss.getSheetByName('개발검증').appendRow(['GH 분류 보완 재대조','실제 운영',nowKst()+' | 주거모집 단어 생략/명시적 테스트 구분·원장/큐 보존·공식 전체 페이지 재대조']);}let cursor=Number(props.getProperty('GH_ROUTE_CURSOR4')||0)%GH_ROUTES4.length,visited=0;
 while(visited<GH_ROUTES4.length&&Date.now()+15000<deadline){const cfg=GH_ROUTES4[cursor],key='GH_PAGE4_'+cfg.id,src={...cfg,agency:'GH',label:cfg.id,from:'전체 게시 이력'},due=Number(props.getProperty('GH_DUE4_'+cfg.id)||0);cursor=(cursor+1)%GH_ROUTES4.length;visited++;props.setProperty('GH_ROUTE_CURSOR4',String(cursor));if(due>Date.now()&&!props.getProperty(key)&&props.getProperty('GH_FULL4_'+cfg.id)&&Number(props.getProperty('GH_HEAD_DUE4_'+cfg.id)||0)>Date.now())continue;
  V4_GH_WORK=true;V4_ROUTE=cfg.id;sourceAttempt(ss,src,to);try{
   const first=parseGHListV4(fetchText(ghUrlV4(cfg,1)),cfg),fingerprint=digest(JSON.stringify(first.records.concat(first.pinned||[]).map(r=>[r.number,r.title,r.published])));let state=loadCheckpoint52A(props,key);const full=JSON.parse(props.getProperty('GH_FULL4_'+cfg.id)||'null');
   if(ghHeadUnchangedV4(full,{total:first.total,pages:first.pages,first:fingerprint},!!state,due,Date.now())){saveGHPageV4(ss,cfg,first,'증분 '+nowKst());sourceFinish(ss,src,[],null,to);const hs=ss.getSheetByName('수집상태'),hi=readV4(hs).findIndex(r=>r[0]===cfg.id);hs.getRange(hi+1,7).setValue(first.total);hs.getRange(hi+1,10).setValue('증분 첫페이지 '+first.records.length+'행/지문·총건수 동일; 마지막 전체대조 '+full.at+'; 과거 페이지 정정은 24시간 전체 재대조에서 확인');props.setProperty('GH_HEAD_DUE4_'+cfg.id,String(Date.now()+3600000));continue;}

   if(!state||state.total!==first.total||state.pages!==first.pages||state.first!==fingerprint)state={page:1,total:first.total,pages:first.pages,first:fingerprint,pinIds:cfg.kind==='notice'?[...new Set((first.pinned||[]).map(r=>r.number))]:[],ids:cfg.kind==='notice'?[...new Set((first.pinned||[]).map(r=>r.number))]:[],generation:nowKst()};
   if(!props.getProperty('GH_STARTED4_'+cfg.id)){props.setProperty('GH_STARTED4_'+cfg.id,nowKst());props.setProperty('GH_INITIAL4_'+cfg.id,'true');}
   let processed=0;while(state.page<=state.pages||state.total===0){if(Date.now()+15000>=deadline)throw Error('TIME_BUDGET: GH '+state.page+'페이지부터 이어받기');
  const x=state.page===1?first:parseGHListV4(fetchText(ghUrlV4(cfg,state.page)),cfg);if(x.page!==state.page||x.total!==state.total||x.pages!==state.pages)throw Error('PARTIAL: GH 페이지/총건수 변경·다음 주기 재대조');
    const pageStats=saveGHPageV4(ss,cfg,x,state.generation)||{};state.added=Number(state.added||0)+Number(pageStats.added||0);state.changed=Number(state.changed||0)+Number(pageStats.changed||0);state.ids.push(...x.records.map(r=>r.number));state.page++;processed++;checkpoint42(props,key,state);
    if(state.page>state.pages||state.total===0){if(!ghCheckpointCompleteV4(state,cfg))throw Error('PARTIAL: GH 전체 행/고유ID 대조 불일치');sourceFinish(ss,src,[],null,to);const s=ss.getSheetByName('수집상태'),at=readV4(s).findIndex(r=>r[0]===cfg.id);s.getRange(at+1,7).setValue(state.total);if(state.added||state.changed)s.getRange(at+1,3).setValue('정상·신규 '+Number(state.added||0)+'/변경 '+Number(state.changed||0));s.getRange(at+1,10).setValue('공식 '+state.total+'표시행/'+state.pages+'페이지/고유ID '+new Set(state.ids).size+'개 대조 완료'+(cfg.kind==='notice'?' (고정공지 중복표시 별도)':'')+'; 모집/제외/별도검토 GH게시판대조 보존. 별도 외부운영 공고·첨부 조건 미검증');clearCheckpoint52A(props,key);props.deleteProperty('GH_INITIAL4_'+cfg.id);props.setProperty('GH_FULL4_'+cfg.id,JSON.stringify({total:state.total,pages:state.pages,first:state.first,at:nowKst()}));props.setProperty('GH_HEAD_DUE4_'+cfg.id,String(Date.now()+3600000));props.setProperty('GH_DUE4_'+cfg.id,String(Date.now()+86400000));break;}
    if(processed>=5)throw Error('TIME_BUDGET: GH 5페이지 단위 저장·다음 10분 이어받기');
   }
  }catch(err){sourceFinish(ss,src,[],safeError(err),to);}
 }
}
function parseGHDetailV4(html,r){
 if(!ghIdentity52A(html,r))throw Error('PARSE: GH 상세 제목/고유ID 불일치');
 const d={_parserVersion:'GH52A3',id:r.id,url:r.url,complexes:[r.title],units:[],attachments:[],address:'',regionEvidence:[],building:'원문 확인 필요',begin:'',end:'',winner:'',move:'',qualification:'원문 확인 필요',price:'원문 확인 필요',monthly:'원문 확인 필요',min:'',max:'',count:'',bodyEvidence:'',crossReferences:[]};
 const body=(html.match(/<(?:td|div)\b[^>]*class=["'][^"']*\b(?:b-content-box|b-content|board_cont|txt_box|notice_content)\b[^"']*["'][^>]*>([\s\S]*?)<\/(?:td|div)>/i)||[])[1];if(body)d.bodyEvidence=ghTextV4(body).slice(0,18000);
 for(const a of html.matchAll(/<a\b[^>]*href=["']([^"']*(?:mode=download|selectFileDown\.do)[^"']*)["'][^>]*>([\s\S]*?)<\/a>/gi)){const href=a[1].replace(/&amp;/g,'&'),url=href.startsWith('http')?href:href.startsWith('?')?r.url.split('?')[0]+href:'https://www.gh.or.kr'+href,name=ghTextV4(a[2]).replace(/\s*\([\d,]+\s*Byte\).*$/i,'').trim();if(!d.attachments.some(f=>f.url===url))d.attachments.push({fileId:'GH:'+digest(url),name:name||'공식 첨부 · 파일명 확인 필요',url});}
 for(const tr of html.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)){const t=ghTextV4(tr[1]);if(/접수처\s*운영기간/.test(t))continue;if(/청약\s*(?:접수)?기간|신청기간|접수기간/.test(t)&&!/서류|심사|당첨/.test(t)){const dates=[...t.matchAll(/20\d{2}[.\/-]\d{1,2}[.\/-]\d{1,2}/g)].map(m=>ghDateV4(m[0]));if(dates.length>=2){d.begin=dates[0];d.end=dates[dates.length-1];d.schedules=[{label:'GH 공식 상세 접수기간',begin:d.begin,end:d.end,evidence:t}];}}}
 for(const a of html.matchAll(/(?:href=["']|https?:\/\/)([^\s"'<>]*(?:articleNo=\d+|pbancNo=\d+|HOUSE_MANAGE_NO=\d+)[^\s"'<>]*)/gi))d.crossReferences.push(ghTextV4(a[0]).slice(0,500));
 // Official GH supply tabs contain per-complex unit rows and schedules.
 const chunks=html.split(/<div\b[^>]*id=["']tab\d+["'][^>]*>/i).slice(1),schedules=[];
 for(const [chunkIndex,chunk] of chunks.entries()){const supply=(chunk.match(/<table\b[^>]*>[\s\S]*?<\/table>/i)||[])[0]||'',name=ghTextV4((supply.match(/지구명<\/th>\s*<td[^>]*>([\s\S]*?)<\/td>/i)||[])[1]||''),address=ghTextV4((supply.match(/소재지<\/th>\s*<td[^>]*>([\s\S]*?)<\/td>/i)||[])[1]||'');if(name&&!d.complexes.includes(name))d.complexes.push(name);if(address&&!d.address.includes(address))d.address+=(d.address?'; ':'')+address;if(address)d.regionEvidence.push({kind:'OFFICIAL_SUPPLY_ADDRESS',url:r.url,position:'공급탭 '+String(chunkIndex+1)+' / 소재지',value:address});
  for(const tr of chunk.matchAll(/<tr\b[^>]*class=["'][^"']*tb_house_con[^"']*["'][^>]*>([\s\S]*?)<\/tr>/gi)){const cells=[...tr[1].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map(m=>ghTextV4(m[1]));if(/^(?:합계|소계|총계)$/.test(cells[0]))continue;const area=areaNumber52A(cells[1]);if(!area||area>1000)throw Error('PARSE: GH 주택형 전용면적 변경');const num=x=>/^\d[\d,]*$/.test(x||'')?Number(x.replace(/,/g,'')):'원문 확인 필요';d.units.push({complex:name||'단지명 확인 필요',type:cells[0],area,count:num(cells[2]),deposit:num(cells[3]),monthly:num(cells[4]),evidence:cells.join(' | ')});}
  for(const li of chunk.matchAll(/<li\b[^>]*>([\s\S]*?)<\/li>/gi)){const t=ghTextV4(li[1]);if(!/온라인접수기간|현장접수기간/.test(t))continue;const dates=[...t.matchAll(/(20\d{2}[.\/-]\d{1,2}[.\/-]\d{1,2})\s*(\d{2}:\d{2})?/g)];if(dates.length>=2)schedules.push({complex:name,label:t,begin:ghDateV4(dates[0][1]),end:ghDateV4(dates[dates.length-1][1]),endTime:dates[dates.length-1][2]||'',evidence:t});}
 }
 if(schedules.length){d.schedules=schedules;d.begin=schedules.map(s=>s.begin).sort()[0];d.end=schedules.map(s=>s.end).sort().slice(-1)[0];const times=[...new Set(schedules.map(s=>s.endTime).filter(Boolean))];d.endTime=times.length===1?times[0]:'주택형별 원문 확인 필요';}
 if(d.units.length){d.min=Math.min(...d.units.map(u=>u.area));d.max=Math.max(...d.units.map(u=>u.area));d.count=d.units.every(u=>typeof u.count==='number')?d.units.reduce((n,u)=>n+u.count,0):'';d.complexes=d.complexes.filter(x=>x!==r.title);}
 for(const tr of html.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)){const m=tr[1].match(/<th\b[^>]*>([\s\S]*?)<\/th>\s*<td\b[^>]*>([\s\S]*?)<\/td>/i);if(!m)continue;const label=ghTextV4(m[1]).replace(/\s+/g,'');if(!/^(?:공급(?:주택)?(?:소재지|주소)|주택(?:소재지|주소))$/.test(label))continue;const address=ghTextV4(m[2]);if(address&&!d.regionEvidence.some(e=>e.value===address)){d.address+=(d.address?'; ':'')+address;d.regionEvidence.push({kind:'OFFICIAL_SUPPLY_ADDRESS',url:r.url,position:'상세 표 '+label+' 행',value:address});}}
 d.status='GH 공식 HTML '+d.units.length+'개 주택형/첨부 링크 확인·가격/자격/건물유형 원문 확인 필요';return d;
}
function enableGHV4(){const ss=SpreadsheetApp.openById(SPREADSHEET_ID),p=PropertiesService.getScriptProperties();if(!p.getProperty('LIST_AUTO_VERIFIED4'))throw Error('기존18경로 시간 기반 2회 정상 검증 선행 필요');ensureGHV4(ss);p.setProperty('GH_ENABLED4','true');for(const cfg of GH_ROUTES4)if(!readV4(ss.getSheetByName('수집상태')).some(r=>r[0]===cfg.id)){const src={...cfg,agency:'GH',label:cfg.id,from:'전체 게시 이력'};sourceAttempt(ss,src,todayKst());sourceFinish(ss,src,[],'PARTIAL: GH 최초 전체대조 대기·정상 0건 아님',todayKst());}p.setProperty('FULL_NORMAL35','GH 확대 후 전체 정상 점검 미완료');ss.getSheetByName('개발검증').appendRow(['GH 수집 활성','실제 설정',nowKst()+' | 원문/첨부/외부 운영기관 조건 미검증 별도']);console.log('GH_ENABLED4');}
function parseGHNoticeV4(html,cfg){const t=ghTextV4(html),m=t.match(/총게시물\s*:\s*([\d,]+)\s*페이지\s*:\s*(\d+)\s*\/\s*(\d+)/);if(!m)throw Error('PARSE: GH 공지 총건수/페이지 없음');const records=[],pinned=[];for(const tr of html.matchAll(/<tr\b([^>]*)>([\s\S]*?)<\/tr>/gi)){const a=tr[2].match(/<a\b[^>]*data-sn=["'](\d+)["'][^>]*>([\s\S]*?)<\/a>/i);if(!a)continue;const td=[...tr[2].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map(x=>ghTextV4(x[1])),r={number:a[1],title:ghTextV4(a[2]),published:ghDateV4(td[3]),region:'',type:'GH 공지',url:cfg.detail+'?bbsSn='+a[1]};r._parserVersion='GH_LIST52A3';Object.assign(r,ghListRegionEvidence52A(html,tr[0],r.url));if(!r.published)throw Error('PARSE: GH 공지 날짜 없음');if(/\bnoti\b/.test(tr[1]))pinned.push({...r,pinned:true});else records.push(r);}const total=Number(m[1].replace(/,/g,'')),page=Number(m[2]),pages=Number(m[3]);if(records.length!==Math.min(10,Math.max(0,total-new Set(pinned.map(r=>r.number)).size-(page-1)*10)))throw Error('PARSE: GH 공지 행 불일치');return{total,page,pages,records,pinned};}
function upsertGHAuditV4(s,rows){const all=readV4(s),ix=new Map(all.slice(1).map((r,i)=>[r[0],i+1]));for(const r of rows){if(ix.has(r[0]))all[ix.get(r[0])]=r;else{ix.set(r[0],all.length);all.push(r);}}if(all.length>s.getMaxRows())s.insertRowsAfter(s.getMaxRows(),all.length-s.getMaxRows());if(all.length>1)s.getRange(2,1,all.length-1,13).setValues(all.slice(1).map(r=>Array.from({length:13},(_,i)=>r[i]??'')));}
function saveGHFollowupsV4(ss,cfg,rows){rows=rows.filter(r=>ghDispositionV4(r.title,cfg)[0]==='중요후속');if(!rows.length)return;let s=ss.getSheetByName('GH후속안내');if(!s){s=ss.insertSheet('GH후속안내');s.appendRow(['공고ID','제목','게시일','분류','원모집ID','연결/변경 근거','원문URL','마지막확인','본문','변경전','변경후']);s.setFrozenRows(1);}const existing=new Set(readV4(s).slice(1).map(r=>r[0])),q=ss.getSheetByName('발송대기'),keys=new Set(readV4(q).slice(1).map(r=>r[0]));for(const r of rows){if(ghDispositionV4(r.title,cfg)[0]!=='중요후속')continue;const id=normalizeGHV4(r,cfg).id,key=id+':FOLLOWUP:'+digest(JSON.stringify([r.title,r.published]));if(!existing.has(id)){const props=PropertiesService.getScriptProperties(),initial=!!props.getProperty('GH_INITIAL4_'+cfg.id)&&r.published<kstDayV3(props.getProperty('GH_STARTED4_'+cfg.id));upsertTable(s,[[id,r.title,r.published,'중요 후속 검토','','원 모집/변경내용 원문 확인 필요',r.url,nowKst(),'원문 확인 필요','원문 확인 필요','원문 확인 필요',initial?'초기백필 후속':'신규발견 후속',nowKst()]]);existing.add(id);}if(!keys.has(key)){const recent=dayDiffV4(todayKst(),r.published)<=7;q.appendRow([key,id,nowKst(),'후속안내','미발송','GH 후속·원 모집 연결 검토',r.url,'GH중요후속',recent?'Y':'N',recent?'최근 중요 후속 안내·변경내용 원문 확인 필요':'초기 과거 후속·현재 유효성/연결 확인 전 명시적 보류']);keys.add(key);}}}
function verifyPhase4Status(){const p=PropertiesService.getScriptProperties(),ss=SpreadsheetApp.openById(SPREADSHEET_ID),m=readV4(ss.getSheetByName('공고원장')).slice(4).filter(r=>r[0]);console.log(JSON.stringify({master:m.length,unique:new Set(m.map(r=>r[0])).size,listAutoCount:Number(p.getProperty('LIST_AUTO_OK4')||0),listAutoVerified:p.getProperty('LIST_AUTO_VERIFIED4')||'',ghEnabled:p.getProperty('GH_ENABLED4')==='true',triggers:ScriptApp.getProjectTriggers().map(t=>({handler:t.getHandlerFunction(),type:String(t.getEventType())})),checkpoints:GH_ROUTES4.map(c=>{let x;try{x=loadCheckpoint52A(p,'GH_PAGE4_'+c.id);}catch(e){}return {route:c.id,nextPage:x&&x.page,total:x&&x.total,ids:x&&x.ids.length};})}));}
function runGHVerificationV4(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 수집 실행중');const start=Date.now();let ss;V4_MODE='후처리';V4_END=start+210000;try{const p=PropertiesService.getScriptProperties();if(p.getProperty('GH_ENABLED4')!=='true')throw Error('GH 활성화 전·기존18개 자동검증 선행');ss=SpreadsheetApp.openById(SPREADSHEET_ID);measureV4('GH 수동 전체대조/재개',()=>runGHJobsV4(ss,start+105000));measureV4('모니터/현황판',()=>{refreshMonitor(ss);refreshRegionV4(ss);refreshUserDashboardV4(ss);});ss.getSheetByName('개발검증').appendRow(['GH 실제 대조','수동 실행',nowKst()+' | '+((Date.now()-start)/1000).toFixed(3)+'초 | 경로별 정상/부분누락 별도']);}finally{if(ss){V4_STAGE.push(['총 실행',Date.now()-start]);flushMetricsV4(ss,Utilities.formatDate(new Date(start),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'),'GH 수동 검증','경로별 상태 참조');}resetV4();lock.releaseLock();}}
function verifyGHCurrentDetailV4(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 수집 실행중');try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID),row=readV4(ss.getSheetByName('공고원장')).slice(4).find(r=>r[0]==='GH:APPLY:839');if(!row)throw Error('공식 GH 목록 저장 선행 필요');const r={id:row[0],number:String(row[34]),title:row[5],published:kstDayV3(row[2]),url:row[26]},d=parseGHDetailV4(fetchText(r.url),r);saveDetail(ss,r,d);ss.getSheetByName('개발검증').appendRow(['GH 현재 공고 상세','실제 공식 HTML',nowKst()+' | '+r.id+' | 단지 '+d.complexes.length+' | 주택형 '+d.units.length+' | 모집표 합 '+d.count+' | '+d.begin+'~'+d.end+' '+d.endTime+' | 가격/자격 미확인']);refreshMonitor(ss);refreshRegionV4(ss);refreshUserDashboardV4(ss);console.log('GH_CURRENT_DETAIL '+d.units.length);}finally{resetV4();lock.releaseLock();}}

function ghCheckpointCompleteV4(state,cfg){if(state.ids.length!==state.total)return false;if(cfg.kind!=='notice')return new Set(state.ids).size===state.total;const counts=new Map();for(const id of state.ids)counts.set(id,(counts.get(id)||0)+1);return [...counts].every(([id,n])=>n===1||(n===2&&(state.pinIds||[]).includes(id)));}
function validAliasesV4(ss,master){const s=ss.getSheetByName('교차게시검토');if(!s)return [];const map=new Map(master.map(r=>[r[0],r])),out=[];for(const r of readV4(s).slice(1)){if(r[4]!=='동일 모집 확인·원장 보존'||!map.has(r[0])||!map.has(r[1]))continue;try{const p=JSON.parse(r[2]);if(map.get(r[0])[36]===p.webListHash&&map.get(r[1])[36]===p.applyListHash)out.push([r[0],r[1]]);}catch(e){}}return out;}
function verifyGHCrossPostingV4(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 수집 실행중');try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID),master=readV4(ss.getSheetByName('공고원장')).slice(4),web=master.find(r=>r[0]==='GH:WEB:65277'),apply=master.find(r=>r[0]==='GH:APPLY:839');if(!web||!apply)throw Error('GH 두 공식 목록의 저장 선행 필요');const record=r=>({id:r[0],number:String(r[34]),title:r[5],published:kstDayV3(r[2]),url:r[26]}),w=parseGHDetailV4(fetchText(web[26]),record(web)),a=parseGHDetailV4(fetchText(apply[26]),record(apply)),list=(w.bodyEvidence.match(/모집지구\s*[-:：]\s*([\s\S]+)/)||[])[1]||'',tokens=list.split(',').map(x=>x.trim()).filter(Boolean),norm=x=>x.replace(/[\s()（）-]/g,''),matches=tokens.map(t=>a.complexes.filter(x=>norm(x).includes(norm(t))));
 if(kstDayV3(web[2])!==kstDayV3(apply[2])||tokens.length!==24||matches.some(x=>x.length!==1)||new Set(matches.flat()).size!==24||!w.bodyEvidence.includes('apply.gh.or.kr')||!(/26년.*하반기.*행복주택.*예비입주자.*추가모집/.test(web[5])&&/26년.*하반기.*행복주택.*예비입주자.*추가모집/.test(apply[5])))throw Error('교차게시 근거 부족·병합하지 않음');
 const proof={why:'기관 원문이 GH청약센터로 안내·같은 게시일/공급유형/26년 하반기 회차·24개 모집지구 전부 1:1 대조',webListHash:web[36],applyListHash:apply[36],published:kstDayV3(web[2]),districts:tokens.map((t,i)=>[t,matches[i][0]]),webUrl:web[26],applyUrl:apply[26]};upsertTable(ss.getSheetByName('교차게시검토'),[[web[0],apply[0],JSON.stringify(proof),nowKst(),'동일 모집 확인·원장 보존']]);filterQueueRegionV4(ss);refreshUserDashboardV4(ss);ss.getSheetByName('개발검증').appendRow(['GH 교차게시 대조','실제 두 공식 원문',nowKst()+' | '+web[0]+' → '+apply[0]+' | 24지구·동일회차/게시일·센터 안내 근거; 원장ID 삭제 없음']);console.log('GH_CROSS_CONFIRMED');}finally{resetV4();lock.releaseLock();}}

function ghHeadUnchangedV4(full,current,hasCheckpoint,due,now){return !!(full&&!hasCheckpoint&&due>now&&full.total===current.total&&full.pages===current.pages&&full.first===current.first);}

function ghPageNeedsPolicyV4(records,changed,knownOrigins){return changed||records.some(r=>!knownOrigins.has(r.id));}

function reclassifyGHAuditV4(ss){const s=ss.getSheetByName('GH게시판대조'),rows=readV4(s).slice(1),cfgs=new Map(GH_ROUTES4.map(c=>[c.id,c]));if(rows.length)s.getRange(2,9,rows.length,2).setValues(rows.map(r=>ghDispositionV4(r[6],cfgs.get(r[1]))));}

// Explicit migration cohort from the first GH full-history connection, before live operation.
const GH_INITIAL_FOLLOWUP4=new Set(['GH:WEB:62576','GH:WEB:61600','GH:NOTICE:468','GH:NOTICE:461','GH:NOTICE:459','GH:NOTICE:457','GH:WEB:51855']);
function ghFollowupPolicyV4(event,follow,initial,linkedDecision){
 if(['발송완료','발송 완료'].includes(event[4]))return event.slice(7,10);
 const cfg={kind:String(event[1]).startsWith('GH:NOTICE:')?'notice':'web'},classification=ghDispositionV4(String(follow&&follow[1]||''),cfg)[0];
 if(!follow||classification!=='중요후속')return ['GH후속 재분류','N','공식 목록 최신 분류는 중요후속 아님 또는 근거 미확인·이벤트 보존·원문 확인 필요'];
 if(initial&&!linkedDecision)return ['GH초기후속·확인대기','N','최초 GH 전체연결의 과거 후속·초기 대량 알림 차단 고정; 원모집 유효성/중요 변경 원문 확인 필요'];
 if(initial&&!['접수중','접수예정'].includes(linkedDecision[1]))return ['GH초기후속·확인대기','N','과거 초기 후속·연결된 원모집 현재/향후 접수 미확인·임의 마감 아님'];
 return ['GH중요후속','Y',initial?'과거 초기 중요후속·연결 원모집 현재/향후 접수 근거 확인; 변경내용/자격은 별도':'새로 발견한 중요후속 안내·원모집 연결/변경내용 원문 확인 필요'];
}
function protectGHFollowupsV4(ss){
 const s=ss.getSheetByName('GH후속안내');if(!s)return;const follow=readV4(s).slice(1).filter(r=>r[0]);if(!follow.length)return;
 const q=ss.getSheetByName('발송대기'),events=readV4(q).slice(1),decisions=new Map(readV4(ss.getSheetByName('공고판정')).slice(1).map(r=>[r[0],r])),fm=new Map(follow.map(r=>[r[0],r]));
 s.getRange(1,12,1,2).setValues([['최초 후속 적재구분(고정)','최초 후속발견(KST)']]);
 for(const r of follow){if(!r[11])r[11]=GH_INITIAL_FOLLOWUP4.has(r[0])?'초기백필 후속':'신규발견 후속';if(!r[12])r[12]=stampV3((events.find(e=>e[1]===r[0]&&e[3]==='후속안내')||[])[2])||nowKst();}
 s.getRange(2,12,follow.length,2).setValues(follow.map(r=>r.slice(11,13)));
 s.getRange(2,4,follow.length,1).setValues(follow.map(r=>[ghDispositionV4(String(r[1]),{kind:String(r[0]).startsWith('GH:NOTICE:')?'notice':'web'})[0]==='중요후속'?'중요 후속 검토':'일반/모집 안내·최신 분류 재검토']));
 if(events.length)q.getRange(2,8,events.length,3).setValues(events.map(e=>String(e[1]).startsWith('GH:')&&e[3]==='후속안내'?ghFollowupPolicyV4(e,fm.get(e[1]),!!(fm.get(e[1])&&String(fm.get(e[1])[11]).startsWith('초기백필')),decisions.get((fm.get(e[1])||[])[4])):e.slice(7,10)));
}
function reconcileGHFollowupPolicyV4(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 수집 실행중');try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID);reconcileDecisionsV3(ss);protectGHFollowupsV4(ss);refreshUserDashboardV4(ss);ss.getSheetByName('개발검증').appendRow(['GH 초기후속 후보 재평가','실제 보완',nowKst()+' | 고정 최초구분·현재 공식 분류 대조·이벤트/원장 삭제 없음·외부 발송 없음']);console.log('GH_FOLLOWUP_POLICY_RECONCILED');}finally{resetV4();lock.releaseLock();}}

function ghOfficialFingerprintV4(raw){return JSON.stringify(['number','title','published','type','region','boardDeadline','boardStatus','url'].map(k=>String(k==='region'?ghListingRegion52A(raw):raw&&raw[k]!==undefined?raw[k]:'')));}
function planUpsert(existing,records,now,hashFn,context){
 if(!records.some(r=>String(r.id).startsWith('GH:')))return planUpsert35V4(existing,records,now,hashFn,context);
 const old=new Map(existing.map(r=>[r[0],r])),snapshots=context&&context.snapshots||SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName('수집원본').getDataRange().getValues(),sm=new Map(snapshots.map(r=>[r[0],r]));let same=0;
 const effective=records.filter(r=>{if(!String(r.id).startsWith('GH:')||!old.has(r.id))return true;const snap=sm.get(old.get(r.id)[38]);if(!snap)throw Error('PARSE: GH 원천 비교 스냅샷 누락');let a,b;try{a=JSON.parse(snap[5]);b=JSON.parse(r.raw);}catch(e){throw Error('PARSE: GH 원천 비교 JSON 오류');}if(ghOfficialFingerprintV4(a)===ghOfficialFingerprintV4(b)){same++;return false;}return true;});
 const result=planUpsert35V4(existing,effective,now,hashFn,context||{snapshots});result.unchanged+=same;return result;
}
function ghChangePoliciesV4(events,snapshots){
 const prior=new Map(),priorRaw=new Map(),comparisons=new Map();for(const r of snapshots){const k=String(r[0]||'');if(!k.startsWith('GH:'))continue;const id=k.split(':').slice(0,3).join(':');let raw;try{raw=JSON.parse(r[5]);}catch(e){comparisons.set(k,'원천 비교 미확인');continue;}const fp=ghOfficialFingerprintV4(raw);comparisons.set(k,prior.has(id)?prior.get(id)===fp?'동일':'변경':'원천 비교 미확인');if(priorRaw.has(id)&&raw._parserVersion==='GH_LIST52A3'&&priorRaw.get(id)._parserVersion!=='GH_LIST52A3'&&!priorRaw.get(id).regionEvidence&&raw.regionEvidence&&raw.regionEvidence.kind==='OFFICIAL_SUPPLY_COLUMN'&&JSON.stringify(['number','title','published','type','boardDeadline','boardStatus','url'].map(f=>String(priorRaw.get(id)[f]??'')))===JSON.stringify(['number','title','published','type','boardDeadline','boardStatus','url'].map(f=>String(raw[f]??''))))comparisons.set(k,'지역근거보완');prior.set(id,fp);priorRaw.set(id,raw);}
 return events.map(e=>{if(!String(e[1]).startsWith('GH:')||e[3]!=='변경'||['발송완료','발송 완료'].includes(e[4]))return e.slice(7,10);const c=comparisons.get(e[0]);return c==='지역근거보완'?['공급지역 근거 보완','N','새 파서의 공급 소재지 근거 최초 확인·공식 모집 변경 근거 없음·기존 발견 이벤트 별도 재평가']:c==='동일'?['파생분류 보완','N','공식 원천 필드 동일·내부 공급분류/파서 보완; 이벤트/이력 보존']:c==='변경'?['중요변경 후보','Y','공식 목록 원천 변경 확인·중요도/정정 내용은 원문 추가 확인']:['GH변경·비교확인대기','N','이전/현재 공식 원천 비교 근거 확인 필요·이벤트 보존'];});
}
function reconcileGHChangesV4(ss){const q=ss.getSheetByName('발송대기'),events=readV4(q).slice(1);if(!events.some(e=>String(e[1]).startsWith('GH:')&&e[3]==='변경'))return;const policies=ghChangePoliciesV4(events,readV4(ss.getSheetByName('수집원본')).slice(1));if(events.length)q.getRange(2,8,events.length,3).setValues(policies);}
function verifyGHListingReplayV4(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 수집 실행중');try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID),cfg=GH_ROUTES4[0],x=parseGHListV4(fetchText(ghUrlV4(cfg,1)),cfg),records=x.records.filter(r=>ghDispositionV4(r.title,cfg)[0]==='수집').map(r=>normalizeGHV4(r,cfg)),m=readV4(ss.getSheetByName('공고원장')).slice(4);const p=planUpsert(m,records,nowKst(),digest);if(p.added||p.changed||p.events.length)throw Error('PARSE: GH 동일 공식 목록 재검증에서 예상치 않은 신규/변경 '+p.added+'/'+p.changed);reconcileGHChangesV4(ss);ss.getSheetByName('개발검증').appendRow(['GH 공식 목록 재수집 계획 검증','실제 공식 첫100행·원장/원천 대조',nowKst()+' | 수집대상 '+records.length+' | 추가/변경/이벤트 0; 원장 저장은 불필요하여 생략·전체572 재조회 아님']);console.log('GH_LIST_REPLAY '+records.length+' ZERO_WRITES_ZERO_EVENTS');}finally{resetV4();lock.releaseLock();}}

var GH_COMPARE_CACHE4=null;
function ghRecordsUnchangedV4(ss,records){if(!records.length)return true;if(!GH_COMPARE_CACHE4)GH_COMPARE_CACHE4={master:new Map(readV4(ss.getSheetByName('공고원장')).slice(4).map(r=>[r[0],r])),raw:new Map(readV4(ss.getSheetByName('수집원본')).slice(1).map(r=>[r[0],r]))};return records.every(r=>{if(resultNotice52A(r.title)&&noticeKind52A(r.title)==='EXCLUDED'&&GH_COMPARE_CACHE4.raw.has(r.id+':RESULT:'+digest(semantic(r))))return true;const old=GH_COMPARE_CACHE4.master.get(r.id);if(!old)return false;const snap=GH_COMPARE_CACHE4.raw.get(old[38]);if(!snap)throw Error('PARSE: GH 원천 비교 스냅샷 누락');try{return ghOfficialFingerprintV4(JSON.parse(snap[5]))===ghOfficialFingerprintV4(JSON.parse(r.raw));}catch(e){throw Error('PARSE: GH 원천 비교 JSON 오류');}});}

const LEGACY_BOOTSTRAP_SH4=new Set(["SH:311521", "SH:311549", "SH:311349", "SH:311087", "SH:311200", "SH:310653", "SH:310650", "SH:310673", "SH:310258", "SH:310041", "SH:309467", "SH:310107", "SH:309337", "SH:308446", "SH:308971", "SH:308944", "SH:308887", "SH:308340", "SH:308644", "SH:308394", "SH:308167", "SH:308123", "SH:306986", "SH:306722", "SH:306214", "SH:306205", "SH:306218", "SH:306066", "SH:306065", "SH:306011", "SH:305221", "SH:305240", "SH:304925", "SH:304864", "SH:304555", "SH:305517", "SH:304295", "SH:304106", "SH:303656", "SH:303584", "SH:303557", "SH:303480", "SH:302368", "SH:302646", "SH:301406", "SH:301759", "SH:300255", "SH:299904", "SH:299109", "SH:299475", "SH:299479", "SH:299476", "SH:304699", "SH:311656", "SH:301479", "SH:301076", "SH:311754", "SH:311428", "SH:311375", "SH:310976", "SH:311005", "SH:310845", "SH:310784", "SH:310782", "SH:310779", "SH:310672", "SH:310580", "SH:310629", "SH:310575"]);
const USER_SHEET4='🏡 신혼집 청약 현황판';
function ensureOriginsV4(ss){if(!ss.getSheetByName('발견구분')){const s=ss.insertSheet('발견구분');s.appendRow(['공고ID','최초 적재구분(고정)','최초발견','공식게시일','근거']);s.setFrozenRows(1);}const s=ss.getSheetByName('발견구분'),known=new Set(readV4(s).slice(1).map(r=>r[0])),first=new Map();for(const e of readV4(ss.getSheetByName('발송대기')).slice(1))if(e[3]==='신규'&&!first.has(e[1]))first.set(e[1],e);const fresh=[];for(const m of readV4(ss.getSheetByName('공고원장')).slice(4)){if(!m[0]||known.has(m[0]))continue;const e=first.get(m[0]),kind=LEGACY_BOOTSTRAP_SH4.has(m[0])?'초기백필·3차 SH 최초 연결':e&&e[7]||'발견구분 확인 필요';fresh.push([m[0],kind,stampV3(m[1]),kstDayV3(m[2]),'최초 신규 이벤트 기준 고정·최초발견과 게시일 구분']);}upsertTable(s,fresh);const old=readV4(s);const changed=old.slice(1).filter(r=>LEGACY_BOOTSTRAP_SH4.has(r[0])&&!String(r[1]).startsWith('초기백필')).map(r=>[r[0],'초기백필·3차 SH 최초 연결',r[2],r[3],'4차 시작 전 SH69개 최초 연결 코호트·인수인계/최초발견시각 대조. 현재 유효 공고와 알림 후보는 별도 보존']);upsertTable(s,changed);}
function dayDiffV4(a,b){if(!a||!b)return null;return Math.round((Date.parse(a+'T00:00:00Z')-Date.parse(b+'T00:00:00Z'))/86400000);}
function firstMsV4(v){if(v instanceof Date)return v.getTime();let s=stampV3(v);if(/^20\d{2}-\d{2}-\d{2}$/.test(s))s+=' 00:00:00';return Date.parse(s.replace(' ','T')+(s.includes('Z')||/[+-]\d{2}:\d{2}$/.test(s)?'':'+09:00'));}
function dashboardDataV4(master,decisions,policy,origins,events,now,today,aliases=[]){
 const dm=new Map(decisions.map(r=>[r[0],r])),gm=new Map(policy.map(r=>[r[0],r])),om=new Map(origins.map(r=>[r[0],r[1]])),em=new Map();for(const e of events)if(e[3]==='신규'&&!em.has(e[1]))em.set(e[1],e);
 const omit=new Set(aliases.map(r=>r[0])),unique=[...new Map(master.filter(r=>r[0]&&!omit.has(r[0])).map(r=>[r[0],r])).values()],target=unique.filter(m=>['서울·경기','서울·경기 포함/복수'].includes((gm.get(m[0])||[])[1])&&(dm.get(m[0])||[])[1]!=='모집대상 제외');
 const initial=m=>/초기백필|초기.*백필|GH초기연결|초기\/과거백필/.test(om.get(m[0])||''),recent=target.filter(m=>!initial(m)),inDays=(m,days)=>{if(days!==1){const age=dayDiffV4(today,kstDayV3(m[1]));return age!==null&&age>=0&&age<days;}const t=firstMsV4(m[1]);return Number.isFinite(t)&&now-t>=0&&now-t<days*86400000;};
 const current=target.filter(m=>['접수중','접수예정'].includes((dm.get(m[0])||[])[1])),near=target.filter(m=>{const d=dm.get(m[0])||[];return d[1]==='접수중'&&[1,3].includes(dayDiffV4(kstDayV3(d[5]),today));});
 const last7=recent.filter(m=>inDays(m,7)),previous7=recent.filter(m=>inDays(m,14)&&!inDays(m,7)),metrics={day:recent.filter(m=>inDays(m,1)).length,week:last7.length,delta:last7.length-previous7.length,important:current.filter(m=>(dm.get(m[0])||[])[2]==='★중요★').length,review:target.filter(m=>{const d=dm.get(m[0])||[];return d[2]==='★검토 필요★'&&!['마감','취소','모집대상 제외'].includes(d[1]);}).length,accepting:target.filter(m=>(dm.get(m[0])||[])[1]==='접수중').length,starting:target.filter(m=>{const d=dm.get(m[0])||[],n=dayDiffV4(kstDayV3(d[4]),today);return d[1]==='접수예정'&&n!==null&&n>=0&&n<=7;}).length,closing:near.length,regionUnknown:unique.filter(m=>(gm.get(m[0])||[])[1]==='지역 확인 필요').length};
 const newest=recent.slice().sort((a,b)=>firstMsV4(b[1])-firstMsV4(a[1])).slice(0,20).map(m=>{const d=dm.get(m[0])||[],e=em.get(m[0])||[];return[stampV3(m[1]),kstDayV3(m[2]),m[4],m[5],d[10]||m[8],d[8]||m[3],e[7]||m[7],d[2]||'일반',d[4]&&d[5]?kstDayV3(d[4])+' ~ '+kstDayV3(d[5]):'접수기간 확인 필요',m[26]];});
 const interest=target.filter(m=>{const d=dm.get(m[0])||[];return ['★중요★','★검토 필요★'].includes(d[2])&&!['마감','취소','모집대상 제외'].includes(d[1]);}).sort((a,b)=>{const da=dm.get(a[0])||[],db=dm.get(b[0])||[],rank=d=>(d[1]==='접수중'?0:d[1]==='접수예정'?1:2)+(d[2]==='★중요★'?0:3);return rank(da)-rank(db)||String(da[5]||'9999').localeCompare(String(db[5]||'9999'))||kstDayV3(b[2]).localeCompare(kstDayV3(a[2]));}).slice(0,20).map(m=>{const d=dm.get(m[0])||[];return[d[1]||'기간 확인 필요',m[13]?'최대 '+m[13]+'㎡':'면적 확인 필요',m[4],m[5],d[10]||m[8],d[8]||m[3],'자격 확인 필요',d[2],d[3]||'근거 원문 확인 필요',m[26]];});
 const schedule=current.slice().sort((a,b)=>{const da=dm.get(a[0])||[],db=dm.get(b[0])||[];return Number(db[1]==='접수중')-Number(da[1]==='접수중')||String(da[5]||'9999').localeCompare(String(db[5]||'9999'));}).slice(0,20).map(m=>{const d=dm.get(m[0])||[],n=dayDiffV4(kstDayV3(d[5]),today);return[d[1],kstDayV3(d[4]),kstDayV3(d[5]),m[5],d[10]||m[8],d[8]||m[3],n!==null?'D-'+n:'마감 확인 필요',d[2]||'일반','정확한 마감시각 원문 확인 필요',m[26]];});
 const count=(rows,fn)=>{const x={};for(const r of rows){const k=fn(r);x[k]=(x[k]||0)+1;}return Object.entries(x);};
 const daily=[];for(let n=6;n>=0;n--){const day=new Date(Date.parse(today+'T00:00:00Z')-n*86400000).toISOString().slice(0,10);daily.push([day,last7.filter(m=>kstDayV3(m[1])===day).length]);}
 return {scheduleIds:current.slice().sort((a,b)=>{const da=dm.get(a[0])||[],db=dm.get(b[0])||[];return Number(db[1]==='접수중')-Number(da[1]==='접수중')||String(da[5]||'9999').localeCompare(String(db[5]||'9999'));}).slice(0,20).map(m=>m[0]),metrics,newest,interest,schedule,daily,agencies:count(last7,m=>m[4]),regions:count(last7,m=>/서울/.test((gm.get(m[0])||[])[5])?'서울':'경기'),supply:count(target,m=>(dm.get(m[0])||[])[8]||m[3]),unknown:unique.filter(m=>(gm.get(m[0])||[])[1]==='지역 확인 필요').slice(0,10).map(m=>[stampV3(m[1]),kstDayV3(m[2]),m[4],m[5],m[8]||'미확인',m[3],m[7],'지역 확인 필요','서울·경기 포함 여부 확인 전 제외하지 않음',m[26]])};
}
function setDashboardBlockV4(s,row,rows,height){const width=10,data=Array.from({length:height},(_,i)=>Array.from({length:width},(_,j)=>rows[i]&&rows[i][j]!==undefined?rows[i][j]:''));for(const r of data)if(typeof r[0]==='string')r[0]=r[0].replace(/^(20\d{2}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})$/,'$1\n$2');s.getRange(row,1,height,width).setValues(data);s.getRange(row,10,height,1).setRichTextValues(data.map(r=>[/^https?:\/\//.test(String(r[9]))?SpreadsheetApp.newRichTextValue().setText('공고 원문 ↗').setLinkUrl(r[9]).build():SpreadsheetApp.newRichTextValue().setText(String(r[9]||'')).build()]));if(height>1)s.setRowHeights(row,height,64);}
function refreshUserDashboardV4(ss){
 const p=PropertiesService.getScriptProperties(),started=Date.now(),previous=p.getProperty('USER_DASHBOARD4')||'미완료';let s=ss.getSheetByName(USER_SHEET4);if(!s){s=ss.insertSheet(USER_SHEET4);formatDashboardLean52A6(s);}const state={state:'RUNNING',at:nowKst(),previousComplete:previous};p.setProperty('USER_RENDER_STATE52A6',JSON.stringify(state));s.getRange('A2').setValue('집계 중 · 이전 완료 '+previous+' KST · 새 집계 완료 전 최신 아님');
 try{
  ensureOriginsV4(ss);const masterRows=readV4(ss.getSheetByName('공고원장')).slice(4),data=dashboardDataV4(masterRows,readV4(ss.getSheetByName('공고판정')).slice(1),readV4(ss.getSheetByName('지역정책')).slice(1),readV4(ss.getSheetByName('발견구분')).slice(1),readV4(ss.getSheetByName('발송대기')).slice(1),Date.now(),todayKst(),validAliasesV4(ss,masterRows)),m=data.metrics;
  const fullDetails=new Map(readV4(ss.getSheetByName('공고상세')).slice(1).map(r=>[r[0],r]));for(const [i,r]of data.schedule.entries()){try{const d=JSON.parse((fullDetails.get(data.scheduleIds[i])||[])[16]||'{}');if(d.endTime)r[8]=d.endTime+' KST · 주택형별 일정 근거 확인';}catch(e){}}
  const old=s.getDataRange().getValues(),links=s.getRange(1,10,106,1).getRichTextValues();for(let i=0;i<links.length;i++){const link=links[i][0]&&links[i][0].getLinkUrl();if(link){while(old.length<=i)old.push([]);old[i][9]=link;}}let written=0,skipped=0;
  const put=(row,col,values,rich=false)=>{const equal=values.every((r,i)=>r.every((v,j)=>(sameCell52A(v,(old[row+i-1]||[])[col+j-1])||sameCell52A(safeText52A(v),(old[row+i-1]||[])[col+j-1]))));if(equal){skipped++;return;}const safe=values.map(r=>r.map(safeText52A));s.getRange(row,col,values.length,values[0].length).setValues(safe);written++;if(rich){s.getRange(row,10,values.length,1).setRichTextValues(values.map(r=>[(()=>{const link=/^https?:\/\//.test(String(r[9])),b=SpreadsheetApp.newRichTextValue().setText(link?'공고 원문 ↗':String(r[9]||''));if(link)b.setLinkUrl(r[9]);return b.build();})()]));written++;}for(let i=0;i<values.length;i++){while(old.length<row+i)old.push([]);for(let j=0;j<values[i].length;j++)old[row+i-1][col+j-1]=values[i][j];}};
  put(1,1,[['🏡 신혼집 청약 현황판']]);const metrics=[[4,['최근 24시간 신규 발견','최근 7일 신규(오늘 포함)','유효 ★중요★','현재 접수 중']],[5,[m.day,m.week,m.important,m.accepting]],[7,['직전 7일 대비','현재/미확인 ★검토 필요★','7일 내 접수 시작','접수 마감 D-3·D-1']],[8,[(m.delta>=0?'+':'')+m.delta,m.review,m.starting,m.closing]]];
  for(const [row,values]of metrics){const anchors=[0,3,6,8],original=old[row-1]||[],hasOther=original.some((v,i)=>i<10&&!anchors.includes(i)&&v!==''&&v!=null);if(hasOther){anchors.forEach((c,i)=>put(row,c+1,[[values[i]]]));}else{const line=Array(10).fill('');anchors.forEach((c,i)=>line[c]=values[i]);put(row,1,[line]);}}
  put(10,1,[['지역 확인 필요 '+m.regionUnknown+'건 별도 검토 · 현재/향후 접수는 확인된 날짜 기준 · 알림 후보와 신청자격은 별도']]);
  const block=(row,rows,height)=>{const values=Array.from({length:height},(_,i)=>Array.from({length:10},(_,j)=>rows[i]&&rows[i][j]!==undefined?rows[i][j]:''));for(const r of values)if(typeof r[0]==='string')r[0]=r[0].replace(/^(20\d{2}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})$/,'$1\n$2');put(row,1,values,height>1);};
  block(12,[['최초 발견(KST)','공식 게시일','기관','최근 발견 모집공고','지역','공급유형','발견/모집 구분','중요도','접수기간','공식 원문']],1);block(13,data.newest.length?data.newest:[['초기 백필을 제외한 서울·경기 신규 발견 없음']],20);
  block(35,[['모집상태','전용면적','기관','관심공고 · 현재/기간미확인','위치','공급유형','신청자격','중요도','선정 이유/미확인 항목','공식 원문']],1);block(36,data.interest,20);
  block(58,[['모집상태','접수 시작일','접수 마감일','청약 일정 · 마감된 공고 제외','위치','공급유형','마감 D-day','중요도','마감시각','공식 원문']],1);block(59,data.schedule,20);
  block(81,[['최초 발견(KST)','공식 게시일','기관','지역 확인 필요 · 임의 제외 금지','공식 지역','공급유형','모집 구분','확인 상태','확인할 항목','공식 원문']],1);block(82,data.unknown,10);
  const rows=Array.from({length:12},()=>Array(10).fill(''));rows[0]=['기관(최근7일)','건수','','지역(최근7일)','건수','','공급유형(누적 대상)','건수','발견일(최근7일)','건수'];for(const [col,items]of [[0,data.agencies],[3,data.regions],[6,data.supply],[8,data.daily]])items.slice(0,11).forEach((r,i)=>{rows[i+1][col]=r[0];rows[i+1][col+1]=r[1];});put(95,1,rows);
  const pointer=JSON.parse(p.getProperty('DERIVED_GEN52A4')||'null'),complete=nowKst();s.getRange('A2').setValue(pointer?'세대 기준 '+pointer.startedAt+' KST · 최신 반영 대기 '+Number(p.getProperty('DERIVED_PENDING52A4')||0)+' · 세대/최신 완료 구분':'서울·경기 우선 · 집계 완료 '+complete+' KST · 신청자격 별도 확인');p.setProperty('USER_DASHBOARD4',complete);p.setProperty('USER_RENDER_STATE52A6',JSON.stringify({state:'COMPLETE',at:complete,elapsedMs:Date.now()-started,writtenGroups:written,skippedGroups:skipped}));
  try{ss.getSheetByName('개발검증').appendRow(['local.6 사용자현황판','집계 완료',complete+' | '+JSON.stringify(m)]);}catch(e){p.setProperty('USER_RENDER_LOG_ERROR52A6',nowKst()+' '+safeError(e));}return data;
 }catch(e){p.setProperty('USER_RENDER_STATE52A6',JSON.stringify({state:'FAILED',at:nowKst(),previousComplete:previous,error:safeError(e)}));throw e;}
}
function formatUserDashboardV4(s){
 s.setFrozenRows(2);s.setHiddenGridlines(true);s.setTabColor('#4b7967');s.getRange('A1:J2').setBackground('#edf4ef');s.getRange('A1:J1').merge().setFontSize(22).setFontWeight('bold').setFontColor('#244b3d');s.getRange('A2:J2').merge().setFontSize(10).setWrap(true);s.setRowHeight(1,44);s.setRowHeight(2,40);
 for(const row of [4,5,7,8])for(const [a,b] of [[1,3],[4,6],[7,8],[9,10]])s.getRange(row,a,1,b-a+1).merge().setBackground(row===5||row===8?'#f2f6f3':'#f7f8f7').setFontSize(row===5||row===8?24:11).setFontWeight('bold');s.setRowHeights(4,5,32);s.getRange('A10:J10').merge().setFontSize(10).setFontColor('#57635c');
 const widths=[115,100,70,330,110,95,115,95,210,85];widths.forEach((w,i)=>s.setColumnWidth(i+1,w));
 for(const row of [12,35,58,81,95]){s.getRange(row,1,1,10).setBackground('#e7ece9').setFontWeight('bold').setWrap(true);s.setRowHeight(row,36);}
 for(const [row,n] of [[13,20],[36,20],[59,20],[82,10]]){s.getRange(row,1,n,10).setFontSize(10).setVerticalAlignment('middle').setWrap(true);s.setRowHeights(row,n,64);s.getRange(row,10,n,1).setFontColor('#1763a2');}
 const rule=SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('★중요★').setBackground('#fff2c7').setFontColor('#704e00').setRanges([s.getRange('H13:H91')]).build(),closing=SpreadsheetApp.newConditionalFormatRule().whenTextContains('D-1').setBackground('#fbe6e4').setRanges([s.getRange('G59:G78')]).build();s.setConditionalFormatRules([rule,closing]);
 ensureDashboardChart52A(s);
}
function installUserDashboardV4(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 수집 실행중');try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID);refreshRegionV4(ss);refreshUserDashboardV4(ss);console.log('USER_DASHBOARD4_READY');}finally{lock.releaseLock();}}

function finalizeHistory41(plan,existing){
 const before=new Map(existing.filter(r=>r[0]).map(r=>[r[0],r]));
 const after=new Map(plan.writes.map(w=>[w.row[0],w.row]));
 const dates=new Set([1,2,17,18,19,20,28]);
 const value=(v,i)=>{
  if(v===null||v===undefined||v==='')return '';
  if(dates.has(i)&&v instanceof Date)return Utilities.formatDate(v,'Asia/Seoul',i===1||i===28?'yyyy-MM-dd HH:mm:ss':'yyyy-MM-dd');
  return String(v);
 };
 for(const h of plan.history){
  const a=before.get(h[0]),b=after.get(h[0]);if(!a||!b)continue;
  const changed=[];for(let i=0;i<31;i++)if(![1,7,28,29].includes(i)&&value(a[i],i)!==value(b[i],i))changed.push(MASTER_HEADERS[i]);
  h[4]=changed.join(', ');if(!changed.length){h[3]='내부 데이터 보완·공식 정정 아님';h[9]='보호 후 공식 필드 변경 없음';for(const e of plan.events)if(e[0]===h[10]){e[7]='파생분류 보완';e[8]='N';e[9]='보호 후 최종 필드 동일·공식 정정 아님';}}h[5]=JSON.stringify(a.slice(0,31));h[6]=JSON.stringify(b.slice(0,31));
 }
 return plan;
}

// 4.2: bounded work units; no triggers, credentials, or notification transport.
var V42_SINGLE=false;
function checkpoint42(props,key,state){
 const ids=state.ids||[],chunkSize=200,chunks=[],hash=digest(JSON.stringify(ids)),previous=JSON.parse(props.getProperty(key)||'null');
 if(!Array.isArray(ids))throw Error('SCHEMA: checkpoint IDs');
 try{
  for(let i=0;i<ids.length;i+=chunkSize){const k=key+':IDS52A:'+hash+':'+(i/chunkSize);props.setProperty(k,JSON.stringify(ids.slice(i,i+chunkSize)));chunks.push(k);}
  const manifest={...state};delete manifest.ids;Object.assign(manifest,{_idChunks52A:chunks,_idHash52A:hash,_idCount52A:ids.length});
  const raw=JSON.stringify(manifest);if(Utilities.newBlob(raw).getBytes().length>=8500)throw Error('PARTIAL: checkpoint manifest 8.5KB');
  // Chunks are immutable/content-addressed; publish pointer LAST. Failed publish preserves prior manifest.
  props.setProperty(key,raw);
 }catch(e){throw Error('PARTIAL: 체크포인트 저장 실패·이전 manifest 보존');}
 for(const k of previous&&previous._idChunks52A||[])if(!chunks.includes(k))props.deleteProperty(k);
}
function shProgress42(props,key){let s;try{s=loadCheckpoint52A(props,key);}catch(e){}return s?'완료 '+Math.max(0,s.page-1)+'/'+(s.pages??'?')+'페이지; 다음 '+s.page+'; 고유ID '+new Set(s.ids||[]).size:'커서 없음·첫페이지부터 재대조';}
function auditPastHistory42(){
 const lock=LockService.getScriptLock();if(!lock.tryLock(1000))throw Error('다른 실행중');
 try{const ss=SpreadsheetApp.openById(SPREADSHEET_ID),history=ss.getSheetByName('정정이력').getDataRange().getValues().slice(4),master=new Map(ss.getSheetByName('공고원장').getDataRange().getValues().slice(4).map(r=>[r[0],r]));let s=ss.getSheetByName('이력보완감사42');if(!s){s=ss.insertSheet('이력보완감사42');s.appendRow(['원본 이벤트ID','보완시각','공고ID','원본 이력시각','구분','필드','현재 원장 확인값','판단근거']);}
 const known=new Set(s.getDataRange().getValues().slice(1).map(r=>r[0]));let count=0;
 for(const h of history){if(h[0]!=='LH:03:2015122300020856'||known.has(h[10]))continue;let a,b;try{a=JSON.parse(h[5]);b=JSON.parse(h[6]);}catch(e){continue;}const m=master.get(h[0]);if(!m)continue;const fields=[14,17,18,19].filter(i=>a[i]!==''&&a[i]!=null&&(b[i]===''||b[i]==null)&&String(m[i])===String(a[i]));if(!fields.length)continue;s.appendRow([h[10],nowKst(),h[0],stampV3(h[1]),'과거 중간값 기록 오류·공식 삭제 아님',fields.map(i=>MASTER_HEADERS[i]).join(', '),JSON.stringify(fields.map(i=>[MASTER_HEADERS[i],m[i]])),'4.1 재현·보호 처리 전 JSON; 원본 이력 보존. 현재 값 확인이며 이후 공식 변경과 구분']);count++;}
 console.log('HISTORY_AUDIT42 '+count+'건 추가·원본 이력 무변경');
 }finally{lock.releaseLock();}
}
function verifyPreservation42(){
 const live=SpreadsheetApp.openById(SPREADSHEET_ID),backup=SpreadsheetApp.openById('1lVimwDwYteElKsXA2BEr1_2JmWfiF6esUr_eCy9p3WQ'),v=(ss,n)=>ss.getSheetByName(n).getDataRange().getValues(),norm=x=>x instanceof Date?Utilities.formatDate(x,'Asia/Seoul','yyyy-MM-dd HH:mm:ss'):String(x??''),same=(a,b)=>norm(a)===norm(b);
 const old=v(backup,'공고원장').slice(4).filter(r=>r[0]),next=v(live,'공고원장').slice(4).filter(r=>r[0]),map=new Map(next.map(r=>[r[0],r])),protectedCols=[0,1,6,9,15,16,20,21,22,23,24,30,39],missing=old.filter(r=>!map.has(r[0])).length,protectedChanged=old.reduce((n,r)=>n+(map.has(r[0])?protectedCols.filter(i=>!same(r[i],map.get(r[0])[i])).length:0),0);
 const keyed=(name,start,key,cols)=>{const a=v(backup,name).slice(start).filter(r=>r[key]),b=v(live,name).slice(start).filter(r=>r[key]),bm=new Map(b.map(r=>[String(r[key]),r]));return {before:a.length,after:b.length,missing:a.filter(r=>!bm.has(String(r[key]))).length,duplicate:b.length-bm.size,changedPreservedCells:a.reduce((n,r)=>n+(bm.has(String(r[key]))?cols.filter(i=>!same(r[i],bm.get(String(r[key]))[i])).length:0),0)};};
 const result={at:nowKst(),master:{before:old.length,after:next.length,missing,duplicate:next.length-map.size,protectedChanged},history:keyed('정정이력',4,10,Array.from({length:11},(_,i)=>i)),events:keyed('발송대기',1,0,[0,1,2,3,4,5,6]),attachments:keyed('첨부파일',1,0,[0,1,2,3,4]),details:keyed('공고상세',1,0,[0]),units:keyed('주택형상세',1,0,[0,1]),activitiesUnchanged:JSON.stringify(v(backup,'청약활동'))===JSON.stringify(v(live,'청약활동'))};
 console.log('PRESERVATION42 '+JSON.stringify(result));return result;
}
function inspectStability42(){
 const p=PropertiesService.getScriptProperties(),all=p.getProperties(),bytes=s=>Utilities.newBlob(String(s)).getBytes().length,now=Date.now(),out={at:nowKst(),release:p.getProperty('RELEASE42'),started:p.getProperty('STARTED42'),accountQuota:'실제 계정 적용량/잔여량 직접 확인 불가·내부 계측과 별도',properties:{count:Object.keys(all).length,totalBytes:Object.keys(all).reduce((n,k)=>n+bytes(k)+bytes(all[k]),0),maxValueBytes:Math.max(0,...Object.keys(all).map(k=>bytes(all[k])))},budgets:['상세','첨부','후속','파생'].map(k=>({kind:k,usedOrReservedMs:ledger42(p,'BUDGET42_'+k,now).reduce((n,r)=>n+r[1],0),entries:ledger42(p,'BUDGET42_'+k,now).length})),legacyUsedOrReservedMs:ledger42(p,'ENRICH_WINDOW4',now).reduce((n,r)=>n+r[1],0),success:['상세','첨부'].map(k=>({kind:k,last:p.getProperty('LAST_SUCCESS42_'+k),count24h:ledger42(p,'PROGRESS42_'+k,now).length})),cursors:Object.keys(all).filter(k=>/^GH_PAGE4_|^SH_PAGE35_/.test(k)).map(k=>{let x;try{x=JSON.parse(all[k]);}catch(e){}return {key:k,bytes:bytes(all[k]),nextPage:x&&x.page,total:x&&x.total,pages:x&&x.pages,seen:x&&Array.isArray(x.ids)?new Set(x.ids).size:null};}),handlers:ScriptApp.getProjectTriggers().map(t=>t.getHandlerFunction())};console.log('DIAGNOSTIC42 '+JSON.stringify(out));return out;
}
function ledger42(p,key,now){
 const rows=JSON.parse(p.getProperty(key)||'[]');
 if(!Array.isArray(rows)||rows.some(r=>!Array.isArray(r)||!Number.isFinite(r[0])||!Number.isFinite(r[1])))throw Error('PARSE: 4.2 예산 이력 오류·보존');
 return rows.filter(r=>r[0]>now-86400000&&r[0]<=now);
}
function admission42(used,slot,budget){return Number.isFinite(budget)&&budget>=0&&used+slot<=budget;}
function workClock42(kind){return 'ROLE_HTTP_AT52A_'+kind;}
function budgetStatus42(p,kind,now,plannedSlot){
 const analysis=kind==='상세'||kind==='첨부',keys=analysis?['ENRICH_WINDOW4','BUDGET42_상세','BUDGET42_첨부']:['BUDGET42_'+kind],rows=keys.flatMap(k=>ledger42(p,k,now)),cap=analysis?Number(p.getProperty('ENRICH_BUDGET_MS4')??600000):300000,slot=plannedSlot??(kind==='상세'?60000:kind==='첨부'?20000:50000),used=rows.reduce((n,r)=>n+r[1],0);
 let left=used,nextMs=admission42(left,slot,cap)?now:null;
 for(const r of rows.slice().sort((a,b)=>a[0]-b[0])){if(nextMs!==null)break;left-=r[1];if(admission42(left,slot,cap))nextMs=r[0]+86400000;}
 return {kind,cap,used,remainingMs:Math.max(0,cap-used),slot,nextMs,canRun:admission42(used,slot,cap)};
}
function budgetWait42(b){return b.kind+' 예산 대기·잔여 '+b.remainingMs+'ms / 계획 '+b.slot+'ms·재개 예상 '+(b.nextMs===null?'설정 확인 필요':Utilities.formatDate(new Date(b.nextMs),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'))+' (다른 사용량 없을 때)';}
function claimDetail42(ss,id){const j=detailJob52A(ss,id);j.s.getRange(j.at,2,1,2).setValues([['시도중·중단시 지연 재시도',nowKst()]]);j.s.getRange(j.at,6).setValue(Utilities.formatDate(new Date(Date.now()+3600000),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'));SpreadsheetApp.flush();return j;}
function claimAttachment42(ss,all,index,r){
 const p=PropertiesService.getScriptProperties(),s=ss.getSheetByName('첨부파일');
 // Commit cursor and retry lease BEFORE network I/O: a hard runtime kill skips finally.
 p.setProperty('ATTACH_CURSOR4',String((index+1)%Math.max(1,all.length)));
 const at=all.findIndex(x=>x[0]===r[0]);if(at<0)throw Error('PARSE: 첨부 claim 대상 없음');
 s.getRange(at+2,7).setValue(nowKst());s.getRange(at+2,9).setValue('시도중·중단시 지연 재시도');
 s.getRange(at+2,16).setValue(Utilities.formatDate(new Date(Date.now()+6*3600000),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'));
 p.setProperty('WORKER_HTTP4',JSON.stringify({at:nowKst(),stage:'첨부 '+r[1],url:String(r[4]).split('?')[0]}));SpreadsheetApp.flush();
}
function workBudget42(p,kind,fn,plannedSlot){
 const now=Date.now(),key='BUDGET42_'+kind,rows=ledger42(p,key,now),sum=a=>a.reduce((n,r)=>n+r[1],0);
 const analysis=kind==='상세'||kind==='첨부',slot=plannedSlot??(kind==='상세'?60000:kind==='첨부'?20000:50000);
 const cap=analysis?Number(p.getProperty('ENRICH_BUDGET_MS4')??600000):300000;
 // Preserve old used/reserved time. New work never erases the previous ledger.
 const used=analysis?sum(ledger42(p,'ENRICH_WINDOW4',now))+sum(ledger42(p,'BUDGET42_상세',now))+sum(ledger42(p,'BUDGET42_첨부',now)):sum(rows);
 if(!admission42(used,slot,cap)){p.setProperty(key,JSON.stringify(rows));p.setProperty('BUDGET_SKIP42',String(Number(p.getProperty('BUDGET_SKIP42')||0)+1));return {ran:false,reason:budgetWait42(budgetStatus42(p,kind,now,slot)),used,cap};}
 // Admission is a soft elapsed-time budget, NOT Google's quota. A killed request
 // retains a conservative six-minute charge. Never claim an HTTP hard timeout.
 rows.push([now,360000]);p.setProperty(key,JSON.stringify(rows));
 const start=Date.now();try{return {ran:true,value:measureV4(kind+'42',fn)};}finally{const saved=ledger42(p,key,Date.now()),r=saved.slice().reverse().find(x=>x[0]===now);if(r)r[1]=Date.now()-start;p.setProperty(key,JSON.stringify(saved));}
}
function detailRank42(row,decision,origin,today){
 const life=decision&&decision[1]||lifecycleV3(row,null,today),imp=decision&&decision[2]||row[21],geo=regionV4(row);
 if(!geo.eligible)return 99;
 const important=['★중요★','★검토 필요★'].includes(imp);
 if(life==='접수중'&&important)return 0;
 if(life==='접수예정'&&important)return 1;
 if(origin==='실시간신규'&&!/마감|취소|제외/.test(life))return 2;
 if(geo.group==='지역 확인 필요'||life==='기간 확인 필요')return 3;
 return /마감|취소|제외/.test(life)?5:4;
}
function recordProgress42(ss,kind,id){
 const p=PropertiesService.getScriptProperties(),now=Date.now(),rows=ledger42(p,'PROGRESS42_'+kind,now);
 rows.push([now,1]);p.setProperty('PROGRESS42_'+kind,JSON.stringify(rows));p.setProperty('LAST_SUCCESS42_'+kind,nowKst());
 ss.getSheetByName('개발검증').appendRow(['4.2 '+kind+' 실제저장',V42_AUTO?'실제 시간 기반':'수동 실행',nowKst()+' | '+id+' | release '+p.getProperty('RELEASE42')+' | 결과 저장 완료·의미분석 완료와 구분']);
}
var V42_AUTO=false;
function chooseDetail42(ss){
 const p=PropertiesService.getScriptProperties(),master=readV4(ss.getSheetByName('공고원장')).slice(4).filter(r=>r[0]),dm=new Map(readV4(ss.getSheetByName('공고상세')).slice(1).map(r=>[r[0],r])),jm=new Map(readV4(ss.getSheetByName('상세작업')).slice(1).map(r=>[r[0],r])),dec=new Map(readV4(ss.getSheetByName('공고판정')).slice(1).map(r=>[r[0],r])),orig=new Map(readV4(ss.getSheetByName('발견구분')).slice(1).map(r=>[r[0],r[1]])),now=nowKst(),today=todayKst();
 const eligible=master.filter(r=>{let d;try{d=JSON.parse((dm.get(r[0])||[])[16]||'null');}catch(e){}const j=jm.get(r[0]);return regionV4(r,d).eligible&&(!j||!/^20\d{2}-/.test(stampV3(j[5]))||stampV3(j[5])<=now);});
 if(!eligible.length)return null;
 const turn=Number(p.getProperty('DETAIL_TURN42')||0),rank=r=>detailRank42(r,dec.get(r[0]),orig.get(r[0]),today);
 let row;
 if(turn%4===3){const at=Number(p.getProperty('DETAIL_CURSOR4')||0)%master.length;for(let n=0;n<master.length;n++){const i=(at+n)%master.length;if(eligible.some(r=>r[0]===master[i][0])){row=master[i];p.setProperty('DETAIL_CURSOR4',String((i+1)%master.length));break;}}}
 else row=eligible.sort((a,b)=>rank(a)-rank(b)||Number(dm.has(a[0]))-Number(dm.has(b[0]))||stampV3((jm.get(a[0])||[])[3]).localeCompare(stampV3((jm.get(b[0])||[])[3]))||stampV3(b[1]).localeCompare(stampV3(a[1])))[0];
 p.setProperty('DETAIL_TURN42',String(turn+1));return row;
}
function processDetail42(ss){
 const row=chooseDetail42(ss);if(!row)return false;
 const p=PropertiesService.getScriptProperties(),r={id:row[0],number:String(row[34]),title:row[5],type:row[11],region:row[8],url:row[26],published:kstDayV3(row[2])};
 detailAttempt(ss,r.id);claimDetail42(ss,r.id);V4_ROUTE='상세 '+r.id;
 try{let d;if(r.id.startsWith('GH:'))d=parseGHDetailV4(fetchText(r.url),r);else if(r.id.startsWith('SH:'))d=parseSHDetail(fetchText(r.url),r);else if(r.id.startsWith('LH:'))d=parseLhDetail(fetchText(r.url),r);else{const raw=readV4(ss.getSheetByName('수집원본')).find(x=>x[0]===row[38]);if(!raw)throw Error('PARSE: 원천 스냅샷 없음');d=collectApplyModels(normalizeApply(JSON.parse(raw[5]),row[33]),p.getProperty('APPLYHOME_SERVICE_KEY'),fetchText);}
  saveDetail(ss,r,d);if(r.id.startsWith('SH:'))saveSHAttachments(ss,r,d);detailRecovered(ss,r.id);
  const jobs=readV4(ss.getSheetByName('상세작업')),at=jobs.findIndex(j=>j[0]===r.id);
  if(at>0)ss.getSheetByName('상세작업').getRange(at+1,6).setValue(Utilities.formatDate(new Date(Date.now()+86400000),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'));
  SpreadsheetApp.flush();recordProgress42(ss,'상세',r.id);return true;
 }catch(e){detailFailed(ss,r.id,e);const js=ss.getSheetByName('상세작업'),at=js.getDataRange().getValues().findIndex(x=>x[0]===r.id);if(at>0)js.getRange(at+1,2).setValue(classifyError(e));return false;}
}
function processAttachment42(ss){
 const p=PropertiesService.getScriptProperties(),master=new Map(readV4(ss.getSheetByName('공고원장')).slice(4).map(r=>[r[0],r])),dec=new Map(readV4(ss.getSheetByName('공고판정')).slice(1).map(r=>[r[0],r])),s=ss.getSheetByName('첨부파일'),all=readV4(s).slice(1),now=nowKst();
 const pending=all.map((r,i)=>({r,i})).filter(({r})=>{const m=master.get(r[1]);return m&&regionV4(m).eligible&&!attachmentDispositionV3(r)&&leaseDue52A(r[15],Date.now())&&(!r[7]||firstMsV4(r[7])<Date.now()-86400000);});if(!pending.length)return false;
 const turn=Number(p.getProperty('ATTACH_TURN42')||0),cursor=Number(p.getProperty('ATTACH_CURSOR4')||0);
 pending.sort(turn%4===3?(a,b)=>(a.i-cursor+all.length)%all.length-(b.i-cursor+all.length)%all.length:(a,b)=>detailRank42(master.get(a.r[1]),dec.get(a.r[1]),'',todayKst())-detailRank42(master.get(b.r[1]),dec.get(b.r[1]),'',todayKst())||Number(!!a.r[5])-Number(!!b.r[5])||a.i-b.i);
 const {r,i}=pending[0],single={getDataRange:()=>({getValues:()=>[[],r]})},real=upsertTable,view={getSheetByName:n=>n==='첨부파일'?single:ss.getSheetByName(n)};let success=false;
 claimAttachment42(ss,all,i,r);p.setProperty('ATTACH_TURN42',String(turn+1));V4_ROUTE='첨부 '+r[1];
 try{upsertTable=function(sheet,incoming,keycol){if(sheet===single)success=incoming.some(x=>!!x[5]&&x[7]!==r[7]);return real(sheet===single?s:sheet,incoming,keycol);};processAttachment35V4(view,true);}finally{upsertTable=real;}
 if(success){SpreadsheetApp.flush();recordProgress42(ss,'첨부',r[1]);}return success;
}
function updateOps42(ss,reason){
 let s=ss.getSheetByName('4.2운영점검');if(!s){s=ss.insertSheet('4.2운영점검');s.getRange(1,1,1,3).setValues([['운영 지표','값','범위/한계']]);s.setFrozenRows(1);}
 const p=PropertiesService.getScriptProperties(),now=Date.now(),dec=new Map(readV4(ss.getSheetByName('공고판정')).slice(1).map(r=>[r[0],r])),jobs=new Map(readV4(ss.getSheetByName('상세작업')).slice(1).map(r=>[r[0],r])),master=readV4(ss.getSheetByName('공고원장')).slice(4).filter(r=>r[0]),pending=master.filter(m=>regionV4(m).eligible&&(!jobs.has(m[0])||!jobs.get(m[0])[3])),important=pending.filter(m=>detailRank42(m,dec.get(m[0]),'',todayKst())<=1),oldest=pending.slice().sort((a,b)=>stampV3(a[1]).localeCompare(stampV3(b[1])))[0];
 const rows=[['진단시각',nowKst(),'4.2 운영 중·24시간 검증 별도'],['최종 소스 적용',p.getProperty('STARTED42')||'미설정','최종 저장 해시와 함께 판단'],['마지막 상세 성공',p.getProperty('LAST_SUCCESS42_상세')||'4.2 이후 미처리','원문/주택형 저장 성공'],['마지막 첨부 성공',p.getProperty('LAST_SUCCESS42_첨부')||'4.2 이후 미처리','바이너리/지원 HWPX, PDF 의미분석 별도'],['24시간 상세 실제저장',ledger42(p,'PROGRESS42_상세',now).length,'수동/자동 구분은 개발검증'],['24시간 첨부 실제저장',ledger42(p,'PROGRESS42_첨부',now).length,'수동/자동 구분은 개발검증'],['예산 대기 누적',Number(p.getProperty('BUDGET_SKIP42')||0),'4.2 이후 누적'],['중요공고 최초 상세 대기',important.length,'서울·경기/지역확인·접수중/예정 최신 판정'],['최장 최초 상세 대기',oldest?oldest[0]:'없음',oldest?Math.max(0,(now-firstMsV4(oldest[1]))/3600000).toFixed(1)+'시간':''],['다음 처리 역할',Number(p.getProperty('ANALYSIS_TURN42')||0)%6===5?'SH 후속':Number(p.getProperty('ANALYSIS_TURN42')||0)%3===2?'첨부':'상세','기존 10분 트리거 유지·첫 3슬롯 후 분석 시간당 1슬롯 분산·Lock/예산 재평가'],['현재 처리 상태',reason,'단순 후처리 정상종료와 실제 분석 진척 구분'],['예산 해석','Google 실제 할당량 아님','기존 상세 예산 600000ms 유지·요청 1개 계획슬롯 60초/20초·강제종료시 6분 보수계상']];
 const b=budgetStatus42(p,'상세',now),a=budgetStatus42(p,'첨부',now),derived=budgetStatus42(p,'파생',now),started=firstMsV4(p.getProperty('STARTED42'));
 rows.push(['운영 버전',p.getProperty('RELEASE42')||'미설정','소스 해시는 저장본 대조 보고서 참조'],['분석 사용/상한(ms)',b.used+' / '+b.cap,'기존 보수예약 + 상세 + 첨부·24시간 이동창'],['분석 잔여(ms)',b.remainingMs,'Google 계정 할당량과 별도'],['상세 입장 재개 예상',b.canRun?'현재 가능':b.nextMs===null?'설정 확인 필요':Utilities.formatDate(new Date(b.nextMs),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'),'추가 사용량·실제 트리거·Lock에 따라 달라짐'],['첨부 입장 재개 예상',a.canRun?'현재 가능':a.nextMs===null?'설정 확인 필요':Utilities.formatDate(new Date(a.nextMs),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'),'상세와 같은 예산 공유'],['최종 버전 이후 상세 성공',firstMsV4(p.getProperty('LAST_SUCCESS42_상세'))>=started?p.getProperty('LAST_SUCCESS42_상세'):'미확인','자동/수동 구분은 개발검증'],['최종 버전 이후 첨부 성공',firstMsV4(p.getProperty('LAST_SUCCESS42_첨부'))>=started?p.getProperty('LAST_SUCCESS42_첨부'):'미확인','최종 적용 전 성공을 최종 버전 검증에 사용하지 않음'],['파생 갱신 예산',derived.used+' / '+derived.cap+'ms',p.getProperty('DERIVED_WAIT42A')||'단계별 입장·실측비용 참조']);
 for(const kind of ['공고판정','지역정책','사용자현황판'])rows.push(['파생 마지막 정상·'+kind,p.getProperty('DERIVED_OK42A_'+kind)||'42.A3 이후 미확인','단계 소요(ms) '+(p.getProperty('DERIVED_COST42A_'+kind)||'미측정')]);rows.push(['파생 다음 단계',p.getProperty('DERIVED_STEP42A')||'0',p.getProperty('DERIVED_WAIT42A')||'대기원인 없음'],['42.A3 최초 정규 실행',p.getProperty('FIRST_AUTO42A_42.A3')||'미확인','4.2-B 기준 후보·사용자 요청 전 장기검증 미시작']);
 rows.push(['검토감시(local.6)',p.getProperty('REVIEW_WATCH_ERROR52A6')?'실패·핵심파생과 분리':p.getProperty('REVIEW_WATCH_WAIT52A6')?'시간 대기':'오류 기록 없음',p.getProperty('REVIEW_WATCH_ERROR52A6')||p.getProperty('REVIEW_WATCH_WAIT52A6')||'검토시트/마지막 검사시각 참조'],['사용자현황판 렌더(local.6)',p.getProperty('USER_RENDER_STATE52A6')||'미실행','COMPLETE만 집계완료; 세대/최신 일치는 별도']);s.getRange(2,1,rows.length,3).setValues(rows);
}
function runEnrichmentV42(e){
 const lock=LockService.getScriptLock();if(!lock.tryLock(1000)){lockMiss52A('후처리');return;}
 const start=Date.now(),p=PropertiesService.getScriptProperties();V52A4_ACTIVE=true;V4_MODE='후처리';V4_END=start+180000;V42_AUTO=!!(e&&e.triggerUid);let ss,result='시작';
 try{ss=SpreadsheetApp.openById(SPREADSHEET_ID);ensureV4(ss);detectWorkerAbortV4(ss);if(p.getProperty('RELEASE42')!=='42.A3'){p.setProperty('STARTED42',nowKst());p.setProperty('RELEASE42','42.A3');}if(V42_AUTO&&!p.getProperty('FIRST_AUTO42A_42.A3'))p.setProperty('FIRST_AUTO42A_42.A3',nowKst());if(V42_AUTO)p.setProperty('WORKER_AUTO4',nowKst());upsertTable(ss.getSheetByName('작업운영'),[['후처리',nowKst(),p.getProperty('WORKER_OK4')||'','시도중','4.2 목록 우선·분리 예산',p.getProperty('WORKER_AUTO4')||'']]);
  // local.6: every phase receives a dedicated attempt at most once per 20 minutes.
  // Other ticks retain GH/detail/attachment/follow-up fairness and existing budgets.
  const derivedPhase=Number(p.getProperty('DERIVED_STEP42A')||0)%4;
  const derivedCost=Number(p.getProperty('DERIVED_COST42A_공고판정')||0);
  const lastDedicated=Number(p.getProperty('DERIVED_DEDICATED_AT42A32')||0);
  const dedicated=Date.now()-lastDedicated>=1200000&&budgetStatus42(p,'파생',Date.now(),50000).canRun; // bounded slices; historical 175.6s estimate no longer gates admission
  if(dedicated){
   p.setProperty('DERIVED_DEDICATED_AT42A32',String(Date.now()));
   const done=runDerived42A(ss);
   result=done?'파생 단계 '+derivedPhase+' 전용 완료·기존 GH/상세 다음 예약':'파생 단계 '+derivedPhase+' 전용 시도·기존 상태/커서 보존';
  }else{
   if(p.getProperty('GH_ENABLED4')==='true')measureV4('GH 목록',()=>runGHJobsV4(ss,start+55000));
   result=executeRole52A(p,ss,V4_END);
   if(Date.now()+65000<V4_END)runDerived42A(ss);
  }
  reviewWatchSafe52A6(ss);if(p.getProperty('REVIEW_WATCH_ERROR52A6'))result+=' · 검토감시 실패(핵심파생 별도)';if(/실제저장|실패|예산 대기/.test(result)||Date.now()-Number(p.getProperty('OPS_AT42')||0)>1800000){updateOps42(ss,result);p.setProperty('OPS_AT42',String(Date.now()));}if(!dedicated||!/시도/.test(result))p.setProperty('WORKER_OK4',nowKst());upsertTable(ss.getSheetByName('작업운영'),[['후처리',Utilities.formatDate(new Date(start),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'),p.getProperty('WORKER_OK4')||'',result,'4.2 상세/첨부 우선·상태 세부는 4.2운영점검',p.getProperty('WORKER_AUTO4')||'']]);
 }catch(err){result='실패 '+safeError(err);if(ss)ss.getSheetByName('처리오류이력').appendRow([nowKst(),'4.2 후처리','',result,'','다음 예약·커서 보존',safeError(err)]);throw err;
 }finally{try{if(ss){V4_STAGE.push(['총 실행',Date.now()-start]);flushMetricsV4(ss,Utilities.formatDate(new Date(start),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'),'후처리42',result);ss.getSheetByName('개발검증').appendRow(['4.2 후처리',V42_AUTO?'실제 시간 기반':'수동 실행',nowKst()+' | '+((Date.now()-start)/1000).toFixed(3)+'초 | '+result]);}}finally{resetV4();V42_AUTO=false;lock.releaseLock();}}
}

function runEnrichmentV4(e){return runEnrichmentV42(e);}

// NOT INSTALLED / NOT RUN. Only aggregate sizes and whitelisted non-secret counters.
// Never print the property object, values, authentication keys or trigger IDs.
function inspectReadOnly41(){
 const p=PropertiesService.getScriptProperties(),all=p.getProperties(),bytes=s=>Utilities.newBlob(String(s)).getBytes().length;
 const sizes=Object.keys(all).map(k=>({key:k,valueBytes:bytes(all[k]),keyBytes:bytes(k)}));
 const at=Date.now(),entries=JSON.parse(p.getProperty('ENRICH_WINDOW4')||'[]').filter(r=>Array.isArray(r)&&r[0]>at-86400000&&r[0]<=at);
 const gh=['GH_기관주택','GH_청약임대','GH_청약매입임대','GH_청약공지'].map(route=>{
  const raw=p.getProperty('GH_PAGE4_'+route),state=raw?loadCheckpoint52A(p,'GH_PAGE4_'+route):null,full=JSON.parse(p.getProperty('GH_FULL4_'+route)||'null');
  return {route,page:state&&state.page,total:state&&state.total,seenIDs:state&&Array.isArray(state.ids)?state.ids.length:null,cursorValueBytes:raw?bytes(raw):0,lastFullAt:full&&full.at,nextFullEpoch:Number(p.getProperty('GH_DUE4_'+route)||0)};
 });
 const out={properties:{count:sizes.length,totalKeyAndValueBytes:sizes.reduce((n,r)=>n+r.keyBytes+r.valueBytes,0),maxValueBytes:Math.max(0,...sizes.map(r=>r.valueBytes)),valuesAtLeast8KiB:sizes.filter(r=>r.valueBytes>=8192).length},enrichment:{windowEntries:entries.length,usedOrReservedMs:entries.reduce((n,r)=>n+Number(r[1]||0),0),budgetMs:Number(p.getProperty('ENRICH_BUDGET_MS4')||600000),upfrontReserveMs:360000,oldestExpiryEpoch:entries.length?Math.min(...entries.map(r=>r[0]))+86400000:null},gh,triggerHandlers:ScriptApp.getProjectTriggers().map(t=>t.getHandlerFunction()),detailCursor:Number(p.getProperty('DETAIL_CURSOR4')||0),attachmentCursor:Number(p.getProperty('ATTACH_CURSOR4')||0)};
 console.log(JSON.stringify(out));return out;
}

// 4.2-A candidate. No sender, no triggers, no account budget increase.
function detailComparable42A(d){
 const val=x=>x==null?'':String(x).replace(/\s+/g,' ').trim();
 const attrs=['address','building','begin','end','winner','move','qualification','price','monthly','min','max','count','related','target','endTime'];
 const out={};for(const k of attrs)out[k]=val(d&&d[k]);
 out.complexes=(d&&d.complexes||[]).map(val).sort();
 // fileId identifies an official attachment; downloader URL/mode are implementation.
 out.attachments=(d&&d.attachments||[]).map(a=>[val(a.fileId),val(a.name),val(a.size)]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
 // evidence may include changing buttons (e.g. '-' -> '청약신청전').
 out.units=(d&&d.units||[]).map(u=>['complex','type','area','count','deposit','monthly'].map(k=>val(u[k]))).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
 out.schedules=(d&&d.schedules||[]).map(x=>['complex','begin','end','endTime'].map(k=>val(x[k]))).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
 out.body=val(String(d&&d.bodyEvidence||'').split(/\r?\n/).filter(line=>!/^\s*(?:청약신청전|청약신청|신청하기|바로가기|다운로드|목록으로|이전글|다음글)\s*$/.test(line)).join('\n'));return out;
}
function detailChange42A(before,after){
 if(!before)return {kind:'최초 상세 확보',official:false,fields:[]};
 const a=detailComparable42A(before),b=detailComparable42A(after),fields=Object.keys(b).filter(k=>JSON.stringify(a[k])!==JSON.stringify(b[k]));
 if(!fields.length)return {kind:'내부 경로·표시 보완',official:false,fields};
 const known=v=>v!==''&&!/원문 확인|확인 필요|미확인/.test(String(v));
 const collectionChanged=(left,right,idCols)=>{
  if(!left.length||!right.length)return false;
  const key=x=>JSON.stringify(idCols.map(i=>x[i])),lm=new Map(left.map(x=>[key(x),x])),rm=new Map(right.map(x=>[key(x),x]));
  if(lm.size!==rm.size||[...lm.keys()].some(k=>!rm.has(k)))return true;
  return [...lm].some(([k,row])=>row.some((v,i)=>!idCols.includes(i)&&known(v)&&known(rm.get(k)[i])&&v!==rm.get(k)[i]));
 };
 const strong=fields.filter(k=>k==='body'?known(a.body)&&known(b.body):k==='attachments'?collectionChanged(a.attachments,b.attachments,[0]):k==='schedules'?collectionChanged(a.schedules,b.schedules,[0,1,2,3]):k==='units'?collectionChanged(a.units,b.units,[0,1]):k==='complexes'?a[k].length>0&&b[k].length>0:known(a[k])&&known(b[k]));
 // A parser change never discards a material delta. It changes the evidence threshold.
 const parserStable=before._parserVersion!=null&&before._parserVersion===after._parserVersion;
 const sourceSame=known(a.body)&&a.body===b.body;
 const scheduleProof=k=>{
  if(!['begin','end','winner'].includes(k))return false;
  const norm=x=>String(x||'').replace(/(20\d{2})[.\/-](\d{2})[.\/-](\d{2})/g,'$1-$2-$3').replace(/\s+/g,' ').trim();
  const old=(before.schedules||[]),next=(after.schedules||[]);
  return old.some(x=>next.some(y=>x.label===y.label&&(x.complex||'')===(y.complex||'')&&
   x[k]===a[k]&&y[k]===b[k]&&norm(x.evidence).includes(a[k])&&norm(y.evidence).includes(b[k])&&
   !norm(x.evidence).includes(b[k])&&!norm(y.evidence).includes(a[k])));
 };
 const supported=strong.filter(k=>scheduleProof(k)||(k!=='body'&&parserStable&&!sourceSame));
 // A known value disappearing is not a first extraction: retain a review record.
 const lost=fields.filter(k=>typeof a[k]==='string'&&known(a[k])&&!known(b[k])||Array.isArray(a[k])&&a[k].length&&!b[k].length);
 const reviewFields=[...new Set(strong.filter(k=>!supported.includes(k)).concat(lost))];
 return {kind:supported.length?'공식 상세 필드 변경 후보':reviewFields.length?'공식 변경 여부 별도검토':'기존 미확인 상세 보완',
  official:supported.length>0,review:reviewFields.length>0,fields,strong,supported,reviewFields,
  evidence:parserStable?'동일 파서의 기존 확인값 비교·공식 정정 확정 아님':'파서 변경 동시 발생·일정 근거행 대조 또는 원문 별도검토'};
}
function finalizeDetailEvent42A(ss,r,previous,d,hash){
 if(!previous||previous[1]===hash)return;
 const before=JSON.parse(previous[16]||'{}'),change=detailChange42A(before,d);
 if(!change.official&&!change.review)return; // Internal-only fills create no correction event.
 const s=ss.getSheetByName('공고상세'),saved=s.getDataRange().getValues().find(x=>x[0]===r.id);
 if(!saved||saved[1]!==hash||saved[16]!==JSON.stringify(d))throw Error('DETAIL_FINAL42A: 상세 최종저장 대조 실패');
 const now=nowKst(),snap=r.id+':DETAIL:'+hash,
 proof='42A:'+change.kind+'; '+change.evidence+'; 변경 '+change.strong.join(', ')+(change.review?'; 원문 대조 요청 '+change.reviewFields.join(', '):'');
 upsertTable(ss.getSheetByName('정정이력'),[[r.id,now,r.published,change.kind,change.fields.join(', '),previous[16]||'',saved[16],'최종 상세 저장값 대조',r.url,proof,snap]],10);
 const category=change.official?'정정/변경':'공식 변경 여부 별도검토',allow=change.official?'Y':'N';
 const m=ss.getSheetByName('공고원장').getDataRange().getValues().find(x=>x[0]===r.id),policy=m?notificationRegionV4([snap,r.id,now,'상세변경','미발송',proof,r.url,category,allow,proof],m,[category,allow,proof]):['정정/변경','N','42A:원장 근거 미확인'];
 if(!change.official)policy.splice(0,3,category,'N',proof);
 upsertTable(ss.getSheetByName('발송대기'),[[snap,r.id,now,'상세변경','미발송',proof,r.url,...policy]]);
}
function detailEventPolicy42A(event,history){
 if(event[3]!=='상세변경'||['발송완료','발송 완료'].includes(event[4]))return event.slice(7,10);
 if(event[7]==='파생분류 보완'&&event[8]==='N'&&/4\.2-A 감사 재평가/.test(String(event[9])))return event.slice(7,10);
 if(!history)return [event[7]||'상세 근거 검토','N','42A:상세 변경 전후 근거 미확인·원본 보존'];
 try{const c=detailChange42A(JSON.parse(history[5]),JSON.parse(history[6]));return c.official?[event[7]||'정정/변경',event[8],event[9]]:c.review?['공식 변경 여부 별도검토','N','42A:'+c.kind+'; 원문 대조 요청 '+c.reviewFields.join(', ')+'; 원본 이력 보존']:['파생분류 보완','N','42A:'+c.kind+'; 공식 변경 근거 없음·원본 이력 보존'];}
 catch(e){return [event[7]||'상세 근거 검토','N','42A:변경 이력 파싱 실패·공식 근거 확인 전 보류'];}
}
function protectDetailEvents42A(ss){
 const q=ss.getSheetByName('발송대기'),rows=q.getDataRange().getValues().slice(1),hm=new Map(ss.getSheetByName('정정이력').getDataRange().getValues().slice(4).map(h=>[h[10],h]));
 const after=rows.map(e=>detailEventPolicy42A(e,hm.get(e[0])));writeChangedRows42A(q,2,8,after);
}

// One stage per existing worker tick. Existing BUDGET42_파생 ledger is retained.
function writeChangedRows42A(sheet,row,col,values,ignoreTailStamp=false){
 if(!values.length)return 0;const old=sheet.getRange(row,col,values.length,values[0].length).getValues();let writes=0;
 for(let at=0;at<values.length;at+=100){const next=values.slice(at,at+100).map((r,k)=>r.some((v,j)=>!(ignoreTailStamp&&j===r.length-1)&&!sameCell52A(v,(old[at+k]||[])[j]))?r:(old[at+k]||r));if(next.some((r,k)=>r.some((v,j)=>!sameCell52A(v,(old[at+k]||[])[j])))){sheet.getRange(row+at,col,next.length,values[0].length).setValues(next.map(r=>r.map(safeText52A)));writes+=next.length;}}
 return writes;
}
function cachedDerivedView42A(ss){
 const sheets=new Map(),clone=a=>a.map(r=>r.slice());
 return new Proxy(ss,{get(target,key){if(key!=='getSheetByName'){const v=target[key];return typeof v==='function'?v.bind(target):v;}return name=>{
  if(sheets.has(name))return sheets.get(name);
  const real=target.getSheetByName(name);if(!real)return real;let cache=null;
  const read=()=>{if(!cache)cache=clone(real.getDataRange().getValues());return cache;};
  const rangeView=(range,args)=>new Proxy(range,{get(r,k){
   if(k==='getValues')return()=>{if(args===null)return clone(read());const bounds=typeof args[0]==='number'?args:a1Bounds52A(args[0]);if(!bounds)return r.getValues();const [row,col,h=1,w=1]=bounds,a=read();return Array.from({length:h},(_,i)=>Array.from({length:w},(_,j)=>(a[row-1+i]||[])[col-1+j]??''));};
   if(k==='setValue'||k==='setValues')return value=>{
    const vals=k==='setValue'?[[value]]:value;
    const bounds=typeof args?.[0]==='number'?args:a1Bounds52A(args?.[0]);if(!bounds){if(k==='setValue')r.setValue(value);else r.setValues(value);cache=null;return rangeView(r,args);}const row=bounds[0],col=bounds[1],a=read();
    const same=vals.every((x,i)=>x.every((v,j)=>!(typeof v==='string'&&v.startsWith('='))&&sameCell52A(v,(a[row-1+i]||[])[col-1+j])));
    if(!same){if(k==='setValue')r.setValue(value);else r.setValues(value);for(let i=0;i<vals.length;i++){while(a.length<row+i)a.push([]);for(let j=0;j<vals[i].length;j++)a[row-1+i][col-1+j]=vals[i][j];}}
    if(vals.some(row=>row.some(v=>typeof v==='string'&&v.startsWith('='))))cache=null;
    return rangeView(r,args);
   };
   const v=r[k];if(typeof v!=='function')return v;
   return(...x)=>{const result=v.apply(r,x);if(/^clear|^delete|^insert|^copy|^move|^merge|^setFormula|^setRichText/.test(String(k)))cache=null;return result===r?rangeView(r,args):result;};
  }});
  const wrapped=new Proxy(real,{get(s,k){if(k==='getDataRange')return()=>rangeView(s.getDataRange(),null);if(k==='getRange')return(...a)=>rangeView(s.getRange(...a),a);
   const v=s[k];if(typeof v!=='function')return v;return(...a)=>{const result=v.apply(s,a);if(/^append|^insert|^delete|^clear/.test(String(k)))cache=null;return result===s?wrapped:result;};}});
  sheets.set(name,wrapped);return wrapped;
 };}});
}
function runDerived42A(ss){if(V52A4_ACTIVE)return runDerivedFinite52A5(ss);
 const p=PropertiesService.getScriptProperties(),phase=Number(p.getProperty('DERIVED_STEP42A')||0)%4,aux=Number(p.getProperty('DERIVED_AUX42A')||0)%4;
 const maintenance=[['핵심정보',reconcileQualityV2],['첨부예외',reconcileExceptionsV3],['리마인더',prepareReminders35],['운영대시보드',s=>refreshMonitor(s,true)]];
 const steps=[['공고판정',reconcileDecisionsV3],['지역정책',refreshRegionV4],['사용자현황판',refreshUserDashboardV4],maintenance[aux]],step=steps[phase],now=Date.now();
 // Initial plan stays conservative until this exact stage has been measured.
 const previous=Number(p.getProperty('DERIVED_COST42A_'+step[0])||0),slot=phase===0?50000:previous?Math.max(50000,Math.ceil(previous*1.08)):50000; // 42.A3.2: 123s stage fits dedicated 180s window; never override actual budget
 if(now+slot+15000>V4_END){p.setProperty('DERIVED_WAIT42A','실행시간 대기·'+step[0]);return false;}
 const b=budgetStatus42(p,'파생',now,slot);if(!b.canRun){p.setProperty('DERIVED_WAIT42A',budgetWait42(b)+' · '+step[0]);return false;}
 // Dependent screen stages cannot be marked refreshed if preceding stages failed.
 const view=cachedDerivedView42A(ss),start=Date.now();
 let work;try{work=workBudget42(p,'파생',()=>measureV4('4.2A 파생 '+step[0],()=>{if(phase!==0)return step[1](view);const until=Math.min(V4_END-20000,Date.now()+45000);for(let n=0;n<100&&Date.now()+5000<until;n++){if(decisionSlice52A(view,until))return true;}return false;}),slot);}catch(e){p.setProperty('DERIVED_WAIT42A','단계 실패·'+step[0]+'·이전 정상시각 보존');throw e;}
 if(!work.ran){p.setProperty('DERIVED_WAIT42A',work.reason);return false;}
 p.setProperty('DERIVED_COST42A_'+step[0],String(Date.now()-start));
 if(phase===0&&work.value===false){p.setProperty('DERIVED_WAIT42A','공고판정 체크포인트 저장·다음 예약 재개');return false;}
 p.setProperty('DERIVED_OK42A_'+step[0],nowKst());p.setProperty('DERIVED_WAIT42A','');p.setProperty('DERIVED_STEP42A',String((phase+1)%4));
 if(phase===3)p.setProperty('DERIVED_AUX42A',String((aux+1)%4));
 if(phase===2)p.setProperty('DERIVED_AT42',String(Date.now()));return true;
}

// Official LH paging form is POST. GET currPage repeats page 1 after 100 rows.
function lhPagingRequest42A3(html,page){
 const form=(html.match(/<form\b[^>]*name=["']pagingForm["'][^>]*>[\s\S]*?<\/form>/i)||[])[0];
 if(!form||!(/method=["']post["']/i).test(form))throw Error('PARSE: LH POST 페이지 폼 없음');
 const allowed=new Set(['currPage','cnpCd','xssChk','panEdDt','listCo','prevListCo','panSs','endDt','aisTpCd','uppAisTpCd','maxSn','mvinQf','viewType','startDt','panStDt','mi','srchUppAisTpCd','srchY','minSn','schTy','csCd']),payload={};
 for(const x of form.matchAll(/<input\b[^>]*>/gi)){const n=(x[0].match(/name=["']([^"']+)["']/i)||[])[1],v=(x[0].match(/value=["']([^"']*)["']/i)||[])[1];if(allowed.has(n)&&v!==undefined)payload[n]=v.replace(/&amp;/g,'&');}
 for(const k of ['currPage','listCo','panSs','startDt','endDt','mi','srchUppAisTpCd','srchY'])if(!Object.prototype.hasOwnProperty.call(payload,k))throw Error('PARSE: LH 페이지 필수값 누락 '+k);
 payload.currPage=String(page);return {url:LH_BASE+'selectWrtancList.do',options:{method:'post',payload}};
}

// Read-only shape diagnostic: public board HTML only; never headers/cookies/properties.
function shResponseShape42A3(html,url){
  const marker=(html.match(/class=["'][^"']*mentcount[^"']*["'][^>]*>([\s\S]*?)<\/div>/i)||[])[1]||'';
  const m=textOf(marker).match(/총\s*([\d,]+)\s*건\s*\[(\d+)\/(\d+)페이지/);
  const table=(html.match(/<table\b[^>]*>[\s\S]*?<\/table>/gi)||[]).find(t=>/공고 및 공지 목록/.test(t))||'';
  const rows=[...table.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)];
  const ids=re=>[...new Set([...table.matchAll(re)].map(x=>x[1]))].slice(0,120);
  return {url,totalMarker:m?'총 '+Number(m[1].replace(/,/g,''))+' 건 ['+m[2]+'/'+m[3]+'페이지]':'',characters:html.length,hasHtml:/<html\b/i.test(html),hasTotalMarker:!!m,total:m?Number(m[1].replace(/,/g,'')):null,page:m?Number(m[2]):null,pages:m?Number(m[3]):null,hasListTable:!!table,trCount:rows.length,getDetailViewCount:(table.match(/getDetailView\s*\(/g)||[]).length,onclickCount:(table.match(/onclick\s*=/gi)||[]).length,detailCallSeq:ids(/getDetailView\s*\(\s*['"]?(\d{1,15})['"]?\s*\)/g),hrefSeq:ids(/[?&](?:amp;)?seq=(\d{1,15})(?=[&'"\s<>]|$)/g),rowStructure:rows.slice(0,15).map(x=>({tdCount:(x[1].match(/<td\b/gi)||[]).length,hasDate:/20\d{2}-\d{2}-\d{2}/.test(textOf(x[1])),hasDetailCall:/getDetailView\s*\(/.test(x[1])}))};
}

/** HUG past-baseline safeguard, verified by 5.1-J.1 before writes. */
function hugArchiveLegacyNoticeGuard4233(){return true;}

// 5.2-A local release: additional bounded worker and dry-run contracts.
function supplyGeo52A(text){
 const s=String(text||'').trim();
 // Ambiguous exclusions/residency text is never affirmative housing evidence.
 const ambiguous=/아닌|아니라|제외|제외한|외\s*(?:지역|거주|공급)|거주자|거주요건|거주\s*요건|신청자|본사|기관\s*소재|서울권/.test(s);
 const names=['서울특별시','서울시','서울','경기도','경기','부산광역시','부산','대구광역시','대구','인천광역시','인천','대전광역시','대전','울산광역시','울산','광주광역시','광주','세종특별자치시','세종','강원특별자치도','강원도','강원','충청남도','충남','충청북도','충북','전라남도','전남','전북특별자치도','전라북도','전북','경상남도','경남','경상북도','경북','제주특별자치도','제주도','제주'];
 const found=[];const re=new RegExp('(?:^|[\\s·,;/()\\[\\]])('+names.join('|')+')(?=$|[\\s·,;/()\\[\\]])','g');let m;while((m=re.exec(s)))found.push(m[1]);
 return {target:!ambiguous&&found.some(x=>/^(서울|경기)/.test(x)),other:!ambiguous&&found.some(x=>!/^(서울|경기)/.test(x)),known:!ambiguous&&found.length>0,open:ambiguous||/전국|통합|복수|여러|미상|미확인|확인 필요|(?:^|\s)외(?:\s|$)/.test(s),ambiguous};
}
function noticeKind52A(title,evidence){
 const t=String(title||''),result=resultNotice52A(t),action=recruitmentAction52A(t);
 if(/상가|상업용지|토지\s*(?:공급|분양|매각)|사업자\s*모집/.test(t)&&!/토지임대부.*주택/.test(t))return 'EXCLUDED';
 if(result)return action&&evidence&&evidence.recruitmentChangeConfirmed===true?'MATERIAL':action?'REVIEW':'EXCLUDED';
 if(/계약갱신|갱신계약/.test(t))return 'EXCLUDED';
 if(/정정|수정공고/.test(t)||action||/무순위|잔여세대/.test(t))return 'MATERIAL';
 return /모집|분양|임대|공급/.test(t)?'RECRUITMENT':'REVIEW';
}
function decisionRow52A(row,dr,now,today,sourceTitle){
 let d=null;if(dr){try{d=JSON.parse(dr[16]||'{}');}catch(e){throw Error('SCHEMA: 상세 JSON 오류·판정 정상시각 보존');}}
 const q={building:dr?dr[21]:'원문 확인 필요'},imp=assessV3(row,d,q);
 const status=noticeKind52A(sourceTitle||row[5])==='EXCLUDED'?'모집대상 제외':lifecycleV3(row,d,today);
 return [row[0],status,imp[0],imp[1],kstDayV3(d&&d.begin||row[17]),kstDayV3(d&&d.end||row[18]),row[1],d?'Y':'N',/^(?:SH:|GH:)/.test(String(row[0]))?classifySupplyV2(row,{title:row[5]})[0]:dr&&dr[19]||row[3],row[5],d&&d.address||row[8],row[26],'신청자격 확인 필요',String(row[0]).startsWith('SH:')?shProgram(row[5]):'',dr?dr[22]:'상세 미생성',now];
}
function unique52A(rows,label){const seen=new Set();for(const r of rows){if(!r[0])continue;if(seen.has(r[0]))throw Error('SCHEMA: '+label+' 중복키·자동 병합 금지');seen.add(r[0]);}return rows;}
function readRows52A(ss,name,start,width){const s=ss.getSheetByName(name);return s&&s.getLastRow()>=start?s.getRange(start,1,s.getLastRow()-start+1,width).getValues():[];}
function finalQueueGuard52A(ss){
 const master=new Map(readRows52A(ss,'공고원장',5,40).map(r=>[r[0],r]));
 const details=new Map(readRows52A(ss,'공고상세',2,23).map(r=>[r[0],r]));
 const rawMap=new Map(readRows52A(ss,'수집원본',2,6).map(r=>[r[0],r]));
 const s=ss.getSheetByName('발송대기'),rows=readRows52A(ss,'발송대기',2,10);
 const out=rows.map(e=>{if(['발송완료','발송 완료'].includes(e[4]))return e.slice(7,10);const m=master.get(e[1]);if(!m)return [e[7],'N','5.2-A: 원장 연결 미확인'];let d=null;try{d=JSON.parse((details.get(e[1])||[])[16]||'null');}catch(_){}d=supplyDetail52A(m,d,rawMap);let p=notificationRegionV4(e,m,e.slice(7,10),d);if(['EXCLUDED','REVIEW'].includes(noticeKind52A(d&&d._sourceNoticeTitle||m[5])))p=[p[0],'N','5.2-A: 주거 모집/중요변경 근거 확인 필요'];return p;});
 if(out.length)writeChangedRows42A(s,2,8,out);
}
function decisionSlice52A(ss,deadline){
 const p=PropertiesService.getScriptProperties(),state=JSON.parse(p.getProperty('DECISION_CURSOR52A')||'{"part":"decisions","offset":0}');
 const end=Math.min(deadline,Date.now()+45000),size=100,now=nowKst(),today=todayKst();
 const master=unique52A(readRows52A(ss,'공고원장',5,40).filter(r=>r[0]),'원장');
 const ds=new Map(unique52A(readRows52A(ss,'공고상세',2,23),'상세').map(r=>[r[0],r]));
 const revisionRows=readRows52A(ss,'수집원본',2,6),sourceMap=new Map(revisionRows.map(r=>[r[0],r]));
 const signatureNow=digest(JSON.stringify([today,master,[...ds],revisionRows]));
 if(state.signature&&state.signature!==signatureNow){state.part='decisions';state.offset=0;state.signature=signatureNow;}
 const decisions=ss.getSheetByName('공고판정');
 unique52A(readRows52A(ss,'공고판정',2,16),'판정');
 if(state.part==='decisions'){
  // ID order fingerprint prevents stale numeric cursors after insertion/reordering.
  const sig=signatureNow;
  if(state.signature!==sig){state.offset=0;state.signature=sig;}
  if(Date.now()+5000>=end)return false;
  const rows=master.slice(state.offset,state.offset+size).map(r=>decisionRow52A(r,ds.get(r[0]),now,today,snapshotNoticeTitle52A((sourceMap.get(r[38])||[])[5])));
  ensureRowsV4(decisions,state.offset+rows.length+1);
  if(rows.length)writeChangedRows42A(decisions,state.offset+2,1,rows,true);
  state.offset+=rows.length;
  if(state.offset>=master.length){state.part='queue';state.offset=0;}
  p.setProperty('DECISION_CURSOR52A',JSON.stringify(state));return false;
 }
 const queue=ss.getSheetByName('발송대기'),events=unique52A(readRows52A(ss,'발송대기',2,10),'이벤트');
 const signature=digest(JSON.stringify(events.map(r=>[r[0],r[1],r[2],r[3],r[4],r[5],r[6]])));
 if(state.queueSignature!==signature){state.offset=0;state.queueSignature=signature;}
 const dm=new Map(readRows52A(ss,'공고판정',2,16).map(r=>[r[0],r])),mm=new Map(master.map(r=>[r[0],r]));
 const hm=new Map(readRows52A(ss,'정정이력',5,11).map(r=>[r[10],r]));
 const aliases=new Map(validAliasesV4(ss,master)),derived=derivedEvents35(ss);
 const rawRows=readRows52A(ss,'수집원본',2,6),rawMap=new Map(rawRows.map(r=>[r[0],r]));
 const gh=ghChangePoliciesV4(events,rawRows);
 const sf=new Map(readRows52A(ss,'SH후속안내',2,7).map(r=>[r[0],r])),gf=new Map(readRows52A(ss,'GH후속안내',2,13).map(r=>[r[0],r]));
 const v3=p.getProperty('V3_STARTED');if(Date.now()+5000>=end)return false;
 const batch=events.slice(state.offset,state.offset+size),out=batch.map((e,i)=>{
  if(['발송완료','발송 완료'].includes(e[4]))return e.slice(7,10);
  const m=mm.get(e[1]);if(!m)return [e[7],'N','5.2-A: 원 모집 연결 확인 필요'];
  let policy=notificationV3(e,dm.get(e[1]),m[1],v3);
  if(derived.has(e[0]))policy=['파생분류 보완','N','공식 판단 핵심값 동일'];
  if(e[3]==='후속안내'){
   if(String(e[1]).startsWith('SH:')&&['일반 안내','단순 결과'].includes(followupType35((sf.get(e[1])||[])[1]||'')))policy=['SH 일반/결과 안내','N','모집대상 제외'];
   if(String(e[1]).startsWith('GH:')){const f=gf.get(e[1]);policy=ghFollowupPolicyV4(e,f,!f||!f[11]||String(f[11]).startsWith('초기백필'),dm.get((f||[])[4]));}
  }
  if(String(e[1]).startsWith('GH:')&&e[3]==='변경')policy=gh[state.offset+i];
  if(e[3]==='상세변경')policy=detailEventPolicy42A([...e.slice(0,7),...policy],hm.get(e[0]));
  if(aliases.has(e[1])&&e[3]==='신규')policy=[policy[0],'N','동일 모집 확인·대표ID '+aliases.get(e[1])];
  let detail=null;try{detail=JSON.parse((ds.get(e[1])||[])[16]||'null');}catch(_){}
  detail=supplyDetail52A(m,detail,rawMap);policy=notificationRegionV4(e,m,policy,detail);
  if(['EXCLUDED','REVIEW'].includes(noticeKind52A(detail&&detail._sourceNoticeTitle||m[5])))policy=[policy[0],'N','5.2-A: 주거 모집/중요변경 근거 확인 필요'];
  return policy;
 });
 if(out.length)writeChangedRows42A(queue,state.offset+2,8,out);
 state.offset+=batch.length;
 if(state.offset>=events.length){p.deleteProperty('DECISION_CURSOR52A');return true;}
 p.setProperty('DECISION_CURSOR52A',JSON.stringify(state));return false;
}
function deliveryPlan52A(notice,event,config,ledger,now){
 const reject=reason=>({status:'HOLD',reason,key:null,send:false});
 const at=x=>typeof x==='number'?x:firstMsV4(x),go=at(config.goLiveAt),first=at(notice.firstSeenAt),created=at(event.createdAt);
 if(!config.channelApproved||!config.channel)return reject('CHANNEL_NOT_APPROVED');
 if(![go,first,created,now].every(Number.isFinite)||first<go||created<go||created<first||created>now||first>now||go>now)return reject('BASELINE_OR_TIME');
 if(notice.archive||String(notice.id).startsWith('HUG:ARCHIVE:')||notice.backfill)return reject('ARCHIVE_OR_BACKFILL');
 if(notice.regionGroup!=='서울·경기'&&notice.regionGroup!=='서울·경기 포함/복수')return reject('REGION_REVIEW_OR_OUTSIDE');
 if(!['RECRUITMENT','MATERIAL'].includes(noticeKind52A(notice.title)))return reject('NOT_RECRUITMENT');
 if(!event.officialEventKey||!notice.id||event.noticeId!==notice.id||!['NEW','MATERIAL'].includes(event.kind)||event.allow!=='Y')return reject('EVENT_REVIEW');
 if(event.kind==='MATERIAL'&&!event.materialEvidence)return reject('MATERIAL_EVIDENCE_REQUIRED');
 // Cross-source identities may only be shared after explicit evidence-based confirmation.
 const identity=notice.confirmedIdentity||notice.id;
 const key=JSON.stringify([config.channel,identity,event.officialEventKey]);
 const last=ledger[key];
 if(config.lastDeliveredEventKey===key||last&&['DELIVERED','IN_FLIGHT','UNKNOWN'].includes(last.status))return reject('DUPLICATE_OR_AMBIGUOUS');
 if(last&&(last.attempts>=5||last.nextAttemptAt>now))return reject('RETRY_WAIT_OR_EXHAUSTED');
 return {status:'DRY_RUN_CANDIDATE',key,send:false,attempt:(last&&last.attempts||0)+1};
}
function simulateDelivery52A(plan,outcome,now){
 if(plan.status!=='DRY_RUN_CANDIDATE')return null;
 return {status:outcome==='SUCCESS'?'DELIVERED':outcome==='UNKNOWN'?'UNKNOWN':'FAILED',attempts:plan.attempt,nextAttemptAt:now+Math.min(3600000,60000*Math.pow(2,plan.attempt-1)),key:plan.key,simulated:true};
}
function adapterContract52A(adapter,raw){
 for(const k of ['fetch','parse','normalize'])if(typeof adapter[k]!=='function')throw Error('ADAPTER: '+k+' missing');
 const notices=adapter.parse(raw).map(x=>adapter.normalize(x));
 for(const n of notices)if(!n.id||!n.source||!n.url||!n.title||!n.raw)throw Error('ADAPTER: stable official ID/source/url/title/raw required');
 unique52A(notices.map(n=>[n.id]),'adapter');return notices;
}
function inspect52AReadOnly(){
 const ss=SpreadsheetApp.openById(SPREADSHEET_ID),p=PropertiesService.getScriptProperties();
 const m=readRows52A(ss,'공고원장',5,40),r=readRows52A(ss,'수집원본',2,6),e=readRows52A(ss,'발송대기',2,10);
 unique52A(m,'원장');unique52A(r,'스냅샷');unique52A(e,'이벤트');
 const review=readRows52A(ss,'지역정책',2,10).filter(x=>x[1]==='지역 확인 필요');
 const eventIds=new Set(e.map(x=>x[1]));
 const result={regionReviewCount:review.length,regionReviewOverdue3h:review.filter(x=>Number.isFinite(firstMsV4(x[7]))&&Date.now()-firstMsV4(x[7])>10800000).length,missingDiscoveryEvents:m.filter(x=>x[0]&&!String(x[0]).startsWith('HUG:ARCHIVE:')&&!eventIds.has(x[0])).length,version:'5.2-A.local.6',master:m.filter(x=>x[0]).length,raw:r.filter(x=>x[0]).length,events:e.filter(x=>x[0]).length,archiveEvents:e.filter(x=>String(x[1]).startsWith('HUG:ARCHIVE:')).length,triggerHandlers:ScriptApp.getProjectTriggers().map(t=>t.getHandlerFunction()),phase:p.getProperty('DERIVED_STEP42A')||'0',cursor:p.getProperty('DECISION_CURSOR52A')||'',writes:0,sends:0};
 console.log(JSON.stringify(result));return result;
}
function dryRunNotifications52A(config){
 config=config||{};const ss=SpreadsheetApp.openById(SPREADSHEET_ID),now=Date.now();
 const master=new Map(readRows52A(ss,'공고원장',5,40).map(r=>[r[0],r])),origins=new Map(readRows52A(ss,'발견구분',2,5).map(r=>[r[0],r[1]]));
 const details=new Map(readRows52A(ss,'공고상세',2,23).map(r=>[r[0],r]));
 const rawMap=new Map(readRows52A(ss,'수집원본',2,6).map(r=>[r[0],r]));
 const result={mode:'DRY_RUN_ONLY',candidates:0,holds:0,reasons:{},writes:0,sends:0};
 for(const e of readRows52A(ss,'발송대기',2,10)){
  const m=master.get(e[1]);let d=null;try{d=JSON.parse((details.get(e[1])||[])[16]||'null');}catch(_){}
  if(m)d=supplyDetail52A(m,d,rawMap);
  const n=m?{id:m[0],title:m[5],firstSeenAt:m[1],regionGroup:regionV4(m,d).group,archive:String(m[0]).startsWith('HUG:ARCHIVE:'),backfill:/백필|초기/.test(String(origins.get(m[0])||e[7]))}:{};
  const event={noticeId:e[1],createdAt:e[2],officialEventKey:e[0],kind:e[3]==='신규'?'NEW':'MATERIAL',allow:['발송완료','발송 완료'].includes(e[4])?'N':e[8],materialEvidence:null};
  const plan=deliveryPlan52A(n,event,config,{},now);
  if(plan.status==='DRY_RUN_CANDIDATE')result.candidates++;else{result.holds++;result.reasons[plan.reason]=(result.reasons[plan.reason]||0)+1;}
 }
 console.log(JSON.stringify(result));return result;
}
function supplyDetail52A(row,detail,rawMap){
 const d={...(detail||{})};let raw;try{raw=JSON.parse((rawMap.get(row[38])||[])[5]||'null');}catch(_){}
 d._sourceNoticeTitle=snapshotNoticeTitle52A((rawMap.get(row[38])||[])[5]);
 if(String(row[0]).startsWith('GH:')){d._supplyRegion=ghListingRegion52A(raw,row[0]);d._supplyRegionEvidence=raw&&raw.regionEvidence||null;}
 if(!d.address&&raw&&String(row[0]).startsWith('APPLYHOME:'))d.address=raw.HSSPLY_ADRES||'';
 return d;
}

function lockMiss52A(role){const p=PropertiesService.getScriptProperties();p.setProperty('LOCK_LAST52A_'+role,nowKst());console.log('LOCK_BUSY52A: '+role+'; 다음 기존 트리거 재시도·정상시각 보존');}

// 5.2-A.local.6 integrated helpers
function temporal52A(value){
 if(value instanceof Date)return Number.isFinite(value.getTime())?Utilities.formatDate(value,'Asia/Seoul','yyyy-MM-dd HH:mm:ss'):null;
 if(typeof value!=='string')return null;
 const s=value.trim();let m=s.match(/^(20\d{2})[-./](\d{1,2})[-./](\d{1,2})\.?$/);
 if(m){const y=+m[1],mo=+m[2],d=+m[3],date=new Date(Date.UTC(y,mo-1,d));if(date.getUTCFullYear()!==y||date.getUTCMonth()!==mo-1||date.getUTCDate()!==d)return null;return y+'-'+String(mo).padStart(2,'0')+'-'+String(d).padStart(2,'0')+' 00:00:00';}
 if(/^20\d{2}-\d{2}-\d{2}[ T]\d{2}:\d{2}(?::\d{2})?(?:Z|[+-]\d{2}:\d{2})?$/.test(s)){const t=Date.parse(s.replace(' ','T')+(/Z$|[+-]\d{2}:\d{2}$/.test(s)?'':'+09:00'));return Number.isFinite(t)?Utilities.formatDate(new Date(t),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'):null;}
 return null;
}
function sameCell52A(a,b){if(a===b)return true;const x=temporal52A(a),y=temporal52A(b);if(x!==null&&y!==null)return x===y;return (a==null?'':a)===(b==null?'':b);}
function safeText52A(v){return typeof v==='string'&&/^[=+@-]/.test(v)?"'"+v:v;}
function selectRole52A(p,now,canRun){
 const roles=['상세','첨부','후속'],turn=Number(p.getProperty('ANALYSIS_TURN42')||0)%roles.length;
 for(let n=0;n<roles.length;n++){const i=(turn+n)%roles.length,k=roles[i],last=Number(p.getProperty(workClock42(k))||0);if((!last||now-last>=3600000)&&canRun(k))return {kind:k,next:(i+1)%roles.length};}return null;
}
function executeRole52A(p,ss,deadline){
 if(Date.now()+30000>=deadline)return '실행시간 대기·역할 커서 보존';
 const choice=selectRole52A(p,Date.now(),k=>budgetStatus42(p,k,Date.now()).canRun);if(!choice)return '역할 쿨다운/예산 대기·커서 보존';
 const k=choice.kind,r=workBudget42(p,k,()=>{p.setProperty(workClock42(k),String(Date.now()));return k==='상세'?processDetail42(ss):k==='첨부'?processAttachment42(ss):processFollowups35(ss,1);});
 if(r.ran)p.setProperty('ANALYSIS_TURN42',String(choice.next));
 return r.ran?k+(r.value?' 실제저장':' 처리시도·대상없음/실패는 상세기록 참조'):r.reason;
}
function loadCheckpoint52A(props,key){
 const raw=props.getProperty(key);if(!raw)return null;const m=JSON.parse(raw);if(!m._idChunks52A)return m;
 const ids=[];for(const k of m._idChunks52A){const value=props.getProperty(k);if(value===null)throw Error('PARTIAL: checkpoint chunk missing');const a=JSON.parse(value);if(!Array.isArray(a))throw Error('SCHEMA: checkpoint chunk');ids.push(...a);}
 if(ids.length!==m._idCount52A||digest(JSON.stringify(ids))!==m._idHash52A)throw Error('PARTIAL: checkpoint count/hash mismatch');
 const s={...m,ids};delete s._idChunks52A;delete s._idHash52A;delete s._idCount52A;return s;
}
function clearCheckpoint52A(props,key){const m=JSON.parse(props.getProperty(key)||'null');props.deleteProperty(key);for(const k of m&&m._idChunks52A||[])props.deleteProperty(k);}
function detailJob52A(ss,id){const s=ss.getSheetByName('상세작업'),all=s.getDataRange().getValues();unique52A(all.slice(1),'상세작업');let at=all.findIndex((r,i)=>i>0&&r[0]===id);if(at<0){at=Math.max(1,s.getLastRow());const r=Array(15).fill('');r[0]=id;s.getRange(at+1,1,1,15).setValues([r]);return {s,at:at+1,row:r};}return {s,at:at+1,row:Array.from({length:15},(_,i)=>all[at][i]??'')};}
function a1Bounds52A(a){
 if(typeof a!=='string')return null;const m=a.match(/^\$?([A-Za-z]+)\$?(\d+)(?::\$?([A-Za-z]+)\$?(\d+))?$/);if(!m)return null;
 const col=s=>[...s.toUpperCase()].reduce((v,c)=>v*26+c.charCodeAt(0)-64,0),r=+m[2],c=col(m[1]),er=+(m[4]||m[2]),ec=col(m[3]||m[1]);if(r<1||c<1||er<r||ec<c)return null;return [r,c,er-r+1,ec-c+1];
}
function formula52A(value){if(typeof value!=='string'||!/^=/.test(value))throw Error('SCHEMA: trusted formula');return {_formula52A:value};}
function coalesceUpdates52A(updates){const out=[];for(const u of updates){const prev=out[out.length-1];if(prev&&prev.sheet===u.sheet&&prev.col===u.col&&prev.row+prev.values.length===u.row&&prev.values[0].length===u.values[0].length)prev.values.push(...u.values);else out.push({...u,values:u.values.slice()});}return out;}
function triggerGuide52A(){SpreadsheetApp.getUi().alert('목록 1시간/후처리 10분은 서로 다른 트리거입니다. 이 메뉴는 설치·삭제하지 않습니다. 실제 핸들러·주기·소유자 확인 및 별도 승인 후 운영자가 관리하세요.');}
function shReviewPolicy52A(master,events,now){const review=master.filter(m=>String(m[0]).startsWith('SH:')&&regionV4(m).group==='지역 확인 필요');return review.map(m=>({id:m[0],classification:'서울권 잠정후보/주소확인',personalSend:'N',reviewChannel:'LOCAL_REVIEW_ONLY',previousY:events.filter(e=>e[1]===m[0]&&e[8]==='Y').length,firstSeenAt:m[1],overdue:Number.isFinite(firstMsV4(m[1]))&&now-firstMsV4(m[1])>10800000,url:m[26],evidence:'기관/서울권 표기는 공급지 확정 아님; 공식 상세 소재지/첨부 공급주택표 확인 필요'}));}
function inspectSHReview52A(){const ss=SpreadsheetApp.openById(SPREADSHEET_ID);return shReviewPolicy52A(readRows52A(ss,'공고원장',5,40),readRows52A(ss,'발송대기',2,10),Date.now());}
function leaseDue52A(value,now){if(value===''||value==null)return true;const t=firstMsV4(value);return Number.isFinite(t)&&t<=now;}
function safeMasterRows52A(master,width=40){return master.getLastRow()>=5?master.getRange(5,1,master.getLastRow()-4,width).getValues():[];}
function areaNumber52A(value){const s=String(value||'').trim().replace(/\s*(?:㎡|m²)$/i,'');if(!/^\d+(?:\.\d+)?$/.test(s))return NaN;return Number(s);}
function queuePolicyView52A(ss,fn){
 const real=ss.getSheetByName('발송대기');let policy=null;const load=()=>policy||(policy=readRows52A(ss,'발송대기',2,10).map(e=>e.slice(7,10)));
 const wrapped=new Proxy(real,{get(s,k){if(k==='getDataRange')return()=>({getValues(){const rows=s.getDataRange().getValues(),p=load();for(let i=1;i<rows.length;i++)if(p[i-1])rows[i].splice(7,3,...p[i-1]);return rows;}});
 if(k==='getRange')return(...a)=>{const range=s.getRange(...a);if(typeof a[0]!=='number')return range;return new Proxy(range,{get(r,key){if(key==='setValues'&&a[1]===8&&a[3]===3)return values=>{const p=load();for(let i=0;i<values.length;i++)p[a[0]-2+i]=values[i].slice();return range;};if(key==='getValues')return()=>{const values=r.getValues(),p=load();for(let i=0;i<values.length;i++)for(let j=0;j<values[i].length;j++){const c=a[1]+j;if(c>=8&&c<=10&&p[a[0]+i-2])values[i][j]=p[a[0]+i-2][c-8];}return values;};const v=r[key];return typeof v==='function'?v.bind(r):v;}});};const v=s[k];return typeof v==='function'?v.bind(s):v;}});
 const view=new Proxy(ss,{get(s,k){if(k==='getSheetByName')return name=>name==='발송대기'?wrapped:s.getSheetByName(name);const v=s[k];return typeof v==='function'?v.bind(s):v;}});
 const result=fn(view);if(policy&&policy.length)commitQueuePolicy52A(real,policy);return result;
}
function ghIdentity52A(html,r){
 const urlIds=[...String(r.url||'').matchAll(/[?&](?:articleNo|pbancNo|bbsSn)=(\d+)/g)].map(x=>x[1]);if(urlIds.some(x=>x!==String(r.number)))return false;
 const ids=[];for(const input of html.matchAll(/<input\b[^>]*>/gi)){const name=(input[0].match(/name=["']([^"']+)["']/i)||[])[1],value=(input[0].match(/value=["']([^"']+)["']/i)||[])[1];if(/^(?:pbancNo|bbsSn|articleNo)$/.test(name||'')&&value)ids.push(value);}
 if(ids.length&&ids.some(id=>id!==String(r.number)))return false;
 const text=ghTextV4(html),norm=x=>String(x).normalize('NFKC').replace(/[\s‘’'“”"·]/g,'');
 if(norm(text).includes(norm(r.title))&&html.includes(String(r.number)))return true;
 // Truncation is accepted only with an explicit official identifier and complete prefix evidence.
 const title=String(r.title).replace(/(?:\.\.\.|…)$/,'').trim();return ids.includes(String(r.number))&&title!==r.title&&title.length>=12&&norm(text).includes(norm(title));
}
function ensureDashboardChart52A(s){
 const title='최근 7일 서울·경기 신규 발견 · 초기 백필 제외',matches=s.getCharts().filter(c=>c.getOptions().get('title')===title&&c.getContainerInfo().getAnchorRow()===109&&c.getContainerInfo().getAnchorColumn()===1);
 for(const c of matches.slice(1))s.removeChart(c);if(matches.length)return;
 s.insertChart(s.newChart().asColumnChart().addRange(s.getRange('I95:J102')).setPosition(109,1,0,0).setOption('title',title).setOption('legend',{position:'none'}).setOption('colors',['#55856c']).setOption('width',660).setOption('height',280).build());
}
function commitQueuePolicy52A(sheet,policy){
 if(!policy.length)return 0;const old=sheet.getRange(2,8,policy.length,3).getValues();if(policy.every((r,i)=>r.every((v,j)=>sameCell52A(v,(old[i]||[])[j]))))return 0;
 sheet.getRange(2,8,policy.length,3).setValues(policy.map(r=>r.map(safeText52A)));return policy.length;
}
function checkpointCompatibility52A(){
 const p=PropertiesService.getScriptProperties(),keys=p.getKeys().filter(k=>/^(?:SH_PAGE35_|GH_PAGE4_)/.test(k)&&!k.includes(':IDS52A:'));
 return keys.map(key=>{const m=JSON.parse(p.getProperty(key)||'null'),state=loadCheckpoint52A(p,key),bytes=Utilities.newBlob(JSON.stringify(state)).getBytes().length;return {key,chunked:!!(m&&m._idChunks52A),legacyBytes:bytes,legacyFits:bytes<8500,rollback:'별도 승인하에 기준키만 제거 후 1페이지 재대조; 원장/원천 삭제 금지',writes:0};});
}
// local.3 targeted guards and supply provenance
function resultNotice52A(title){
 const t=String(title||'').normalize('NFKC').replace(/[\s\u200B-\u200D\uFEFF]+/g,'');
 return /(?:선정|모집(?:공고|시행|접수)?|접수|공급|당첨|배정|심사|서류(?:전형|심사)?|계약|추첨)(?:최종)?결과|경쟁률|(?:예비)?당첨자|(?:서류(?:제출|심사)?|입주|심사)대상자?(?:선정)?(?:발표|안내|공고)|신청(?:접수)?현황/.test(t);
}
function recruitmentAction52A(title){
 let t=String(title||'').normalize('NFKC').replace(/[\s\u200B-\u200D\uFEFF]+/g,'');
 // An action embedded in the name of a COMPLETED recruitment round is not a new action.
 t=t.replace(/(?:(?:추가|신규)(?:입주자)?모집|재모집|재공급|추가접수|접수재개)(?:공고|접수|신청|분)?(?:선정)?결과(?:발표|안내|공고)?/g,'')
  .replace(/(?:(?:추가|신규)(?:입주자)?모집|재모집|재공급)(?:공고)?(?:당첨자|서류제출대상자|입주대상자|경쟁률|접수현황)(?:발표|게시|명단|안내|공고)/g,'');
 return rankApplicationAction52A4(title)||resultNotice52A(title)&&/신규(?:입주자)?모집/.test(t)||/추가(?:입주자)?(?:모집|접수)|재모집|재공급|(?:접수|신청)재개|(?:접수|신청)기간.{0,30}(?:변경|연장)|(?:신청)?자격.{0,20}(?:확대|완화)|당첨자발표일.{0,20}(?:변경|정정)/.test(t);
}
function ghListRegionEvidence52A(html,rowHtml,url){
 const unknown={region:'',regionEvidence:{kind:'UNKNOWN',url,position:'목록에 확인 가능한 공식 공급 소재지 열 없음'}};
 for(const table of String(html).match(/<table\b[^>]*>[\s\S]*?<\/table>/gi)||[]){
  if(!table.includes(rowHtml))continue;
  const header=(table.match(/<tr\b[^>]*>[\s\S]*?<th\b[\s\S]*?<\/tr>/i)||[])[0];
  if(!header||/\b(?:colspan|rowspan)\s*=\s*["']?(?:[2-9]|\d{2,})/i.test(header))return unknown;
  const labels=[...header.matchAll(/<th\b[^>]*>([\s\S]*?)<\/th>/gi)].map(x=>ghTextV4(x[1]));
  const index=labels.findIndex(x=>/^(?:공급(?:주택)?(?:소재지|주소|지역|위치)|주택(?:소재지|주소)|소재지)$/.test(x.replace(/\s+/g,'')));
  if(index<0)return unknown;
  const context=ghTextV4((table.match(/<caption\b[^>]*>([\s\S]*?)<\/caption>/i)||[])[1]||'')+' '+labels.join(' ');
  if(labels[index].replace(/\s+/g,'')==='소재지'&&!/공급주택|모집주택|주택목록|단지명|주택형|주택명/.test(context.replace(/\s+/g,'')))return unknown;
  const cells=[...rowHtml.matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map(x=>ghTextV4(x[1]));
  if(cells.length!==labels.length||!cells[index])return unknown;
  return {region:cells[index],regionEvidence:{kind:'OFFICIAL_SUPPLY_COLUMN',url,position:'목록 표 '+labels[index]+' 열('+String(index+1)+')',field:labels[index],context:context.slice(0,300),value:cells[index]}};
 }
 return unknown;
}
function ghListingRegion52A(raw,id){
 if(!raw)return '';
 const evidence=raw.regionEvidence;
 if(evidence&&String(evidence.field||'').replace(/\s+/g,'')==='소재지'&&!/공급주택|모집주택|주택목록|단지명|주택형|주택명/.test(String(evidence.context||'').replace(/\s+/g,'')))return '';
 if(evidence&&evidence.kind==='OFFICIAL_SUPPLY_COLUMN'&&evidence.url&&evidence.position&&evidence.value===raw.region&&/^(?:공급(?:주택)?(?:소재지|주소|지역|위치)|주택(?:소재지|주소)|소재지)$/.test(String(evidence.field||'').replace(/\s+/g,'')))return String(raw.region||'');
 if(evidence)return ''; // Explicitly unknown or invalid provenance never falls back to the old value.
 const manufactured=/^GH:(?:WEB|NOTICE):/.test(String(id||''))||/[?&](?:articleNo|bbsSn)=/.test(String(raw.url||''))||raw.type==='GH 공지';
 // Legacy WEB/NOTICE parsers inserted this exact value without an official supply field.
 return manufactured&&String(raw.region||'').trim()==='경기도'?'':String(raw.region||'');
}
function snapshotNoticeTitle52A(json){let raw;try{raw=JSON.parse(String(json||'null'));}catch(_){return '';}return String(raw&&(raw.title||raw.HOUSE_NM||Array.isArray(raw.td)&&raw.td[2])||'');}
var V52A4_ACTIVE=false;
function rankApplicationAction52A4(title){
 let t=String(title||'').normalize('NFKC').replace(/[\s\u200B-\u200D\uFEFF]+/g,'');
 t=t.replace(/(?:[1-9]\d*(?:[·ㆍ,~∼-][1-9]\d*)*순위|다음순위|후순위|무순위|잔여(?:세대|호실))(?:청약)?(?:접수|신청|청약)?(?:선정|당첨)?결과(?:발표|안내|공고)?/g,'')
  .replace(/(?:[1-9]\d*(?:[·ㆍ,~∼-][1-9]\d*)*순위|무순위)(?:청약)?(?:당첨자|대상자|선정자)(?:발표|명단|선정결과|안내)/g,'');
 return /(?:[1-9]\d*순위|다음순위|후순위)(?:청약)?(?:접수|신청)(?:안내|공고|재개|일정|기간|실시|예정)|(?:무순위|잔여(?:세대|호실))(?:청약|접수|신청)(?:안내|공고|접수|신청|재개)?|재접수|추가청약(?:안내|접수|공고)/.test(t);
}
function packGeneration52A4(x){if(Object.prototype.toString.call(x)==='[object Date]')return {_date52A4:x.getTime()};if(Array.isArray(x))return x.map(packGeneration52A4);if(x&&typeof x==='object'){const o={};for(const k of Object.keys(x))o[k]=packGeneration52A4(x[k]);return o;}return x;}
function unpackGeneration52A4(x){if(x&&typeof x==='object'&&!Array.isArray(x)&&Object.keys(x).length===1&&Number.isFinite(x._date52A4))return new Date(x._date52A4);if(Array.isArray(x))return x.map(unpackGeneration52A4);if(x&&typeof x==='object'){const o={};for(const k of Object.keys(x))o[k]=unpackGeneration52A4(x[k]);return o;}return x;}
function generationInputs52A4(ss){
 const names=['공고원장','공고상세','수집원본','발송대기','정정이력','교차게시검토','SH후속안내','GH후속안내','발견구분'],data={};
 for(const n of names){const s=ss.getSheetByName(n);data[n]=s?s.getDataRange().getValues():null;}return data;
}
function generationHashMap52A4(data){
 const ds=new Map((data['공고상세']||[]).slice(1).map(r=>[r[0],r])),raw=new Map((data['수집원본']||[]).slice(1).map(r=>[r[0],r])),out=new Map();
 for(const m of (data['공고원장']||[]).slice(4).filter(r=>r[0]))out.set(m[0],digest(JSON.stringify(packGeneration52A4([m.map((v,i)=>[28,31,32,37].includes(i)?null:v),(ds.get(m[0])||[]).map((v,i)=>i===2?null:v),(raw.get(m[38])||[]).map((v,i)=>i===1?null:v)]))));return out;
}
function loadGeneration52A4(ss){
 const p=PropertiesService.getScriptProperties(),pointer=p.getProperty('DERIVED_GEN52A4');if(!pointer)return null;const m=JSON.parse(pointer),s=ss.getSheetByName('_52A4_GENERATIONS');if(!s)throw Error('SCHEMA: generation storage missing');
 const rows=s.getRange(m.row,1,m.count,5).getValues();if(rows.some((r,i)=>r[0]!==m.id||r[1]!==i||r[2]!==m.count||r[3]!=='H:'+m.hash))throw Error('SCHEMA: generation chunk identity mismatch');if(rows.some(r=>!String(r[4]).startsWith('J:')))throw Error('SCHEMA: generation payload prefix');const text=rows.map(r=>String(r[4]).slice(2)).join('');if(digest(text)!==m.hash)throw Error('SCHEMA: generation checksum mismatch');
 return {meta:m,data:unpackGeneration52A4(JSON.parse(text))};
}
function beginGeneration52A4(ss){
 const p=PropertiesService.getScriptProperties(),startedMs=Date.now(),data=generationInputs52A4(ss);for(const [name,start]of [['공고원장',4],['공고상세',1],['수집원본',1],['발송대기',1]])unique52A((data[name]||[]).slice(start),name);const text=JSON.stringify(packGeneration52A4(data)),hash=digest(text),sequence=Number(p.getProperty('DERIVED_GEN_SEQ52A4')||0)+1,id='G:'+sequence+':'+Date.now()+':'+hash.slice(0,16),parts=[];if(!Number.isSafeInteger(sequence)||Utilities.newBlob(text).getBytes().length>5*1024*1024)throw Error('PARTIAL: generation size/sequence limit·no truncation');p.setProperty('DERIVED_GEN_SEQ52A4',String(sequence));
 for(let i=0;i<text.length;i+=20000)parts.push(text.slice(i,i+20000));if(!parts.length)parts.push('{}');
 let s=ss.getSheetByName('_52A4_GENERATIONS');if(!s)s=ss.insertSheet('_52A4_GENERATIONS');const header=['generation','chunk','count','sha256','payload'];if(!s.getLastRow())s.getRange(1,1,1,5).setValues([header]);else if(JSON.stringify(s.getRange(1,1,1,5).getValues()[0])!==JSON.stringify(header))throw Error('SCHEMA: reserved generation sheet header conflict');
 const row=s.getLastRow()+1;ensureRowsV4(s,row+parts.length-1);s.getRange(row,1,parts.length,5).setValues(parts.map((part,i)=>[id,i,parts.length,'H:'+hash,'J:'+part]));SpreadsheetApp.flush();
 const meta={version:1,id,row,count:parts.length,hash,startedMs,startedAt:Utilities.formatDate(new Date(startedMs),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'),day:Utilities.formatDate(new Date(startedMs),'Asia/Seoul','yyyy-MM-dd'),baselineAt:p.getProperty('V3_STARTED')||''};
 // Publish pointer only after immutable chunks. A killed write can leave orphan chunks, not a valid partial generation.
 p.setProperty('DERIVED_GEN52A4',JSON.stringify(meta));p.deleteProperty('DECISION_CURSOR52A');return {meta,data,fresh:true};
}
function generationContext52A4(ss,gen,captured){
 const live=captured||generationInputs52A4(ss),frozenHash=generationHashMap52A4(gen.data),liveHash=generationHashMap52A4(live),dirty=new Set();
 for(const [id,h]of frozenHash)if(liveHash.get(id)!==h)dirty.add(id);for(const id of liveHash.keys())if(!frozenHash.has(id))dirty.add(id);
 const events=new Map((live['발송대기']||[]).slice(1).map(r=>[r[0],r])),frozenEvents=new Map((gen.data['발송대기']||[]).slice(1).map(r=>[r[0],r]));
 let changedEvents=0;for(const [key,e]of frozenEvents){const x=events.get(key);if(!x||JSON.stringify(packGeneration52A4(x.slice(0,7)))!==JSON.stringify(packGeneration52A4(e.slice(0,7))))changedEvents++;}for(const key of events.keys())if(!frozenEvents.has(key))changedEvents++;
 const auxChanged=['정정이력','교차게시검토','SH후속안내','GH후속안내','발견구분'].filter(n=>digest(JSON.stringify(packGeneration52A4(live[n])))!==digest(JSON.stringify(packGeneration52A4(gen.data[n]))));const baselineChanged=(PropertiesService.getScriptProperties().getProperty('V3_STARTED')||'')!==(gen.meta.baselineAt||'');return {checkedAt:nowKst(),auxChanged,baselineChanged,live,frozenHash,liveHash,dirty,events,frozenEvents,pending:dirty.size+changedEvents+auxChanged.length+(baselineChanged?1:0)+(gen.meta.day!==todayKst()?1:0)};
}
function finiteView52A4(ss,gen,ctx,deadline,screen=false){
 const base=cachedDerivedView42A(ss),ids=(gen.data['공고원장']||[]).slice(4).filter(r=>r[0]).map(r=>r[0]),targets=new Set(['공고판정','지역정책']),sheets=new Map();
 const same=id=>ctx.liveHash.has(id)&&ctx.liveHash.get(id)===ctx.frozenHash.get(id);
 const virtual=(name)=>{const real=base.getSheetByName(name);if(!real)return null;let data;
  if(targets.has(name)){const all=real.getDataRange().getValues(),by=new Map(all.slice(1).map(r=>[r[0],r]));data=[all[0]||[],...ids.map(id=>by.get(id)||[])];}
  else if(name==='발송대기')data=(gen.data[name]||[]).map((r,i)=>i?[...r.slice(0,7),...(ctx.events.get(r[0])||r).slice(7)]:r.slice());
  else data=(gen.data[name]||[]).filter((r,i)=>!screen||name!=='공고원장'||i<4||same(r[0])).map(r=>r.slice());
  const commit=(row,col,values)=>{
   if(!targets.has(name)&&name!=='발송대기')throw Error('SCHEMA: frozen input write forbidden '+name);
   const actual=real.getDataRange().getValues(),index=new Map(actual.slice(1).map((r,i)=>[r[0],i+2])),writes=[];
   for(let i=0;i<values.length;i++){
    const v=values[i],entry=data[row-1+i]||[],id=targets.has(name)?v[0]:entry[1],key=targets.has(name)?id:entry[0];
    if(!same(id)){ctx.dirty.add(id);continue;}
    if(name==='발송대기'){if(ctx.auxChanged.length||ctx.baselineChanged)continue;const live=ctx.events.get(key);if(col!==8||v.length!==3||!live||JSON.stringify(packGeneration52A4(live.slice(0,7)))!==JSON.stringify(packGeneration52A4(entry.slice(0,7)))||['발송완료','발송 완료'].includes(live[4]))continue;}
    let at=index.get(key);if(!at){if(name==='발송대기')continue;at=actual.length+1;actual.push([]);index.set(key,at);}
    writes.push({at,v});
   }
   writes.sort((a,b)=>a.at-b.at);const groups=[];for(const w of writes){const last=groups[groups.length-1];if(last&&last.at+last.rows.length===w.at)last.rows.push(w.v);else groups.push({at:w.at,rows:[w.v]});}
   for(const g of groups){if(Date.now()+3000>=deadline)throw Error('YIELD52A4: safe batch continuation');ensureRowsV4(real,g.at+g.rows.length-1);real.getRange(g.at,col,g.rows.length,g.rows[0].length).setValues(g.rows);for(let i=0;i<g.rows.length;i++){const key=targets.has(name)?g.rows[i][0]:(actual[g.at+i-1]||[])[0];if(name==='발송대기'&&ctx.events.has(key))ctx.events.get(key).splice(7,3,...g.rows[i]);}}
  };
  return new Proxy(real,{get(s,k){if(k==='getDataRange')return()=>({getValues:()=>data.map(r=>r.slice())});if(k==='getLastRow')return()=>data.length;if(k==='getRange')return(...a)=>{
   const bounds=typeof a[0]==='number'?a:a1Bounds52A(a[0]);const r=s.getRange(...a);if(!bounds)return r;
   const [row,col,h=1,w=1]=bounds;return new Proxy(r,{get(range,key){if(key==='getValues')return()=>Array.from({length:h},(_,i)=>Array.from({length:w},(_,j)=>(data[row-1+i]||[])[col-1+j]??''));if(key==='setValues')return values=>{commit(row,col,values);for(let i=0;i<values.length;i++){while(data.length<row+i)data.push([]);for(let j=0;j<values[i].length;j++)data[row-1+i][col-1+j]=values[i][j];}return range;};const v=range[key];return typeof v==='function'?v.bind(range):v;}});
  };const v=s[k];return typeof v==='function'?v.bind(s):v;}});
 };
 return new Proxy(base,{get(s,k){if(k==='getSheetByName')return name=>{if(!targets.has(name)&&!Object.prototype.hasOwnProperty.call(gen.data,name))return s.getSheetByName(name);if(name==='발견구분'&&screen)return s.getSheetByName(name);if(gen.data[name]===null)return s.getSheetByName(name);if(!sheets.has(name))sheets.set(name,virtual(name));return sheets.get(name);};const v=s[k];return typeof v==='function'?v.bind(s):v;}});
}
function runDerivedFinite52A4(ss){
 const p=PropertiesService.getScriptProperties(),phase=Number(p.getProperty('DERIVED_STEP42A')||0)%4,aux=Number(p.getProperty('DERIVED_AUX42A')||0)%4,label=['공고판정','지역정책','사용자현황판','유지관리'][phase],slot=50000,start=Date.now();
 if(start+slot+15000>V4_END){p.setProperty('DERIVED_WAIT42A','세대 실행시간 대기');return false;}
 if(!budgetStatus42(p,'파생',start,slot).canRun){p.setProperty('DERIVED_WAIT42A','세대 파생 예산 대기·커서 보존');return false;}
 let gen,ctx,lag;let result;
 try{result=workBudget42(p,'파생',()=>{try{
  gen=loadGeneration52A4(ss);if(!gen){if(phase!==0){p.setProperty('DERIVED_STEP42A','0');return false;}gen=beginGeneration52A4(ss);}
  ctx=generationContext52A4(ss,gen,gen.fresh?gen.data:null);gen.fresh=false;p.setProperty('DERIVED_PENDING52A4',String(ctx.pending));const finish=()=>{lag=phase===3?generationContext52A4(ss,gen):{...ctx,pending:Math.max(ctx.pending,ctx.dirty.size)};return true;};const until=Math.min(V4_END-20000,start+45000),view=finiteView52A4(ss,gen,ctx,until,phase===2);
  if(phase===0){for(let i=0;i<100&&Date.now()+5000<until;i++)if(decisionSliceLegacy52A3(view,until,gen.meta.day))return finish();return false;}
  if(phase===1){refreshRegionV4(view);return finish();}
  if(phase===2){refreshUserDashboardV4(view);const board=ss.getSheetByName(USER_SHEET4);if(board)board.getRange('A2').setValue('세대 기준 '+gen.meta.startedAt+' KST · 최신 반영 대기 '+ctx.pending+' · 세대/최신 완료 구분');return finish();}
  const jobs=[reconcileQualityV2,reconcileExceptionsV3,prepareReminders35,s=>refreshMonitor(s,true)];jobs[aux](cachedDerivedView42A(ss));return finish();
 }catch(e){if(String(e.message||e).startsWith('YIELD52A4:'))return false;throw e;}},slot);}catch(e){p.setProperty('DERIVED_WAIT42A','세대 실패·이전 정상시각/커서 보존');throw e;}
 p.setProperty('DERIVED_COST42A_'+label,String(Date.now()-start));if(!result.ran||!result.value){p.setProperty('DERIVED_WAIT42A','고정 세대 부분진행·다음 예약 재개');return false;}
 const stamp=nowKst();p.setProperty('DERIVED_INPUT_VALIDATED_AT52A4',lag.checkedAt);p.setProperty('DERIVED_SNAPSHOT_OK52A4_'+label,stamp);p.setProperty('DERIVED_SNAPSHOT_AT52A4',gen.meta.startedAt);p.setProperty('DERIVED_PENDING52A4',String(lag.pending));
 if(!lag.pending)p.setProperty('DERIVED_OK42A_'+label,stamp);p.setProperty('DERIVED_WAIT42A',lag.pending?'최신 입력 대기 '+lag.pending+' · 다음 세대 처리':'');p.setProperty('DERIVED_STEP42A',String((phase+1)%4));
 if(phase===2&&!lag.pending)p.setProperty('DERIVED_AT42',String(Date.now()));
 if(phase===3){p.setProperty('DERIVED_AUX42A',String((aux+1)%4));p.setProperty('DERIVED_GENERATION_DONE52A4',gen.meta.id);p.setProperty('DERIVED_GENERATION_DELAY_MS52A4',String(Date.now()-gen.meta.startedMs));if(!lag.pending)p.setProperty('DERIVED_LIVE_OK52A4',stamp);p.deleteProperty('DERIVED_GEN52A4');p.deleteProperty('DECISION_CURSOR52A');}
 return true;
}
function inspectGeneration52A4(){const p=PropertiesService.getScriptProperties(),ss=SpreadsheetApp.openById(SPREADSHEET_ID),m=JSON.parse(p.getProperty('DERIVED_GEN52A4')||'null'),s=ss.getSheetByName('_52A4_GENERATIONS');return {active:m&&{id:m.id,startedAt:m.startedAt,chunks:m.count},snapshotCompleted:p.getProperty('DERIVED_GENERATION_DONE52A4'),pending:Number(p.getProperty('DERIVED_PENDING52A4')||0),inputValidatedAt:p.getProperty('DERIVED_INPUT_VALIDATED_AT52A4'),liveConsistentAt:p.getProperty('DERIVED_LIVE_OK52A4'),storageRows:s?s.getLastRow():0,writes:0,sends:0};}
function refreshReviewWatch52A4(ss){
 const p=PropertiesService.getScriptProperties(),now=Date.now();if(now-Number(p.getProperty('REVIEW_WATCH_AT52A4')||0)<1800000)return;
 const master=readRows52A(ss,'공고원장',5,40);unique52A(master,'review master');const known=new Set(master.map(r=>r[0]));for(const [name,prefix]of [['SH게시판대조','SH:'],['GH게시판대조','GH:']])for(const a of readRows52A(ss,name,2,13)){if(noticeKind52A(a[6])!=='REVIEW'||!recruitmentAction52A(a[6])||!a[5])continue;const route=prefix==='GH:'?GH_ROUTES4.find(c=>c.id===a[1]):null;if(prefix==='GH:'&&!route)continue;const id=prefix==='SH:'?'SH:'+a[5]:'GH:'+(route.kind==='web'?'WEB:':route.kind==='notice'?'NOTICE:':'APPLY:')+a[5];if(known.has(id))continue;const r=Array(40).fill('');r[0]=id;r[5]=a[6];r[26]=a[10];master.push(r);known.add(id);}const details=new Map(readRows52A(ss,'공고상세',2,23).map(r=>[r[0],r])),raw=new Map(readRows52A(ss,'수집원본',2,6).map(r=>[r[0],r])),events=readRows52A(ss,'발송대기',2,10),prior=readRows52A(ss,'_52A4_REVIEW',2,12),map=new Map(unique52A(prior,'review states').map(r=>[r[0],r]));
 for(const m of master){if(!m[0]||!/^SH:|^GH:/.test(String(m[0])))continue;let d=null;try{d=JSON.parse((details.get(m[0])||[])[16]||'null');}catch(_){}d=supplyDetail52A(m,d,raw);const geo=regionV4(m,d),old=map.get(m[0]);if(geo.group!=='지역 확인 필요'&&!old)continue;
  const first=old&&old[2]||nowKst();if(!Number.isFinite(firstMsV4(first)))throw Error('SCHEMA: review firstPendingAt invalid');const age=Math.max(0,(now-firstMsV4(first))/3600000),previousY=Math.max(Number(old&&old[5]||0),events.filter(e=>e[1]===m[0]&&e[8]==='Y').length),pending=geo.group==='지역 확인 필요';
  const next=[m[0],pending?'PENDING':geo.eligible?'RESOLVED_TARGET':'RESOLVED_OUTSIDE',first,nowKst(),stampV3(m[1]),previousY,age,pending?(age>=3?'CRITICAL':previousY?'HIGH':age>=0.5?'WARNING':'PENDING'):'RESOLVED',pending?'기존 상세큐/수동확인 대기·SLA 미확정':'',old&&old[9]||'담당 지정/원문 확인 필요',m[26],geo.reason+' · 외부발송 없음'];if(old&&[1,5,7,8,9,10,11].every(i=>sameCell52A(old[i],next[i]))){next[3]=old[3];next[6]=old[6];}map.set(m[0],next);
 }
 const header=['공고ID','검토상태','최초검토대기(KST·고정)','최근상태변경','최초발견','기존Y최대','기록시점대기(h)','로컬경고','원문확인계획','담당/조치','원문URL','근거'];let sheet=ss.getSheetByName('_52A4_REVIEW');if(!sheet)sheet=ss.insertSheet('_52A4_REVIEW');if(!sheet.getLastRow())sheet.getRange(1,1,1,12).setValues([header]);else if(JSON.stringify(sheet.getRange(1,1,1,12).getValues()[0])!==JSON.stringify(header))throw Error('SCHEMA: reserved review sheet header conflict');
 const rows=[...map.values()];ensureRowsV4(sheet,rows.length+1);if(rows.length)writeChangedRows42A(sheet,2,1,rows);p.setProperty('REVIEW_WATCH_AT52A4',String(now));p.setProperty('REVIEW_WATCH_PENDING52A4',String(rows.filter(r=>r[1]==='PENDING').length));
}
function inspectReviewWatch52A4(){const ss=SpreadsheetApp.openById(SPREADSHEET_ID),p=PropertiesService.getScriptProperties(),now=Date.now();return {checkedAt:nowKst(),workerStale3h:now-Number(p.getProperty('REVIEW_WATCH_AT52A4')||0)>10800000,rows:readRows52A(ss,'_52A4_REVIEW',2,12).map(r=>({id:r[0],state:r[1],firstPendingAt:r[2],currentAgeHours:Number.isFinite(firstMsV4(r[2]))?Math.max(0,(now-firstMsV4(r[2]))/3600000):null,recordedLevel:r[7],owner:r[9],url:r[10]})),writes:0,sends:0};}
function decisionSliceLegacy52A3(ss,deadline,snapshotDay){
 const p=PropertiesService.getScriptProperties(),state=JSON.parse(p.getProperty('DECISION_CURSOR52A')||'{"part":"decisions","offset":0}');
 const end=Math.min(deadline,Date.now()+45000),size=100,now=nowKst(),today=snapshotDay||todayKst();
 const master=unique52A(readRows52A(ss,'공고원장',5,40).filter(r=>r[0]),'원장');
 const ds=new Map(unique52A(readRows52A(ss,'공고상세',2,23),'상세').map(r=>[r[0],r]));
 const revisionRows=readRows52A(ss,'수집원본',2,6),sourceMap=new Map(revisionRows.map(r=>[r[0],r]));
 const signatureNow=digest(JSON.stringify([today,master,[...ds],revisionRows]));
 if(state.signature&&state.signature!==signatureNow){state.part='decisions';state.offset=0;state.signature=signatureNow;}
 const decisions=ss.getSheetByName('공고판정');
 unique52A(readRows52A(ss,'공고판정',2,16),'판정');
 if(state.part==='decisions'){
  // ID order fingerprint prevents stale numeric cursors after insertion/reordering.
  const sig=signatureNow;
  if(state.signature!==sig){state.offset=0;state.signature=sig;}
  if(Date.now()+5000>=end)return false;
  const rows=master.slice(state.offset,state.offset+size).map(r=>decisionRow52A(r,ds.get(r[0]),now,today,snapshotNoticeTitle52A((sourceMap.get(r[38])||[])[5])));
  ensureRowsV4(decisions,state.offset+rows.length+1);
  if(rows.length)writeChangedRows42A(decisions,state.offset+2,1,rows,true);
  state.offset+=rows.length;
  if(state.offset>=master.length){state.part='queue';state.offset=0;}
  p.setProperty('DECISION_CURSOR52A',JSON.stringify(state));return false;
 }
 const queue=ss.getSheetByName('발송대기'),events=unique52A(readRows52A(ss,'발송대기',2,10),'이벤트');
 const signature=digest(JSON.stringify(events.map(r=>[r[0],r[1],r[2],r[3],r[4],r[5],r[6]])));
 if(state.queueSignature!==signature){state.offset=0;state.queueSignature=signature;}
 const dm=new Map(readRows52A(ss,'공고판정',2,16).map(r=>[r[0],r])),mm=new Map(master.map(r=>[r[0],r]));
 const hm=new Map(readRows52A(ss,'정정이력',5,11).map(r=>[r[10],r]));
 const aliases=new Map(validAliasesV4(ss,master)),derived=derivedEvents35(ss);
 const rawRows=readRows52A(ss,'수집원본',2,6),rawMap=new Map(rawRows.map(r=>[r[0],r]));
 const gh=ghChangePoliciesV4(events,rawRows);
 const sf=new Map(readRows52A(ss,'SH후속안내',2,7).map(r=>[r[0],r])),gf=new Map(readRows52A(ss,'GH후속안내',2,13).map(r=>[r[0],r]));
 const v3=p.getProperty('V3_STARTED');if(Date.now()+5000>=end)return false;
 const batch=events.slice(state.offset,state.offset+size),out=batch.map((e,i)=>{
  if(['발송완료','발송 완료'].includes(e[4]))return e.slice(7,10);
  const m=mm.get(e[1]);if(!m)return [e[7],'N','5.2-A: 원 모집 연결 확인 필요'];
  let policy=notificationV3(e,dm.get(e[1]),m[1],v3);
  if(derived.has(e[0]))policy=['파생분류 보완','N','공식 판단 핵심값 동일'];
  if(e[3]==='후속안내'){
   if(String(e[1]).startsWith('SH:')&&['일반 안내','단순 결과'].includes(followupType35((sf.get(e[1])||[])[1]||'')))policy=['SH 일반/결과 안내','N','모집대상 제외'];
   if(String(e[1]).startsWith('GH:')){const f=gf.get(e[1]);policy=ghFollowupPolicyV4(e,f,!f||!f[11]||String(f[11]).startsWith('초기백필'),dm.get((f||[])[4]));}
  }
  if(String(e[1]).startsWith('GH:')&&e[3]==='변경')policy=gh[state.offset+i];
  if(e[3]==='상세변경')policy=detailEventPolicy42A([...e.slice(0,7),...policy],hm.get(e[0]));
  if(aliases.has(e[1])&&e[3]==='신규')policy=[policy[0],'N','동일 모집 확인·대표ID '+aliases.get(e[1])];
  let detail=null;try{detail=JSON.parse((ds.get(e[1])||[])[16]||'null');}catch(_){}
  detail=supplyDetail52A(m,detail,rawMap);policy=notificationRegionV4(e,m,policy,detail);
  if(['EXCLUDED','REVIEW'].includes(noticeKind52A(detail&&detail._sourceNoticeTitle||m[5])))policy=[policy[0],'N','5.2-A: 주거 모집/중요변경 근거 확인 필요'];
  return policy;
 });
 if(out.length)writeChangedRows42A(queue,state.offset+2,8,out);
 state.offset+=batch.length;
 if(state.offset>=events.length){p.deleteProperty('DECISION_CURSOR52A');return true;}
 p.setProperty('DECISION_CURSOR52A',JSON.stringify(state));return false;
}
// Lossless snapshot storage v5. Source/audit/user sheets are never garbage-collected.
function snapshotSpec52A5(){return [['공고원장',40],['공고상세',23],['수집원본',6],['발송대기',10],['정정이력',11],['교차게시검토',5],['SH후속안내',7],['GH후속안내',13],['발견구분',5]];}
function generationInputs52A5(ss){const out={};for(const [name,width]of snapshotSpec52A5()){const s=ss.getSheetByName(name);out[name]=s?s.getRange(1,1,Math.max(1,s.getLastRow()),width).getValues():null;}return out;}
function utf8Bytes52A5(s){return Array.from(Utilities.newBlob(s).getBytes(),n=>n&255);}
function utf8Text52A5(b){let s='';for(let i=0;i<b.length;){const a=b[i++];let n,need,min;if(a<128){n=a;need=0;min=0;}else if(a>=194&&a<=223){n=a&31;need=1;min=128;}else if(a>=224&&a<=239){n=a&15;need=2;min=2048;}else if(a>=240&&a<=244){n=a&7;need=3;min=65536;}else throw Error('SCHEMA: codec UTF8');for(let j=0;j<need;j++){if(i>=b.length||(b[i]&192)!==128)throw Error('SCHEMA: codec UTF8 continuation');n=n*64+(b[i++]&63);}if(n<min||n>1114111||(n>=55296&&n<=57343))throw Error('SCHEMA: codec UTF8 scalar');s+=String.fromCodePoint(n);}return s;}
function base64Codes52A5(codes){const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',b=[];for(const n of codes){b.push(n>>8,n&255);}let out='';for(let i=0;i<b.length;i+=3){const a=b[i],c=b[i+1],d=b[i+2],v=(a<<16)|((c||0)<<8)|(d||0);out+=alphabet[(v>>>18)&63]+alphabet[(v>>>12)&63]+(c===undefined?'=':alphabet[(v>>>6)&63])+(d===undefined?'=':alphabet[v&63]);}return out;}
function decodeCodes52A5(s){if(!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(s))throw Error('SCHEMA: codec base64');const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',b=[];for(let i=0;i<s.length;i+=4){const v=(alphabet.indexOf(s[i])<<18)|(alphabet.indexOf(s[i+1])<<12)|(Math.max(0,alphabet.indexOf(s[i+2]))<<6)|Math.max(0,alphabet.indexOf(s[i+3]));b.push((v>>>16)&255);if(s[i+2]!=='=')b.push((v>>>8)&255);if(s[i+3]!=='=')b.push(v&255);}if(b.length%2)throw Error('SCHEMA: codec code length');const out=[];for(let i=0;i<b.length;i+=2)out.push(b[i]*256+b[i+1]);return out;}
function encodeSnapshot52A5(text){if(typeof Utilities.gzip==='function'&&typeof Utilities.base64Encode==='function'){const gz=Array.from(Utilities.gzip(Utilities.newBlob(text)).getBytes(),n=>n&255);if(gz.length>=18&&gz[0]===31&&gz[1]===139&&gz[2]===8&&gz[3]===0){gz[4]=gz[5]=gz[6]=gz[7]=0;const compressed='G5:'+Utilities.base64Encode(gz);return utf8Length52A5(compressed)<utf8Length52A5(text)+3?compressed:'J5:'+text;}}const bytes=utf8Bytes52A5(text),dict=new Map(),codes=[],initial=()=>{dict.clear();for(let i=0;i<256;i++)dict.set(String.fromCharCode(i),i);};initial();let next=257,w='';for(const byte of bytes){const c=String.fromCharCode(byte),wc=w+c;if(dict.has(wc)){w=wc;continue;}codes.push(dict.get(w));if(next<65536)dict.set(wc,next++);else{codes.push(256);initial();next=257;}w=c;}if(w)codes.push(dict.get(w));const compressed='L5:'+base64Codes52A5(codes);return utf8Length52A5(compressed)<bytes.length+3?compressed:'J5:'+text;}
function decodeSnapshot52A5(payload){if(payload.startsWith('G5:')){if(typeof Utilities.ungzip!=='function'||typeof Utilities.base64Decode!=='function')throw Error('SCHEMA: native gzip codec unavailable');const b=Utilities.base64Decode(payload.slice(3)),n=b.length;if(n<18)throw Error('SCHEMA: gzip length');const expected=(b[n-4]&255)+(b[n-3]&255)*256+(b[n-2]&255)*65536+(b[n-1]&255)*16777216;if(expected>786432)throw Error('SCHEMA: gzip decoded part limit');const text=Utilities.ungzip(Utilities.newBlob(b)).getDataAsString('UTF-8');if(utf8Length52A5(text)!==expected)throw Error('SCHEMA: gzip size mismatch');return text;}if(payload.startsWith('J5:'))return payload.slice(3);if(!payload.startsWith('L5:'))throw Error('SCHEMA: codec version');const codes=decodeCodes52A5(payload.slice(3)),dict=[],bytes=[];let next=257,w='';const initial=()=>{dict.length=257;for(let i=0;i<256;i++)dict[i]=String.fromCharCode(i);next=257;w='';};initial();for(const code of codes){if(code===256){initial();continue;}const entry=code<dict.length&&dict[code]!==undefined?dict[code]:code===next&&w?w+w[0]:null;if(entry===null)throw Error('SCHEMA: codec invalid dictionary');for(let j=0;j<entry.length;j++)bytes.push(entry.charCodeAt(j));if(w&&next<65536)dict[next++]=w+entry[0];w=entry;if(bytes.length>786432)throw Error('SCHEMA: codec decoded part limit');}return utf8Text52A5(bytes);}
function storageHeaders52A5(kind){return kind==='store'?['object','part','count','sha256','createdMs','payload']:['generation','state','createdMs','completedMs','manifest','metaJSON'];}
function storageSheet52A5(ss,kind,create=false){const name=kind==='store'?'_52A5_STORE':'_52A5_ROOTS';let s=ss.getSheetByName(name);if(!s&&create)s=ss.insertSheet(name);if(!s)return null;const header=storageHeaders52A5(kind);if(!s.getLastRow()){if(create)s.getRange(1,1,1,6).setValues([header]);return s;}if(JSON.stringify(s.getRange(1,1,1,6).getValues()[0])!==JSON.stringify(header))throw Error('SCHEMA: reserved snapshot '+kind+' header conflict');return s;}
function storageRows52A5(ss,kind){const s=ss.getSheetByName(kind==='store'?'_52A5_STORE':'_52A5_ROOTS');if(!s||!s.getLastRow())return [];const data=s.getRange(1,1,s.getLastRow(),6).getValues();if(JSON.stringify(data[0])!==JSON.stringify(storageHeaders52A5(kind)))throw Error('SCHEMA: reserved snapshot '+kind+' header conflict');return data.slice(1);}
function storageIndex52A5(rows){const map=new Map();for(let i=0;i<rows.length;i++){const r=rows[i];if(r.every(v=>v===''||v===null))continue;if(!r[0]||!Number.isSafeInteger(r[1])||r[1]<0||!Number.isSafeInteger(r[2])||r[2]<1||!Number.isFinite(r[4])||r[4]<=0||typeof r[5]!=='string'||!r[5].startsWith('P5:'))throw Error('SCHEMA: malformed snapshot storage row');if(!map.has(r[0]))map.set(r[0],[]);map.get(r[0]).push({row:i+2,value:r});}return map;}
function readObject52A5(index,key){const cache=index._verifiedText52A5||(index._verifiedText52A5=new Map());if(cache.has(key))return cache.get(key);const records=index.get(key);if(!records||!records.length)throw Error('SCHEMA: snapshot object missing '+key);const ordered=records.slice().sort((a,b)=>a.value[1]-b.value[1]),count=ordered[0].value[2],hash=ordered[0].value[3];if(count!==ordered.length||ordered.some((x,i)=>x.value[0]!==key||x.value[1]!==i||x.value[2]!==count||x.value[3]!==hash))throw Error('SCHEMA: snapshot chunk identity/count mismatch');const encoded=ordered.map(x=>x.value[5].slice(3)).join(''),text=decodeSnapshot52A5(encoded);if(digest(text)!==hash||key!=='O5:'+hash)throw Error('SCHEMA: snapshot checksum mismatch');cache.set(key,text);return text;}
function objectPlan52A5(text,objects,index){const key='O5:'+digest(text);if(!objects.has(key)){if(index&&index.has(key)){const records=index.get(key);if(records.length===records[0].value[2]){readObject52A5(index,key);const parts=records.slice().sort((a,b)=>a.value[1]-b.value[1]).map(x=>x.value[5]);objects.set(key,{key,hash:key.slice(3),parts,plainBytes:utf8Length52A5(text),encodedBytes:utf8Length52A5(parts.map(p=>p.slice(3)).join(''))});return key;}}const payload=encodeSnapshot52A5(text);if(decodeSnapshot52A5(payload)!==text)throw Error('SCHEMA: snapshot codec roundtrip');const parts=[];for(let i=0;i<payload.length;){let end=Math.min(payload.length,i+20000);if(end<payload.length&&/[\uD800-\uDBFF]/.test(payload[end-1]))end--;parts.push('P5:'+payload.slice(i,end));i=end;}objects.set(key,{key,hash:key.slice(3),parts,plainBytes:utf8Length52A5(text),encodedBytes:utf8Length52A5(payload)});}return key;}
function snapshotPlan52A5(data,index){const objects=new Map(),inputs={},sizes={};for(const [name]of snapshotSpec52A5()){const text=JSON.stringify(packGeneration52A4(data[name])),keys=[];for(let i=0;i<text.length;){let end=Math.min(text.length,i+131072);if(end<text.length&&/[\uD800-\uDBFF]/.test(text[end-1]))end--;keys.push(objectPlan52A5(text.slice(i,end),objects,index));i=end;}inputs[name]=keys;sizes[name]={bytes:utf8Length52A5(text),revision:digest(text)};}const manifest={version:5,inputs,sizes},text=JSON.stringify(manifest);if(utf8Length52A5(text)>131072)throw Error('CAPACITY52A5: manifest limit·no truncation');const manifestKey=objectPlan52A5(text,objects,index);return {manifest,manifestKey,objects,sourceBytes:Object.values(sizes).reduce((n,x)=>n+x.bytes,0),encodedBytes:[...objects.values()].reduce((n,x)=>n+x.encodedBytes,0),chunks:[...objects.values()].reduce((n,x)=>n+x.parts.length,0)};}
function dataFromManifest52A5(manifest,index){if(manifest.version!==5||!manifest.inputs||!manifest.sizes)throw Error('SCHEMA: snapshot manifest version');const data={};for(const [name]of snapshotSpec52A5()){const keys=manifest.inputs[name];if(!Array.isArray(keys)||!keys.length)throw Error('SCHEMA: snapshot input absent');const text=keys.map(k=>readObject52A5(index,k)).join('');if(digest(text)!==manifest.sizes[name].revision||utf8Length52A5(text)!==manifest.sizes[name].bytes)throw Error('SCHEMA: input revision mismatch');data[name]=unpackGeneration52A4(JSON.parse(text));}return data;}
function protectedStorage52A5(ss,roots,index){const p=PropertiesService.getScriptProperties(),pointer=JSON.parse(p.getProperty('DERIVED_GEN52A4')||'null'),now=Date.now();if(roots.some(r=>r[0]&&r[1]==='DONE'&&(!Number.isFinite(r[3])||r[3]<=0)))throw Error('SCHEMA: completed timestamp unknown·GC halted');const done=roots.filter(r=>r[0]&&r[1]==='DONE').sort((a,b)=>b[3]-a[3]||b[2]-a[2]),ids=new Set(done.filter((r,i)=>i<2||now-r[3]<3600000).map(r=>r[0]));if(pointer&&pointer.version===5)ids.add(pointer.id);const pins=JSON.parse(p.getProperty('GEN_PINS52A5')||'[]');if(!Array.isArray(pins)||pins.length>16||pins.some(x=>typeof x!=='string'))throw Error('SCHEMA: generation pins');for(const id of pins)ids.add(id);const keys=new Set(),seen=new Set();for(const r of roots){if(!r[0])continue;if(seen.has(r[0]))throw Error('SCHEMA: duplicate generation registry');seen.add(r[0]);if(!['BUILDING','ACTIVE','DONE','ABORTED','EXPIRED'].includes(r[1])||!Number.isFinite(r[2])||r[2]<=0)throw Error('SCHEMA: malformed generation registry');if(!ids.has(r[0]))continue;const m=JSON.parse(r[5]);if(m.id!==r[0]||m.rootKey!==r[4]||(pointer&&pointer.version===5&&pointer.id===r[0]&&JSON.stringify(m)!==JSON.stringify(pointer)))throw Error('SCHEMA: generation registry identity');const manifest=JSON.parse(readObject52A5(index,r[4]));dataFromManifest52A5(manifest,index);keys.add(r[4]);for(const list of Object.values(manifest.inputs))for(const k of list)keys.add(k);}if(pins.some(id=>!seen.has(id)))throw Error('SCHEMA: pinned generation missing');if(pointer&&pointer.version===5&&!seen.has(pointer.id))throw Error('SCHEMA: active generation registry missing');return {ids,keys,pointer};}
function gcPlan52A5(ss){const roots=storageRows52A5(ss,'roots'),rows=storageRows52A5(ss,'store'),index=storageIndex52A5(rows),protectedSet=protectedStorage52A5(ss,roots,index),now=Date.now(),victims=[];for(const [key,parts]of index)if(!protectedSet.keys.has(key)&&parts.every(x=>now-x.value[4]>=3600000))victims.push(...parts.map(x=>({row:x.row,key})));return {roots,rows,index,...protectedSet,victims};}
function collectSnapshotsLocked52A5(ss,deadline=Date.now()+10000){const p=PropertiesService.getScriptProperties(),start=Date.now(),plan=gcPlan52A5(ss),rs=ss.getSheetByName('_52A5_ROOTS'),store=ss.getSheetByName('_52A5_STORE');let cleared=0;p.setProperty('GEN_GC_STATE52A5',JSON.stringify({state:'RUNNING',at:nowKst(),candidates:plan.victims.length}));for(let i=0;i<plan.roots.length;i++){const r=plan.roots[i];if(!r[0]||plan.ids.has(r[0]))continue;if(Date.now()+3000>=deadline)break;if(r[1]!=='EXPIRED'&&r[1]!=='ABORTED'){r[1]=r[1]==='DONE'?'EXPIRED':'ABORTED';rs.getRange(i+2,1,1,6).setValues([r]);}if(Date.now()-r[2]>=3600000)rs.getRange(i+2,1,1,6).clearContent();}const victims=plan.victims.slice().sort((a,b)=>a.row-b.row);for(let i=0;i<victims.length;){if(Date.now()+3000>=deadline)break;const row=victims[i].row;let count=1;while(count<32&&victims[i+count]&&victims[i+count].row===row+count)count++;store.getRange(row,1,count,6).clearContent();cleared+=count;i+=count;}const legacy=collectLegacySnapshots52A5(ss,deadline),remaining=plan.victims.length-cleared+legacy.remaining;p.setProperty('GEN_GC_STATE52A5',JSON.stringify({state:remaining?'PARTIAL':'COMPLETE',at:nowKst(),clearedRows:cleared,remaining,legacyClearedRows:legacy.cleared,elapsedMs:Date.now()-start}));return {cleared,remaining};}
function freeStorageRow52A5(rows){const at=rows.findIndex(r=>r.every(x=>x===''||x===null));return at>=0?at+2:rows.length+2;}
function rowBytes52A5(row){return utf8Length52A5(JSON.stringify(row));}
function totalStorageBytes52A5(rows,roots){return utf8Length52A5(JSON.stringify([storageHeaders52A5('store'),...rows]))+utf8Length52A5(JSON.stringify([storageHeaders52A5('roots'),...roots]));}
function beginGeneration52A5(ss,deadline=Date.now()+45000){const p=PropertiesService.getScriptProperties();if(p.getProperty('DERIVED_GEN52A4'))throw Error('SCHEMA: generation already active');const startedMs=Date.now(),data=generationInputs52A5(ss);for(const [name,start]of [['공고원장',4],['공고상세',1],['수집원본',1],['발송대기',1]])unique52A((data[name]||[]).slice(start),name);const readDoneMs=Date.now(),existing=gcPlan52A5(ss),plan=snapshotPlan52A5(data,existing.index),codecDoneMs=Date.now(),rows=existing.rows,roots=existing.roots,now=Date.now(),missing=[];let reused=0;
 for(const obj of plan.objects.values()){const parts=existing.index.get(obj.key)||[],byPart=new Map();for(const entry of parts){const r=entry.value;if(byPart.has(r[1])||r[2]!==obj.parts.length||r[3]!==obj.hash||r[5]!==obj.parts[r[1]])throw Error('SCHEMA: staged snapshot conflict');byPart.set(r[1],true);}for(let i=0;i<obj.parts.length;i++)if(!byPart.has(i))missing.push([obj.key,i,obj.parts.length,obj.hash,now,obj.parts[i]]);else reused++;}
 const sequence=Number(p.getProperty('DERIVED_GEN_SEQ52A4')||0)+1;if(!Number.isSafeInteger(sequence))throw Error('CAPACITY52A5: sequence limit');const id='G5:'+sequence+':'+now,meta={version:5,id,rootKey:plan.manifestKey,startedMs,startedAt:Utilities.formatDate(new Date(startedMs),'Asia/Seoul','yyyy-MM-dd HH:mm:ss'),day:Utilities.formatDate(new Date(startedMs),'Asia/Seoul','yyyy-MM-dd'),baselineAt:p.getProperty('V3_STARTED')||'',sourceBytes:plan.sourceBytes,encodedBytes:plan.encodedBytes,chunks:plan.chunks,reusedChunks:reused},root=[id,'BUILDING',now,0,plan.manifestKey,JSON.stringify(meta)];
 const predictedRows=rows.map(r=>r.slice()),predictedRoots=roots.map(r=>r.slice());for(const r of missing){const at=freeStorageRow52A5(predictedRows);while(predictedRows.length<at-1)predictedRows.push(Array(6).fill(''));predictedRows[at-2]=r;}const predictedRootAt=freeStorageRow52A5(predictedRoots);while(predictedRoots.length<predictedRootAt-1)predictedRoots.push(Array(6).fill(''));predictedRoots[predictedRootAt-2]=root;const after=totalStorageBytes52A5(predictedRows,predictedRoots)+4096;if(after>5242880)throw Error('CAPACITY52A5: total technical store 5MiB·protected/grace blocks retained·no source truncation');if(Date.now()+5000>=deadline)throw Error('YIELD52A5: capture/codec admission');const writeStartedMs=Date.now(),rs=storageSheet52A5(ss,'roots',true),store=storageSheet52A5(ss,'store',true),rootAt=freeStorageRow52A5(roots);ensureRowsV4(rs,rootAt);p.setProperty('DERIVED_GEN_SEQ52A4',String(sequence));rs.getRange(rootAt,1,1,6).setValues([root]);
 const writes=[];for(const r of missing){const at=freeStorageRow52A5(rows);while(rows.length<at-1)rows.push(Array(6).fill(''));rows[at-2]=r;const last=writes[writes.length-1];if(last&&last.at+last.values.length===at&&last.values.length<32)last.values.push(r);else writes.push({at,values:[r]});}for(const batch of writes){if(Date.now()+3000>=deadline)throw Error('YIELD52A5: staged snapshot·retry verifies/reuses chunks');ensureRowsV4(store,batch.at+batch.values.length-1);store.getRange(batch.at,1,batch.values.length,6).setValues(batch.values);}SpreadsheetApp.flush();const index=storageIndex52A5(storageRows52A5(ss,'store'));dataFromManifest52A5(JSON.parse(readObject52A5(index,plan.manifestKey)),index);if(Date.now()+1000>=deadline)throw Error('YIELD52A5: publication admission');root[1]='ACTIVE';rs.getRange(rootAt,1,1,6).setValues([root]);SpreadsheetApp.flush();p.setProperty('DERIVED_GEN52A4',JSON.stringify(meta));p.deleteProperty('DECISION_CURSOR52A');p.setProperty('GEN_STORAGE52A5',JSON.stringify({sourceBytes:plan.sourceBytes,encodedBytes:plan.encodedBytes,chunks:plan.chunks,reusedChunks:reused,totalPlannedBytes:after,captureElapsedMs:Date.now()-startedMs,inputReadMs:readDoneMs-startedMs,codecMs:codecDoneMs-readDoneMs,storageWriteVerifyMs:Date.now()-writeStartedMs,payloadRowsWritten:missing.length,payloadWriteBatches:writes.length,at:nowKst()}));return {meta,data,fresh:true};}
function loadGeneration52A5(ss){const p=PropertiesService.getScriptProperties(),pointer=p.getProperty('DERIVED_GEN52A4');if(!pointer)return null;const meta=JSON.parse(pointer);if(meta.version!==5)throw Error('SCHEMA: expected v5 pointer');const roots=storageRows52A5(ss,'roots'),matches=roots.filter(r=>r[0]===meta.id);if(matches.length!==1||!['ACTIVE','DONE'].includes(matches[0][1])||matches[0][4]!==meta.rootKey||matches[0][5]!==pointer)throw Error('SCHEMA: active root identity');const index=storageIndex52A5(storageRows52A5(ss,'store')),manifest=JSON.parse(readObject52A5(index,meta.rootKey));return {meta,data:dataFromManifest52A5(manifest,index)};}
function completeGeneration52A5(ss,meta){const s=storageSheet52A5(ss,'roots'),rows=storageRows52A5(ss,'roots'),matches=rows.map((r,i)=>({r,i})).filter(x=>x.r[0]===meta.id);if(matches.length!==1)throw Error('SCHEMA: completed generation registry');const {r,i}=matches[0];r[1]='DONE';r[3]=r[3]||Date.now();s.getRange(i+2,1,1,6).setValues([r]);SpreadsheetApp.flush();}
function inspectSnapshotCapacity52A5(){const ss=SpreadsheetApp.openById(SPREADSHEET_ID),start=Date.now(),data=generationInputs52A5(ss),readMs=Date.now()-start,plan=snapshotPlan52A5(data),gc=gcPlan52A5(ss),stored=totalStorageBytes52A5(gc.rows,gc.roots);return {at:nowKst(),writes:0,sends:0,sourceBytes:plan.sourceBytes,encodedBytes:plan.encodedBytes,objects:plan.objects.size,chunks:plan.chunks,currentStoreBytes:stored,storeLimitBytes:5242880,protectedGenerations:[...gc.ids],gcEligibleRows:gc.victims.length,inputRevisions:plan.manifest.sizes,readMs,totalReadCodecMs:Date.now()-start,measurement:'Apps Script getValues/Date packing/UTF8, selected consumer columns; no snapshot writes'};}
function inspectSnapshotState52A5(){const p=PropertiesService.getScriptProperties();return {writes:0,sends:0,last:p.getProperty('GEN_RUN52A5'),storage:p.getProperty('GEN_STORAGE52A5'),gc:p.getProperty('GEN_GC_STATE52A5'),legacyDone:p.getProperty('DERIVED_GENERATION_DONE52A4'),liveConsistent:p.getProperty('DERIVED_LIVE_OK52A4'),pending:Number(p.getProperty('DERIVED_PENDING52A4')||0)};}

function collectSnapshots52A5(){const lock=LockService.getScriptLock();if(!lock.tryLock(1000))return {state:'LOCK_WAIT',writes:0};try{return collectSnapshotsLocked52A5(SpreadsheetApp.openById(SPREADSHEET_ID));}finally{lock.releaseLock();}}
function collectLegacySnapshots52A5(ss,deadline){const pointer=JSON.parse(PropertiesService.getScriptProperties().getProperty('DERIVED_GEN52A4')||'null');if(pointer&&pointer.version!==5)return {cleared:0,remaining:0,protectedLegacyActive:true};const s=ss.getSheetByName('_52A4_GENERATIONS');if(!s||!s.getLastRow())return {cleared:0,remaining:0};const data=s.getRange(1,1,s.getLastRow(),5).getValues();if(JSON.stringify(data[0])!==JSON.stringify(['generation','chunk','count','sha256','payload']))throw Error('SCHEMA: reserved legacy header conflict');const groups=new Map();for(let i=1;i<data.length;i++){const r=data[i];if(r.every(v=>v===''||v===null))continue;const m=String(r[0]).match(/^G:\d+:(\d+):[a-f0-9]+$/);if(!m||!Number.isFinite(Number(m[1])))throw Error('SCHEMA: legacy orphan age unknown·retain');if(!groups.has(r[0]))groups.set(r[0],{id:r[0],at:Number(m[1]),rows:[]});groups.get(r[0]).rows.push(i+1);}const pins=JSON.parse(PropertiesService.getScriptProperties().getProperty('GEN_PINS_LEGACY52A5')||'[]');if(!Array.isArray(pins)||pins.length>16||pins.some(id=>!groups.has(id)))throw Error('SCHEMA: legacy generation pins');const sorted=[...groups.values()].sort((a,b)=>b.at-a.at),victims=sorted.filter((g,i)=>i>=2&&!pins.includes(g.id)&&Date.now()-g.at>=3600000).flatMap(g=>g.rows).sort((a,b)=>a-b);let cleared=0;for(let i=0;i<victims.length;){if(Date.now()+3000>=deadline)break;const row=victims[i];let count=1;while(count<32&&victims[i+count]===row+count)count++;s.getRange(row,1,count,5).clearContent();cleared+=count;i+=count;}return {cleared,remaining:victims.length-cleared,retainedGroups:Math.min(2,sorted.length)};}
function measureLegacySnapshotBytes52A5(){const ss=SpreadsheetApp.openById(SPREADSHEET_ID),start=Date.now(),data=generationInputs52A4(ss),text=JSON.stringify(packGeneration52A4(data));return {writes:0,sends:0,at:nowKst(),legacyFullSnapshotBytes:utf8Length52A5(text),elapsedMs:Date.now()-start,expression:'UTF8(JSON.stringify(packGeneration52A4(generationInputs52A4(ss))))',source:'getValues includes Date and rectangular cells; not connector display values'};}

function utf8Length52A5(text){return Utilities.newBlob(text).getBytes().length;}

function generationContext52A5(ss,gen,captured){
 const live=captured||generationInputs52A5(ss),frozenHash=generationHashMap52A4(gen.data),liveHash=generationHashMap52A4(live),dirty=new Set();
 for(const [id,h]of frozenHash)if(liveHash.get(id)!==h)dirty.add(id);for(const id of liveHash.keys())if(!frozenHash.has(id))dirty.add(id);
 const events=new Map((live['발송대기']||[]).slice(1).map(r=>[r[0],r])),frozenEvents=new Map((gen.data['발송대기']||[]).slice(1).map(r=>[r[0],r]));
 let changedEvents=0;for(const [key,e]of frozenEvents){const x=events.get(key);if(!x||JSON.stringify(packGeneration52A4(x.slice(0,7)))!==JSON.stringify(packGeneration52A4(e.slice(0,7))))changedEvents++;}for(const key of events.keys())if(!frozenEvents.has(key))changedEvents++;
 const auxChanged=['정정이력','교차게시검토','SH후속안내','GH후속안내','발견구분'].filter(n=>digest(JSON.stringify(packGeneration52A4(live[n])))!==digest(JSON.stringify(packGeneration52A4(gen.data[n]))));const baselineChanged=(PropertiesService.getScriptProperties().getProperty('V3_STARTED')||'')!==(gen.meta.baselineAt||'');return {checkedAt:nowKst(),auxChanged,baselineChanged,live,frozenHash,liveHash,dirty,events,frozenEvents,pending:dirty.size+changedEvents+auxChanged.length+(baselineChanged?1:0)+(gen.meta.day!==todayKst()?1:0)};
}
function runDerivedFinite52A5(ss){
 const p=PropertiesService.getScriptProperties(),oldPointer=JSON.parse(p.getProperty('DERIVED_GEN52A4')||'null');if(oldPointer&&oldPointer.version!==5)return runDerivedFinite52A4(ss);const phase=Number(p.getProperty('DERIVED_STEP42A')||0)%4,aux=Number(p.getProperty('DERIVED_AUX42A')||0)%4,label=['공고판정','지역정책','사용자현황판','유지관리'][phase],slot=50000,start=Date.now();
 if(start+slot+15000>V4_END){p.setProperty('GEN_RUN52A5',JSON.stringify({state:'TIME_WAIT',at:nowKst(),phase}));p.setProperty('DERIVED_WAIT42A','세대 실행시간 대기');return false;}
 if(!budgetStatus42(p,'파생',start,slot).canRun){p.setProperty('GEN_RUN52A5',JSON.stringify({state:'BUDGET_WAIT',at:nowKst(),phase}));p.setProperty('DERIVED_WAIT42A','세대 파생 예산 대기·커서 보존');return false;}
 let gen,ctx,lag;let result;
 try{result=workBudget42(p,'파생',()=>{try{
  p.setProperty('GEN_RUN52A5',JSON.stringify({state:'RUNNING',at:nowKst(),phase}));if(!p.getProperty('GEN_GC_AT52A5')||Date.now()-Number(p.getProperty('GEN_GC_AT52A5'))>=3600000){const gc=collectSnapshotsLocked52A5(ss,Math.min(start+10000,V4_END-20000));p.setProperty('GEN_GC_AT52A5',String(gc.remaining?Date.now()-3600000:Date.now()));}gen=loadGeneration52A5(ss);if(!gen){if(phase!==0){p.setProperty('DERIVED_STEP42A','0');return false;}gen=beginGeneration52A5(ss,Math.min(V4_END-20000,start+45000));}
  ctx=generationContext52A5(ss,gen,gen.fresh?gen.data:null);gen.fresh=false;p.setProperty('DERIVED_PENDING52A4',String(ctx.pending));const finish=()=>{lag=phase===3?generationContext52A5(ss,gen):{...ctx,pending:Math.max(ctx.pending,ctx.dirty.size)};return true;};const until=Math.min(V4_END-20000,start+45000),view=finiteView52A4(ss,gen,ctx,until,phase===2);
  if(phase===0){for(let i=0;i<100&&Date.now()+5000<until;i++)if(decisionSliceLegacy52A3(view,until,gen.meta.day))return finish();return false;}
  if(phase===1){refreshRegionV4(view);return finish();}
  if(phase===2){refreshUserDashboardV4(view);return finish();}
  const jobs=[reconcileQualityV2,reconcileExceptionsV3,prepareReminders35,s=>refreshMonitor(s,true)];jobs[aux](cachedDerivedView42A(ss));finish();completeGeneration52A5(ss,gen.meta);return true;
 }catch(e){if(/^YIELD52A[45]:/.test(String(e.message||e)))return false;throw e;}},slot);}catch(e){p.setProperty('DERIVED_WAIT42A','세대 실패·이전 정상시각/커서 보존');p.setProperty('GEN_RUN52A5',JSON.stringify({state:String(e.message||e).startsWith('CAPACITY52A5:')?'CAPACITY_BLOCKED':'FAILED',at:nowKst(),phase,elapsedMs:Date.now()-start,error:safeError(e)}));throw e;}
 p.setProperty('GEN_RUN52A5',JSON.stringify({state:result.ran&&result.value?'PHASE_COMPLETE':'PARTIAL',at:nowKst(),phase,elapsedMs:Date.now()-start}));p.setProperty('DERIVED_COST42A_'+label,String(Date.now()-start));if(!result.ran||!result.value){p.setProperty('DERIVED_WAIT42A','고정 세대 부분진행·다음 예약 재개');return false;}
 const stamp=nowKst();p.setProperty('DERIVED_INPUT_VALIDATED_AT52A4',lag.checkedAt);p.setProperty('DERIVED_SNAPSHOT_OK52A4_'+label,stamp);p.setProperty('DERIVED_SNAPSHOT_AT52A4',gen.meta.startedAt);p.setProperty('DERIVED_PENDING52A4',String(lag.pending));
 if(!lag.pending)p.setProperty('DERIVED_OK42A_'+label,stamp);p.setProperty('DERIVED_WAIT42A',lag.pending?'최신 입력 대기 '+lag.pending+' · 다음 세대 처리':'');p.setProperty('DERIVED_STEP42A',String((phase+1)%4));
 if(phase===2&&!lag.pending)p.setProperty('DERIVED_AT42',String(Date.now()));
 if(phase===3){p.setProperty('GEN_RUN52A5',JSON.stringify({state:'GENERATION_COMPLETE',at:nowKst(),phase,pending:lag.pending,elapsedSinceCaptureMs:Date.now()-gen.meta.startedMs}));p.setProperty('DERIVED_AUX42A',String((aux+1)%4));p.setProperty('DERIVED_GENERATION_DONE52A4',gen.meta.id);p.setProperty('DERIVED_GENERATION_DELAY_MS52A4',String(Date.now()-gen.meta.startedMs));if(!lag.pending)p.setProperty('DERIVED_LIVE_OK52A4',stamp);p.deleteProperty('DERIVED_GEN52A4');p.deleteProperty('DECISION_CURSOR52A');}
 return true;
}

function reviewWatchSafe52A6(ss){const p=PropertiesService.getScriptProperties();if(Date.now()+20000>=V4_END){p.setProperty('REVIEW_WATCH_WAIT52A6','실행시간 부족·기존 검토상태 보존');return false;}try{refreshReviewWatch52A4(ss);p.deleteProperty('REVIEW_WATCH_ERROR52A6');p.deleteProperty('REVIEW_WATCH_WAIT52A6');return true;}catch(e){const info={at:nowKst(),state:'FAILED',reason:safeError(e),coreContinues:true};p.setProperty('REVIEW_WATCH_ERROR52A6',JSON.stringify(info));console.log('REVIEW_WATCH_FAILED52A6 '+JSON.stringify(info));return false;}}
function formatDashboardLean52A6(s){s.setFrozenRows(2);s.getRange(1,1,106,10).setWrap(true).setFontSize(10);s.getRange(1,1,2,10).setBackground('#edf4ef');s.setColumnWidth(4,330);s.setColumnWidth(9,210);}