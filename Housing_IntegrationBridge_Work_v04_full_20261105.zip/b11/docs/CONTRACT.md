# 발송 계약·장애 처리·남은 통합 조건

## 정책과 식별

서울·경기 주거용 새 유효 모집은 중요도에 관계없이 NEW다. 일반45㎡·오피스텔·자격 미확인이란 이유로 막지 않는다. ★는 표시·순서이며 지역 확정/주거용/실모집과 분리한다. D3은 공식 근거 있는 ★만, D1은 모든 유효 접수창이다. 일반 D1 제외였던 B17은 폐기하고 N07을 따른다. 09:00 KST 기본 일정, 당일 늦은 실행 가능, 지난 날짜 소급 없음. 하루짜리는 NEW 즉시. 23:00 이상07:00 미만 실제 요청 시각에 무음=true이며 다음 날까지 미루지 않는다. 개인 수신처 별칭 하나만 허용하며 토큰·실제 chat_id는 이 코드에서 받지 않는다.

멱등키는 SHA256([telegram, recipientScope, recruitmentId, eventType, [roundId, semanticVersion], scheduleWindow])다. NEW semanticVersion은 opportunityVersion, CHANGE는 공식 의미변경 version, reminder는 접수창의 일정/채널/대상/공급unit hash다. modelVersion은 파서/읽기모델 버전이고 NEW 식별에 쓰지 않는다. 기회 version은 파서 개선·중요도 변경으로 증가시키면 안 된다. 새 차수는 roundId/기회 증거로 구분한다. 다른 기관 ID라도 공식 동일성이 확정돼 같은 canonical 모집·차수인 경우에만 이벤트와 출처를 합친다.

기준선은 mock 전용 명시 승인값(goLiveAt, 소스별 증분 시작, 이미 알려진 모집/정정/이벤트 키, 개인별칭)을 hash로 고정한다. 변경 거부, 동일값 재실행만 허용한다. 과거 Y·1,244과거 표본·HUG archive·신규 어댑터 초기 백필은 신규 푸시0이다. 기준선 이전 모집의 **기준선 이후 새로 관측된 공식 의미 정정**은 별개 CHANGE로 가능하다. PDF hash·파서 버전만 변경된 것은 검토 큐다. 새 소스의 향후 추가·실운영 기준선 전환은 별도 승인 마이그레이션이 필요하다. mock ledger를 운영 ledger로 재사용하면 안 된다.

## canonical 입력 경계

fixture의 전체 스키마를 제공한다. HOUSING_CANONICAL_V1, 확인된 모집/동일성/주거/공급지 증거와 https 공식 URL, sourceNoticeIds, primarySourceId, roundId/opportunityVersion/modelVersion이 필요하다. 상세 일정은 timezone Asia/Seoul, 검증된 일자·시각, 접수창id/채널/대상/unitIds로 분리한다. ★는 확인된 서울·경기 unit의 아파트 전용59㎡ 이상 또는 target 근거 있는 관심프로그램 증거를 요구한다. 타지역 최대면적을 섞지 않는다.

SH/GH 지역 UNKNOWN/PARTIAL/CONFLICT는 reviews에 남으며 NEW를 보내지 않는다. 혼합 결과+다음순위 접수는 upstream REVIEW를 유지하고 공식 접수 기회를 확인한 뒤 새 round로 전송한다. 결과/상가/토지/매입/단순서류안내 유형은 신규·마감 알림 제외다. 이 엔진은 원문을 새로 파싱하거나 자격충족을 단정하지 않는다.

**입력의 CONFIRMED는 승인된 상위 판정기의 계약이다.** URL 형태 검사만으로 실제 공식 내용·도메인 진위를 실증한 것이 아니다. A6 시트 → canonical 공급unit·round 매핑은 아직 연결하지 않았다. `발송대기!I=Y`를 그대로 넘기는 구현이 아니다. Work 원시 `notificationDecision=DEFER_TO_INTEGRATOR`, `deliveryCapability=NONE` 또는 null 모집키를 그대로 넘기면 막는다. Work 수집기·5.3~5.4 구현은 이번 브랜치에 없다.

## 영속 상태와 장애

PENDING → CLAIMED(120초 lease) → REQUEST_STARTED(외부호출 이전 durable 마커) → DELIVERED / RETRY_WAIT / PERMANENT_REVIEW / UNKNOWN_DELIVERY.

락 안에서 선점·저장하고 최신 모델과 소유권을 다시 확인한다. 메시지는 요청 직전 최신 입력으로 다시 만든다. 취소·구일정·모집유형 변경이면 SUPPRESSED, 긴 링크를 자르지 못하면 HOLD다. D1은8항목/3,500 UTF-16 units까지 묶고 ★먼저다. 성공은 mock ok:true + positive message_id/server date를 기록한다. 새 기간/다른 차수를 같은 알림으로 과잉 억제하지 않는다. 이미 성공한 과거 이벤트/알림은 삭제하지 않는다.

- 마커 이전 CLAIM만 만료: 외부요청이 없으므로 PENDING 복귀 가능.
- 마커 이후 중단·타임아웃·깨진 응답·성공 후 기록 실패: UNKNOWN 격리. 요청하지 못한 경우까지 보수적으로 보류할 수 있다. 자동 재전송 없음. 같은 날 NEW의 UNKNOWN을 D1으로 우회하거나 같은 일정의 채널/버전만 바꿔 재전송하는 것도 막는다.
- 명확한 mock API ok:false 429: Retry-After와 backoff 중 긴 쪽. 명확한 ok:false 500/502/503/504: 60/120/...초 backoff, 최대3시도. 원문 응답조차 없는 HTTP 오류를 알려진 거절로 가정하지 않는다.
- 400/401/403 등: PERMANENT_REVIEW. API가 수락한 사실과 사람이 읽은 사실은 다르다.
- 저장 실패: 호출 전이면 송신하지 않음. 호출 뒤면 저장 성공 여부가 불명확할 수 있으므로 재개 시 원장을 먼저 확인하고 REQUEST_STARTED 만료를 UNKNOWN으로 격리.

UNKNOWN을 풀거나 이미 성공한 키를 초기화하는 자동/우회 API는 제공하지 않는다. 관리자가 증거를 확인하는 별도 조정 워크플로·승인·감사기록 설계가 실운영 전 필요하다. 전송 보장의 한계(exactly-once 불가)를 신규 키 발급으로 숨기지 않는다.

## 수락 범위

N01~N18의 sender 계약은 합성 회귀로 확인했다. N03/N04/B07/B09는 상위 canonical 증거를 받아 결정하는 경계 테스트이며 실제 공식 원문 판정·소스 동일성 검증 완료가 아니다. B19/B22는 제어된 동시 interleaving·쓰기 실패/중단 주입이며 실제 두 Google 실행/강제종료 검증은 남는다. B24 실제 트리거 종료/복구, B26 실제 개인 테스트1건은 미실행이다. SH 검토 SLA 실제 경고/후속 확인, GH 공식 total·고정공지, 22경로 실수집, Apps Script 저장/시간/복구 게이트는 여전히 미해결이다. 실제 수신 토큰/HTTP adapter/트리거는 이 패키지에 없다.
