# 5.2-B v1.1 실제 발송 엔진 — MOCK 전송 한정

**운영 NO-GO.** A.local.6 원본 ZIP은 `../baseline/local6/full.zip`이다. 별도 제공하는 `Housing_5.2A_local6_postprocessing_fix_full.zip`과 같은 바이트다. 이 패키지는 A를 수정하지 않은 별도 로컬 브랜치 `feature/5.2b-mock-delivery`의 B 구현이다. Google 복제본 생성·실행·운영 접근·토큰 조회·실제 Telegram 요청·트리거 생성·원격 push를 하지 않았다.

## 다운로드 후 실행

ZIP 전체를 풀고 최상위 디렉터리에서 실행한다. Node.js 24.19.0 사용, npm 설치·계정·네트워크·토큰 불필요.

```sh
sha256sum -c SHA256SUMS.txt
node b11/tools/build.cjs
node b11/tests/run.cjs
node b11/tools/mock-send.cjs b11/fixtures/demo.json /tmp/b11-demo-unique
node b11/tools/mock-send.cjs b11/fixtures/demo.json /tmp/b11-demo-unique
node b11/tools/benchmark.cjs
```

새 디렉터리에서 첫 mock 실행은 NEW 1회, 같은 원장을 사용하는 두 번째 실행은 0회다. 출력의 `DELIVERED`는 MOCK API 수락을 뜻한다. 실제 Telegram 발송·사용자 수신 증거가 아니다. 테스트 재실행은 reports를 갱신하므로 원본 ZIP을 보관한다.

A 재실행은 `baseline/local6/full.zip`을 별도 디렉터리에 풀고 그 안에서 `node tests/all-local6.cjs`를 실행한다. B 결과와 A 결과를 서로 대체하지 않는다.

## 실제 구현 파일

- `src/DeliveryCore.js`: 이벤트 생성, 승인 mock 기준선 고정, 전송 직전 재검증, 영속 선점·요청 마커·성공·재시도·UNKNOWN 격리, 중복 억제와 메시지 생성.
- `src/FileStore.cjs`: 파일 잠금, SHA-256 검사, fsync/atomic rename, 용량 초과 시 기존 원장 보존. 프로세스 간 재시작 테스트에 사용.
- `src/AppsScriptStore.gs`: 승인된 정확한 복제 프로젝트/시트만 허용하는 append journal. 변경분 청크를 먼저 쓰고 COMMIT을 마지막에 기록한다. 중단된 미커밋 꼬리는 무시하고 공개된 청크 손상은 중단한다. 실제 Google에서는 미실행.
- `src/MockEntry.gs`: 승인된 복제본의 단일 mock 실행 진입점. 자동 실행 없음.
- `scripts/HousingB11_Mock.gs.txt`: 위 Apps Script 실행 코드 전체. 승인 후 별도 B 테스트 프로젝트에 **이 한 파일만** 붙여넣는다. A의 Code.gs에 섞지 않는다. `scripts/parts/`의 개별 전체 TXT는 확인용이다. Node 전용 FileStore는 Apps Script에 붙여넣지 않는다.
- `tests/`, `fixtures/`: 실행 가능한 테스트와 **합성** canonical 입력. 실제 SH:311200 원문·현재 시트·공식 GH total을 검증한 fixture가 아니다.
- `reports/code-changes.diff`: A 참조 브랜치 대비 B 소스·실행 스크립트·테스트·fixtures·도구의 전체 추가 diff. A 수정은 0바이트다.

## 이번 실행 결과

B 로컬 133/133 통과. A6 원본을 별도 디렉터리에 풀어 기존403 + A6 신규17 = 420/420를 다시 실행했다. `reports/results.json`, `tests.log`, `a6-recheck/`에 새 실행 결과가 있다. 이 숫자는 Google/실채팅 수락 개수가 아니다.

파일 원장을 쓰는 2,000모집(4,000 이벤트) 합성 부하에서 수집 반영 약616ms, 1회 전송 절차 약325ms, 원장 약4.04MB였다. 정확한 값·명령은 `reports/benchmark.{json,log}`, `tools/benchmark.cjs`에 있다. Google RPC·quota·메모리·동시 트리거 성능으로 환산할 수 없다. FileStore는 mock용 8MiB 제한을 가진다. Apps Script는 전체 상태 복사가 아닌 변경 journal이며 한 transaction은1MiB까지다. 입력은100행씩 커밋한다. 총 journal의 장기 replay·보관/압축 설계는 운영 연결 전 추가 검증 항목이다.

정책·통합 한계는 `docs/CONTRACT.md`, 승인 후 최소 실증과 복구는 `docs/CLONE_AND_RECOVERY.md`를 따른다. 사용자에게 승인 요청을 대신하는 자동 실행 파일은 없다.
