'use strict';
// node b11/tools/mock-send.cjs b11/fixtures/demo.json /tmp/b11-demo
const fs=require('fs'),path=require('path'),crypto=require('crypto'),B=require('../src/DeliveryCore.js'),{FileStore}=require('../src/FileStore.cjs');
const [input,dir]=process.argv.slice(2);if(!input||!dir)throw Error('Usage: node mock-send.cjs fixture.json OUTPUT_DIRECTORY');
const fixture=JSON.parse(fs.readFileSync(input,'utf8'));if(fixture.mode!=='MOCK_ONLY'||fixture.synthetic!==true)throw Error('EXPLICIT_SYNTHETIC_MOCK_REQUIRED');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex'),adapter=B.createMockAdapter(fixture.mockResponses),store=new FileStore(path.join(dir,'mock-ledger.json'));
const sender=B.engine({mode:'MOCK_ONLY',recipient:{kind:'PERSONAL',count:1,scope:'SELF'},hash,store,models:new B.ModelRepository(fixture.rows),adapter,clock:()=>Date.parse(fixture.clock)});
sender.freezeBaseline(fixture.baseline);const ingest=sender.ingest(fixture.rows),outcomes=[];
for(let i=0;i<20;i++){const out=sender.dispatchOne();outcomes.push(out);if(out.state==='IDLE')break;}
const result={mode:'MOCK_ONLY',ingest,outcomes,mockRequests:adapter.calls(),realGoogleCalls:0,realTelegramCalls:0};
fs.writeFileSync(path.join(dir,'mock-run.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({mode:result.mode,added:ingest.added,mockRequests:result.mockRequests.length,realTelegramCalls:0}));
