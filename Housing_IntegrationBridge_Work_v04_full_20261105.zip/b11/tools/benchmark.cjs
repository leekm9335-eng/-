'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto'),B=require('../src/DeliveryCore.js'),F=require('../fixtures/canonical.cjs'),{FileStore}=require('../src/FileStore.cjs');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'b11-bench-')),hash=x=>crypto.createHash('sha256').update(x).digest('hex'),results=[];
for(const count of [100,500,2000]){
 const file=path.join(dir,count+'.json'),rows=Array.from({length:count},(_,i)=>F.row({recruitmentId:'R'+i})),adapter=B.createMockAdapter();
 const sender=B.engine({mode:'MOCK_ONLY',recipient:{kind:'PERSONAL',count:1,scope:'SELF'},hash,store:new FileStore(file),models:new B.ModelRepository(rows),adapter,clock:()=>Date.parse('2026-11-04T01:00:00Z')});sender.freezeBaseline(F.baseline());
 let t=performance.now(),error=null;try{sender.ingest(rows);}catch(e){error=e.message;}
 const ingestMs=performance.now()-t,ingestBytes=fs.statSync(file).size;let dispatchMs=null,state='NOT_ATTEMPTED';
 if(!error){t=performance.now();state=sender.dispatchOne().state;dispatchMs=performance.now()-t;}
 const result={rows:count,ingestMs,ingestBytes,dispatchMs,state,error,mockRequests:adapter.calls().length,bytes:fs.statSync(file).size};results.push(result);console.log(JSON.stringify(result));
}
fs.writeFileSync(path.join(__dirname,'../reports/benchmark.json'),JSON.stringify({environment:'Node '+process.version+'; local filesystem; NOT Google latency/quota',clock:'fixed synthetic',maxFileBytes:8388608,results,realGoogleCalls:0,realTelegramCalls:0},null,2)+'\n');fs.rmSync(dir,{recursive:true,force:true});
