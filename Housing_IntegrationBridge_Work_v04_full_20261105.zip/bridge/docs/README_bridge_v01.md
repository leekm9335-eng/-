# A6 → Work v0.3 → B mock IntegrationBridge

**실제 구현·실행 결과이며, 운영 배포는 NO-GO다.** 운영42.A3/시트/속성/트리거/HUG/비밀설정/실제 Telegram 요청을 변경하거나 실행하지 않았다. A6와 B 실행 소스는 기존 승인 후보 바이트 그대로 사용한다. 중앙 저장소는 로컬 JSON이고 실제 Google Sheets가 아니다.

## 한 명령으로 종단간 실행

ZIP **전체**를 풀고 최상위 폴더에서 실행한다. Node.js24.19.0으로 검증했으며 npm·인증·인터넷 연결이 필요 없다.

```sh
node bridge/tools/e2e.cjs
```

실행 결과와 중앙/발송 원장 경로가 마지막 줄에 나온다. 같은 원장으로 프로세스 재시작까지 확인하려면 출력된 경로를 사용한다.

```sh
node bridge/tools/e2e.cjs --out /tmp/my-housing-e2e
node bridge/tools/e2e.cjs --out /tmp/my-housing-e2e
```

첫 실행: 일반 NEW1 + 다음 날 D1 1, 중요 NEW1 + 다음 날 D3 1, 결과불명 모의 요청1. 동일 입력 즉시 재실행은0, 두 번째 프로세스의 전체 추가 요청도0이다. 일정 충돌·지역 미확인·초기 백필·단순 결과는 각각0이다. 일반 D3은 없다. `DELIVERED`는 **mock 응답 수락**이며 실제 Telegram 수신 확인이 아니다.

`bridge/reports/e2e-first/`와 `e2e-second/`에 실제 두 Node 프로세스의 결과 JSON·stdout 및 첫 실행의 중앙/발송 상태와 원본 입력을 보존했다. 시계는 합성2026-11-04→11-05다. 실제11-05 자동 실행 실증이 아니다. 신규 성공 사례는 명백히 SYNTHETIC인 fixture다. 별도로 제공된 실제 캡처 SOCO 1페이지10건도 테스트했으며 과거 초기자료로 보존하고 발송0을 확인했다. 최신 공식 페이지 조회를 한 것은 아니다.

## 실제 연결된 코드와 데이터

`실제 v0.3 SOCO list parser/collector → 실제 HA53Stage journal 재생·hash/CAS/정책 검증 → 중앙 수집원천·공고원장·상세 → A6 noticeKind52A/recruitmentAction52A/regionV4 → Work 상세 parser와 일정 reconcile → B canonical → 기존 B event builder/영속 발송원장 → 기존 private mock adapter`.

| 코드/중앙 섹션 | 역할 |
|---|---|
| `vendor/work-v03/` | 첨부 v0.3 전체 원본211파일. 소스 수정0. 원본 테스트·결과와 이번 재실행 결과는 구분한다. |
| `src/A6Port.cjs` | 실제 A6 전체 Code.gs를 VM에 로드해 순수 판정3함수를 호출. 코드 SHA 고정, Google API 객체는 접근 시 차단. 후처리 worker/Google RPC는 실행하지 않는다. |
| `src/IntegrationBridge.js` | 정책·증거·기준선 검증, 중앙 기록, canonical 생성, 일정변경 이벤트, 연결키와 복구 gate. |
| `src/NodePipeline.cjs` | 기존 B FileStore/발송 엔진을 실제로 조립. 중앙 최신 판정을 전송 직전에 다시 읽는다. |
| `central.json.bridge.observations/details` | Work envelope/flag/원본 관측과 상세 HTTP fixture를 hash별 보존. |
| `masters/decisions/canonical` | 공고원장40열 projection, 사용자값, 실제 판정 결과/보류이유, B 입력. |
| `history/reviews/receipts/links` | 정정 전 모델, 명시적 보류, 재처리 영수증, source→모집→접수창→event→delivery 연결. |
| `delivery.json` | 기존 B 영속 이벤트/전송원장과 통합 커밋 gate. 실제 계정/토큰 없음. |

NEW는 모집회차 단위라 windowId는 null이며 관련 windowIds를 연결한다. D1/D3는 개별 windowId까지 일치한다. B의 eventKey와 deliveryKey는 같은 멱등키다. 미확정 교차게시를 단지명으로 합치지 않는다.

## staging 권한을 바꾸지 않는 방법

원본 `eventEmissionAllowed:false`, `deliveryCapability:NONE`, `INITIAL_BASELINE/OBSERVE_ONLY`를 유지한다. `INITIAL_BASELINE` 자체는 승인값이나 review가 있더라도 발송하지 않는다. 실제 Work protocol로 검증된 **완료 INITIAL 소스 baseline(SOCO/HUG list)**와 별도 mock 승인 활성화가 있어야 OBSERVE_ONLY 관측을 downstream에서 심사한다. 완료되지 않은 페이지나 operator 단순 batch를 공식 전체 baseline으로 승격하지 않는다.

baseline 이후 관측시각·공식 URL/동일 공고ID·목록/상세 내용 일치·공식 공급위치 라벨·주거 모집·일정 증거를 검증하고 독립 canonical을 만든다. 원래 staging 권한을 true로 바꾸는 코드가 아니다. 기존 초기 원천ID가 나중에 관측됐다는 이유만으로 신규화하지 않는다. 새 순위/추가접수는 상세 hash·원문 quote에 묶인 명시적 검토와 A6 신규 접수행동 근거를 요구한다. 초기자료를 승인 flag 하나로 우회할 수 없다.

기관 주소·신청자 거주요건·제목의 서울 단어로 공급지를 확정하지 않는다. 지역 미확인과 혼합 결과+후속 접수는 보류 원장을 유지한다. 복수지역의 서울·경기 공급은 보존한다. 공식 일정 충돌은 이번 bridge에서 NEW까지 HOLD한다. 날짜 미확인과 충돌은 다른 상태다. 신청자격은 자동 확정하지 않는다.

중요도는 공식 제목의 관심프로그램 또는 공급위치가 확인된 개별 아파트 전용59㎡ 이상 근거로 표시한다. 타지역84㎡·본문 자격문구만으로 ★를 붙이지 않는다. 중요도는 NEW의 차단 조건이 아니다. 같은 소스 회차의 공식 일정 의미변경만 CHANGE로 만들며, 반복 A→B→A→B 정정도 각각 보존한다. 단순 파서 변경은 신규 모집이 아니다.

## 저장 중단·재시작

중앙 저장과 B enqueue는 두 파일에 걸치므로 단일 DB transaction이라고 주장하지 않는다. 대신 B 원장에 ACTIVE 통합 gate를 먼저 영속화하고, 두 기록이 완료된 뒤 READY로 바꾼다. 중간 실패는 FAILED로 잠그며 예전 큐도 전송하지 않는다. 같은 원본 입력의 idempotent 재처리로 복구한다. `processJournal(input,{recoverFailed:true})`는 같은 입력의 기록된 실패만 재처리한다.

프로세스 강제 종료로 ACTIVE가 남으면 먼저 기존 실행 프로세스가 종료됐음을 확인하고 `recoverInterrupted(input,{previousOwnerStopped:true})`로 **정확히 같은 입력**을 복구한다. 기본 자동 해제나 다른 입력으로 덮어쓰기는 없다. CLI는 실행 전 원본 `input-v03-journal.json`을 저장한다. 원장 checksum 오류·용량 초과·외부 lock은 중단하며 빈 원장으로 초기화하지 않는다. stale lock의 소유자 확인/백업 절차는 기존 B runbook을 따른다.

B의 REQUEST_STARTED/UNKNOWN은 bridge 복구와 별개로 보존된다. 요청 성공 후 기록 중단은 UNKNOWN 격리하고 새 event key 발급이나 D1 우회로 재전송하지 않는다. 복구 gate는 공개 sender API를 임의로 우회하지 않고 NodePipeline/bridge 진입점을 사용할 때의 계약이다.

## 테스트·diff·적용 제한

- `node bridge/tests/run.cjs`: 신규56 회귀. 실제 파일 재시작/실패 주입과 실제 Work protocol 재생을 수행한다.
- 기존 A6 420(기존403 포함), B133, Work baseline74+adapter212를 별도 임시 작업 사본에서 새로 실행했다. 실제 로그/JSON은 `reports/regressions/`에 있다. Work v0.3 추가59는 이번 재실행 대상이 아니며 vendor의 기존 결과를 새 실행으로 계산하지 않는다.
- `reports/diffs/`에는 A5→A6, B 최초 구현, 기존 B commit→bridge diff를 구분한다. 이번 브랜치에서 A6/B 실행 소스 수정0이다.
- `scripts/IntegrationBridge.gs.txt`는 순수 core 전체 UTF-8 TXT다. NodePipeline/A6Port TXT는 Node 전용이다. 이것을 A6 운영 Code.gs에 합쳐 붙여넣지 않는다. 실GAS 저장/실행 driver는 미연결이다.

**남은 배포 차단:** A6 실제 clone 0→1→2→3→0·현황판 정상시각 전진·300,000ms 예산/크기/quota·중단복구/롤백·22경로/사용자열/HUG/기존 전송기록 보존, SH/GH 미확인 검토 SLA 실증, GH 공식 total/고정공지, Work v0.4 GAS sink 인수, 실제 Google 중앙 projection 연결, 공식원문/PDF 근거 추가·모집회차/교차게시 검토, 장기저장량/보관·GC·quota 검증이다. 현 노드 store는8MiB이며 무한 확장을 보장하지 않는다. PDF/OCR만 있는 근거는 이 bridge에서 임의 확정하지 않는다. SOCO 상세 기반 성공 경로를 우선 구현했고 HUG 등 근거가 부족한 레코드는 HOLD로 남긴다.

승인 후 A6 clone 최소 실증은 기존 A6 ZIP의 적용/복구 절차대로 진행한다. 대상 clone 프로젝트·시트ID/소유자·외부조회 범위·예산을 먼저 승인받고, 실제 한 순환과 다음 시작/보존 대조/중단 재개·A5 롤백을 확인한다. 운영42.A3는 그대로 둔다. 이번에는 clone을 생성하거나 실행하지 않았다. 실제 Telegram adapter·수신처·토큰·트리거는 추가하지 않았으며 실제 발송은 별도 개발/승인 대상이다.
