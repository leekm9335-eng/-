'use strict';
const fs=require('fs'),path=require('path'),root=path.join(__dirname,'..');
fs.mkdirSync(path.join(root,'scripts'),{recursive:true});
for(const name of ['IntegrationBridge.js','NodePipeline.cjs','A6Port.cjs','HandoffPolicyV04.cjs','NodePipelineV04.cjs','RoundResolverV04.cjs'])fs.copyFileSync(path.join(root,'src',name),path.join(root,'scripts',name.replace(/\.js$/,'.gs')+'.txt'));
console.log('Full UTF-8 source TXT copies built; no deployment.');
