'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),assert=require('node:assert/strict'),Pipeline=require('../src/NodePipelineV04.cjs'),F=require('../fixtures/factory-v04.cjs'),B=require('../../b11/src/DeliveryCore.js');
const args=process.argv.slice(2);if(args.length&&!(args.length===2&&args[0]==='--out'))throw Error('Usage: node bridge/tools/e2e-v04.cjs [--out DIRECTORY]');
const out=path.resolve(args[1]||fs.mkdtempSync(path.join(os.tmpdir(),'housing-bridge-e2e-')));fs.mkdirSync(out,{recursive:true});
const results=[];
function run(name,options,{reminderAt=null,expectedType='NEW',expectedCount=1,script=[]}={}){
 let clock=Date.parse('2026-11-05T01:00:00Z');const adapter=B.createMockAdapter(script),p=Pipeline.create({dir:path.join(out,name),baseline:F.baseline(),clock:()=>clock,adapter});
 const already=Object.values(p.sender.inspect().deliveries).some(x=>x.state==='DELIVERED'||x.state==='UNKNOWN_DELIVERY');
 if(!p.bridge.inspect().activations.SOCO)F.activate(p,path.join(out,name,'staging-baseline'));
 const input=F.packet({...options,directory:path.join(out,name,'staging-observations')});fs.writeFileSync(path.join(out,name,'input-v04-handoff.json'),JSON.stringify(input,null,2)+'\n');const before=JSON.stringify(input),ingest=p.bridge.processJournal(input),first=p.bridge.dispatchOne();const beforeReplay=adapter.calls().length;p.bridge.processJournal(input);p.bridge.dispatchOne();const replayCalls=adapter.calls().length-beforeReplay;assert.equal(replayCalls,0);
 const firstCount=adapter.calls().length;
 if(reminderAt){clock=Date.parse(reminderAt);p.bridge.flush();p.bridge.dispatchOne();p.bridge.flush();p.bridge.dispatchOne();}
 assert.equal(JSON.stringify(input),before,'Work policy/envelope mutated');
 const delivered=Object.values(p.sender.inspect().events).filter(e=>p.sender.inspect().deliveries[e.key].state==='DELIVERED');
 const expectedTotal=already?0:expectedCount;assert.equal(adapter.calls().length,expectedTotal,name+' mock call count');
 if(expectedTotal>0)assert(delivered.some(e=>e.type===expectedType)||first.state==='UNKNOWN_DELIVERY');
 const central=p.bridge.inspect(),row={scenario:name,inputKind:'SYNTHETIC_V04_WIRE_FORMAT',firstDecision:ingest.processed[0].decision,reason:ingest.processed[0].reason,firstDispatch:first.state,mockCallsThisProcess:adapter.calls().length,newMockCallsBeforeReminder:firstCount,mockCallsFromIdenticalReplay:replayCalls,reminderMockCalls:adapter.calls().length-firstCount,expectedCallsThisProcess:expectedTotal,restartAlreadyProcessed:already,types:delivered.map(e=>e.type),links:Object.values(central.links),upstreamHandoffStates:Object.values(central.intakes||{}).map(x=>({disposition:x.handoff&&x.handoff.disposition,roundKey:x.handoff&&x.handoff.canonicalRecruitment.roundKey,eventEmissionAllowed:x.handoff&&x.handoff.eventEmissionAllowed,independentIntakeReason:x.reason})),candidateEvidence:Object.values(central.canonical).map(r=>({roundId:r.roundId,supplyType:r.supplyType,supplyTypeEvidence:r.supplyTypeEvidence,roundResolutionEvidence:r.roundResolutionEvidence,provenance:r.handoffProvenance})),retainedWorkFlags:Object.values(central.observations).map(x=>({mode:x.envelope.stage.mode,eventEmissionAllowed:x.envelope.stage.eventEmissionAllowed,deliveryCapability:x.envelope.stage.deliveryCapability})),requestPayloads:adapter.calls(),realTelegramCalls:0};
 results.push(row);console.log(JSON.stringify({scenario:name,decision:row.firstDecision,reason:row.reason,mockRequests:row.mockCallsThisProcess,eventTypes:row.types}));
}
run('normal_new_and_d1',{id:900001,end:'2026-11-07'},{reminderAt:'2026-11-06T01:00:00Z',expectedType:'D1',expectedCount:2});
run('important_new_and_d3',{id:900002,title:'[합성fixture] 서울 신혼부부 입주자 모집공고',end:'2026-11-09'},{reminderAt:'2026-11-06T01:00:00Z',expectedType:'D3',expectedCount:2});
run('unresolved_round',{id:900008,resolve:false},{expectedCount:0});
run('schedule_conflict',{id:900003,conflict:true},{expectedCount:0});
run('unknown_region',{id:900004,location:null},{expectedCount:0});
run('initial_backfill',{id:900005,mode:'INITIAL_BASELINE'},{expectedCount:0});
run('result_only',{id:900006,title:'[합성fixture] 입주자 모집 결과 발표'},{expectedCount:0});
run('unknown_delivery',{id:900007,end:'2026-11-06'},{expectedCount:1,script:[{kind:'THROW'}]});
let archiveClock=Date.parse('2026-11-05T01:00:00Z');const receiver=Pipeline.create({dir:path.join(out,'provided_handoff_examples'),baseline:F.baseline(),clock:()=>archiveClock});
const supplied=['soco6711','soco6624','nanum','magok','uuc'].map(name=>JSON.parse(fs.readFileSync(path.join(__dirname,'../../vendor/work-v04/handoff',name+'.json'),'utf8'))),received=receiver.receiveHandoffs(supplied);
assert(received.every(r=>r.decision==='HOLD'));assert.equal(receiver.adapter.calls().length,0);
fs.writeFileSync(path.join(out,'provided_handoff_examples/receipts.json'),JSON.stringify(received,null,2)+'\n');
const report={providedWorkHandoffsHeld:received.length,mode:'MOCK_ONLY',status:'PASS',outputDirectory:out,workVersion:'0.4',actualSourceParsers:true,stagingStorage:'Work v0.4 persistent Node file sink',a6Functions:['noticeKind52A','regionV4'],centralStorage:'local JSON SHA256+atomic rename; not live Sheets',realGoogleCalls:0,realTelegramCalls:0,scenarios:results};
fs.writeFileSync(path.join(out,'e2e-results.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:'PASS',scenarios:results.length,realGoogleCalls:0,realTelegramCalls:0,output:out}));
