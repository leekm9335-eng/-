'use strict';
const Base=require('./NodePipeline.cjs'),Policy=require('./HandoffPolicyV04.cjs');
const B=require('../../b11/src/DeliveryCore.js'),hash=Base.hash;
function create(options){
 if(options&&['gasConfig','token','chat_id','writeEnabled','inputPolicy','workVersion'].some(k=>k in options))throw Error('V04_LOCAL_MOCK_ONLY_CONFIG');
 const p=Base.create({
    ...options,workVersion:'0.4',inputPolicy:Policy.create()
  }
  );
 // Handoff alone is never an instruction to emit. Source context + independent evidence are required.
 function receiveHandoffs(records){
    return p.centralStore.transaction(s=>{
      s.v04Handoffs=s.v04Handoffs||{
      }
      ;
      return records.map(h=>{
        const k=hash(B.stable(h)),key=h.original&&h.original.sourceNoticeKey||null;
        const receipt={
          hash:k,sourceNoticeKey:key,original:JSON.parse(JSON.stringify(h)),decision:'HOLD',reason:'ORIGINAL_SOURCE_CONTEXT_AND_ROUND_RESOLUTION_REQUIRED',eventEmissionAllowed:false
        }
        ;
        s.v04Handoffs[k]=s.v04Handoffs[k]||receipt;
        const current=s.bridge&&Object.values(s.bridge.canonical).find(r=>r.sourceNoticeIds.includes(key));
        if(current&&(!current.handoffProvenance||current.handoffProvenance.handoffSha256!==k)){
          s.v04PendingHandoffs=s.v04PendingHandoffs||{
          }
          ;
          s.v04PendingHandoffs[key]={
            hash:k,reason:receipt.reason
          }
          ;
        }
        return {
          hash:k,sourceNoticeKey:key,decision:'HOLD',reason:receipt.reason
        }
        ;
      }
      );
    }
    );
  }
 return {
    ...p,receiveHandoffs,workVersion:'0.4',gasExecution:'NOT_CONNECTED'
  }
  ;
}
module.exports={
  create,hash,resolveLiteralRound:require('./RoundResolverV04.cjs').resolveLiteralRound
}
;
