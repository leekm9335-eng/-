# IntegrationBridge v0.2 — Work v0.4 연결

**최상위 운영 과제는 A6 공고판정·현황판 갱신 복구다. 아직 실제 clone에서 검증하지 않았으므로 복구 성공으로 보고하지 않으며 운영 NO-GO를 유지한다.** 이 패키지는 기다리지 않고 완료한 로컬 통합 구현이다. 운영42.A3·사용자 시트·ScriptProperties·트리거·HUG·토큰·실제 Telegram 변경/발송0이다.

## 한 명령 실행

ZIP 전체를 풀고 최상위 폴더에서 실행한다. Node.js24.19.0으로 검증했고 npm·네트워크·계정이 필요 없다.

```sh
node bridge/tools/e2e-v04.cjs
```

결과 JSON과 원장 경로가 마지막 줄에 나온다. 새 프로세스에서 같은 원장을 확인하려면:

```sh
node bridge/tools/e2e-v04.cjs --out /tmp/my-housing-v04
node bridge/tools/e2e-v04.cjs --out /tmp/my-housing-v04
```

첫 실행은 일반 모집 NEW1 + D1 1, 중요 모집 NEW1 + D3 1이다. 같은 입력 즉시 반복/같은 원장으로 두 번째 프로세스 실행 시 추가0회다. 일정 충돌·지역 미확인·회차 미확정·초기 백필·단순 결과는0회다. UNKNOWN 모의 요청1회는 자동 재전송하지 않는다. 성공 입력/시계는 **합성 확정 사례(11/5→11/6)**이며 실제 공식 신규 공고가 발송됐다는 의미가 아니다. 제공된 실제 인계 JSON5개는 원래 HOLD/null 회차 그대로 별도 수신·보존했다.

## 실제 실행 경로

Work v0.4 실제 SOCO parser/collector → **v0.4 Node 영속 file sink** → v0.4 staging journal hash/CAS 검증 → 원본 `HA53_CANONICAL_HANDOFF_V1` 결합 검증 → 독립 회차·증거 판정 → 중앙 로컬 원장 → 실제 A6 notice/region 함수 → 기존 B 이벤트·영속 발송원장 → 기존 private mock adapter.

중앙 저장은 로컬 JSON이다. 실제 Sheets나 Google 저장소가 아니다. Work `staging_gas53.js`는 원본대로 포함했으며 기본OFF 상태로 남겼다. 실제 Drive/Apps Script 저장 실증은 독립 과제로 미실행이다. Work 테스트의 DriveApp fake surface 성공을 실제 GAS 실행으로 표현하지 않는다.

핵심 변경 파일:

| 파일 | 실제 기능 |
|---|---|
| `src/HandoffPolicyV04.cjs` | 상세/관측 SHA·snapshot·공식 URL·공급지역 quote·공급유형 근거·일정·회차 결합 검증. 원 응답 SHA와 배포 fixture SHA를 별도 보존. |
| `src/RoundResolverV04.cjs` | 원문에 명시된 유일한 연도/모집회차 라벨만 별도 해석. 라벨 없음·충돌·잘못된 binding은 HOLD. 단순 list hint나 임의 round string은 거부. |
| `src/NodePipelineV04.cjs` | v0.4와 정책을 강제 조립. legacy 강등·실GAS/토큰/실수신 설정 불가. 인계 JSON만 받으면 HOLD 기록. |
| `src/IntegrationBridge.js` | 기존 증분 baseline/A6/B 경로에 선택적 intake/evidence hook 추가, 원본 인계·독립 판정·공급유형·회차·일정 근거를 중앙에 기록. |
| `src/NodePipeline.cjs` | v0.3 호환 유지 + v0.4 모듈 선택. 최신 미확정 인계가 있는 기존 후보도 전송 전 격리. |
| `fixtures/factory-v04.cjs`, `tools/e2e-v04.cjs` | 실제 Work 코드로 합성 list/detail을 수집·저장하고 production RoundResolver·정책·발송 경로를 실행. 사전 조작 canonical을 직접 발송하지 않는다. |

A6·B 실행 소스는 수정0이다. `vendor/work-v04/`의 원본247개 hash도 그대로다. `vendor/work-v03/` 및 기존 bridge56 테스트는 호환 회귀용으로 보존했다. 현재 기본 실행/인수 경로는 v04 CLI다. v01 README는 `docs/README_bridge_v01.md`에 보관했다.

## HOLD/null을 임의로 해제하지 않는 계약

원본 인계의 `disposition:HOLD`, `roundKey:null`, `eventEmissionAllowed:false`, `deliveryCapability:NONE`, `holdReasons`는 저장 후에도 그대로다. 독립 후보만 별도로 생성하며 Work staging 자체를 이벤트 발행기로 바꾸지 않는다.

- 원본 source/snapshot/observation hash 및 전체 handoff를 Work convert로 재생해 대조한다. 원본 필드 수정·deadline 강제 변경·공급유형 바꾸기·다른 파일 근거는 거부한다.
- 명시적인 소스 승인·완료 INITIAL baseline·증분 시작시각을 별도로 통과해야 한다. INITIAL 데이터 자체는 회차 근거가 있어도 발송0이다.
- roundKey가 없으면 기본 HOLD다. 원문의 `모집회차/모집차수/공고회차` 라벨이 유일하고 연도·차수/순위가 명시된 경우에만 별도 `BRIDGE_ROUND_RESOLUTION_V1`을 만들 수 있다. 원본 인계 hash/관측 hash/quote/확인시각을 묶고 모든 증거를 재확인한다. 원본 roundKey는 계속 null이다. 라벨 없는 실제 사례를 임의 생성 ID로 통과시키지 않는다.
- 공급지역은 주택위치 등 공식 공급지 라벨만 사용한다. 기관 주소/신청자 거주요건은 대체 근거가 아니다. 공급유형은 SOCO 원 필드optn2 또는 직접 확인되는 본문 근거를 보존하며 명시 라벨 충돌은 HOLD다. 실제 원 응답 hash와 redacted fixture hash를 합치지 않는다. 배포 fixture 바이트는 로컬에서 검증하며, 원 응답 바이트가 없는 경우 원 응답 SHA는 상위 manifest의 보고값으로 표시하고 재조회 검증 완료라고 하지 않는다.
- 일정 충돌·지역/회차 미확정·공식 정정 의미 미확인은 명시적 보류다. 최신 다른 인계의 HOLD를 받은 기존 대기 후보도 격리하며, 같은 handoff에 대한 원본 context+충분한 근거가 검증된 뒤에만 해제한다.
- 일반 NEW 및 D1은 중요도와 무관하다. D3은 중요만이다. 23:00~07:00 KST 즉시 무음 정책과 개인1명 mock 범위는 기존 B를 따른다.

canonical/원장에는 공급유형 근거, 회차 resolution, 원 handoff hash/원래 HOLD 이유, 공식 일정 claims/resolved window, 캡처 출처를 보존한다. 기존 원천·상세·정정·사용자 입력·SENT/UNKNOWN은 삭제하지 않는다. NEW는 모집 단위라 windowIds로 접수창을 연결하고, D1/D3는 windowId 단위다. eventKey와 deliveryKey는 기존 B의 같은 멱등키다.

## 결과·실패·재시작

`reports/v04/e2e-first/`는 실제 첫 Node 프로세스의 입력·파일 staging·중앙/발송 원장·stdout·JSON이고 `e2e-second/`는 같은 데이터로 새 Node 프로세스에서 추가0회인 결과다. Work 실제 인계5개는 별도 HOLD 영수증이 있다.

- 신규 통합45/45, 기존 bridge56/56 통과.
- 기존 A6 420/420(기존403 포함), B133/133을 별도 사본에서 새로 실행했다.
- Work v0.4 소스로 baseline74 + adapters212 + v0.3회귀59 + v0.4신규41 =386/386을 새로 실행했다. 실제 Google 실행0이다.
- 최초 샌드박스 실행은 Work 자식 Node 재시작 테스트의 stdout이 비어 40/41이었다. 원본 테스트 코드를 변경하지 않고 정상 프로세스 실행 권한으로 다시 실행해41/41을 확인했다. 첫 실패 로그도 삭제하지 않고 `reports/v04/regressions/`에 보존했다.

재실행: `node bridge/tests/v04.cjs`, `node bridge/tests/run.cjs`. A6는 원본 ZIP 내부 runner, B는 `node b11/tests/run.cjs`를 사용한다. 전체 로그/JSON 및 소스 보존 hash는 `reports/v04/`에 있다. 현재 branch와 기존 bridge v01 사이의 실제 diff도 포함한다.

중앙+B 저장은 두 파일이므로 전송 gate를 먼저ACTIVE로 기록하고 모두 완료 후READY로 바꾼다. 실패는FAILED로 격리한다. 기록된 실패는 정확히 같은 입력으로 `processJournal(input,{recoverFailed:true})`, 강제 종료는 실행자 종료 확인 후 `recoverInterrupted(input,{previousOwnerStopped:true})`로 복구한다. UNKNOWN을 재전송하거나 상태를 지워 우회하지 않는다. `input-v04-handoff.json`은 처리 전에 저장한다.

## A6 최소 clone 실증 — 별도 승인 후에만

1. 대상 clone 프로젝트·시트ID/소유자·권한·공식조회 허용범위·최대 실행 예산을 승인받고, 실제42.A3 전체 소스/manifest/데이터/비밀 제외 속성·트리거 구성을 백업한다. 실제 토큰/발송 설정을 복제하지 않는다.
2. clone을 가리키는 A6 전체 코드로 기존 worker 진입점을 실행해 **0→1→2→3→0와 다음 시작**을 관측한다. phase/generation/cursor·대기/부분/실패/성공시각과 실제 공고판정·현황판 마지막 정상시각 전진을 확인한다. install/트리거 재설치·강제 단계 초기화로 완료를 꾸미지 않는다.
3. 기존22경로·원장·원천·상세·정정·전송기록·HUG 과거자료·사용자열의 전후 키/행수/hash를 대조한다. 실제 gzip/청크 크기·RPC/quota·lock·300,000ms/24h 파생 예산·중단 보수예약을 측정한다. 예산을 임의 리셋/증액하지 않는다.
4. clone 중단·재개와 A6→A5 코드 롤백을 확인한다. 정상 checkpoint/청크/예산·기존 원장을 삭제하지 않는다. 실제 증거와 독립 검토 후 운영 배포를 별도로 승인한다.

**배포 차단 유지:** 위 A6 실증, SH/GH 미확인 검토 SLA, GH 공식 total/고정공지, Work GAS 실제 저장/quota·복구, 중앙 Sheets projection 및 장기저장량·GC·동시실행 검증. 로컬 FileStore는8MiB cap이며 데이터 증가에 대한 무제한 운영 보장이 아니다. PDF/OCR만 있는 미확정 근거·복잡한 차수/교차게시 관계는 명시적 추가 검토가 필요하다. Bridge 버전 복원 시 dispatch를 멈추고 두 원장/전송 gate를 보존한다. v04 인계를 legacy 자동 회차 경로로 우회하지 않는다. 현재 운영 복구 성공/배포 GO를 선언하지 않는다.
