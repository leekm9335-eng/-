'use strict';
// SYNTHETIC payloads following the supplied v0.3 wire format. No HTTP requests.
const Stage=require('../../vendor/work-v03/src/staging53'),Collector=require('../../vendor/work-v03/src/collector53');
const clone=x=>JSON.parse(JSON.stringify(x));
function baseline(){return {id:'BRIDGE_SYNTHETIC_BASELINE_1',approved:true,approvalScope:'MOCK_ONLY',goLiveAt:'2026-11-04T00:00:00Z',sources:{SOCO:{state:'INCREMENTAL',monitoringStartAt:'2026-11-04T00:00:00Z'}},knownRecruitmentVersions:[],knownChangeVersions:[],legacyEventKeys:[]};}
function journal(records,{snapshotId='incremental_fixture',mode='OBSERVE_ONLY',observedAt='2026-11-04T00:10:00Z'}={}){
 const sink=Stage.createMemory(),state=Collector.initial('SOCO',snapshotId,mode),text=JSON.stringify({resultList:records,pagingInfo:{pageIndex:1,totRow:records.length,totPage:records.length?1:0,rowCount:Math.max(10,records.length),bbsId:'BMSR00015'}});
 Collector.step(state,{status:200,url:Collector.request(state).url,text,observedAt},Date.parse(observedAt),sink);
 return sink.exportJournal('SOCO',snapshotId);
}
function initial(){return {transactions:journal([],{snapshotId:'synthetic_empty_source_baseline',mode:'INITIAL_BASELINE',observedAt:'2026-11-04T00:00:00Z'})};}
const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
function packet(options={}){
 const id=options.id||900001,title=options.title||'[합성fixture] 서울 45㎡ 입주자 모집공고',end=options.end||'2026-11-06',loc=options.location===undefined?'서울특별시 은평구 불광동 302-13':options.location;
 const lines=['SYNTHETIC — 실제 공고 아님','■단지명 : 합성 테스트 주택',...(loc?['■주택위치 : '+loc,'■공급주택형 : '+loc+' 아파트 전용면적 '+(options.unitArea||45)+'㎡']:[]),'■공급호수 : 금회 임대 4세대','■사업주체 : 합성 공급기관','■청약신청 : 2026. 11. 04. 09:00 ~ '+end.replaceAll('-','. ')+'. 17:00'];
 if(options.conflict)lines.push('■청약신청 : 2026. 11. 04. 09:00 ~ 2026. 11. 09. 17:00');if(options.extra)lines.push(options.extra);
 const html='<div class="board_cont">'+lines.map(x=>'<p>'+esc(x)+'</p>').join('')+'</div>';
 const raw={boardId:id,bbsId:'BMSR00015',nttSj:title,optn1:'2026-11-04',optn2:'2',optn3:'합성 공급기관',optn4:'2026-11-04',optn5:'1',regDate:1793750400000,modDate:1793750400000,atchFileId:null,content:html};
 const key='SOCO_YOUTH:BMSR00015:'+id,url='https://soco.seoul.go.kr/youth/bbs/BMSR00015/view.do?boardId='+id+'&menuNo=400008';
 return {synthetic:true,transactions:journal([raw],options),details:{[key]:{url,status:200,text:html}}};
}
function activate(pipeline){const input=initial();pipeline.bridge.registerBaseline(input);const tx=input.transactions.at(-1);pipeline.bridge.activate({source:'SOCO',approved:true,mode:'MOCK_ONLY',baselineId:baseline().id,incrementalAt:baseline().sources.SOCO.monitoringStartAt,baselineSnapshotId:tx.snapshotId,baselineCommitRef:tx.commitRef});}
module.exports={baseline,packet,initial,activate,journal,clone};
