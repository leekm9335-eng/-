'use strict';
// SYNTHETIC payloads following the supplied v0.3 wire format. No HTTP requests.
const H=require('../../vendor/work-v04/src/hash53'),E=require('../../vendor/work-v04/src/handoff53'),S=require('../../vendor/work-v04/src/soco53_adapter'),File=require('../../vendor/work-v04/src/staging_file53.cjs');
const Stage=require('../../vendor/work-v04/src/staging53'),Collector=require('../../vendor/work-v04/src/collector53');
const clone=x=>JSON.parse(JSON.stringify(x));
function baseline(){return {id:'BRIDGE_SYNTHETIC_BASELINE_1',approved:true,approvalScope:'MOCK_ONLY',goLiveAt:'2026-11-05T00:00:00Z',sources:{SOCO:{state:'INCREMENTAL',monitoringStartAt:'2026-11-05T00:00:00Z'}},knownRecruitmentVersions:[],knownChangeVersions:[],legacyEventKeys:[]};}
function journal(records,{snapshotId='incremental_fixture',mode='OBSERVE_ONLY',observedAt='2026-11-05T00:10:00Z'}={}){
 const sink=arguments[1]&&arguments[1].directory?File.createFileSink(require('path').resolve(arguments[1].directory)):Stage.createMemory(),state=Collector.initial('SOCO',snapshotId,mode),text=JSON.stringify({resultList:records,pagingInfo:{pageIndex:1,totRow:records.length,totPage:records.length?1:0,rowCount:Math.max(10,records.length),bbsId:'BMSR00015'}});
 Collector.step(state,{status:200,url:Collector.request(state).url,text,observedAt},Date.parse(observedAt),sink);
 return sink.transactions('SOCO',snapshotId);
}
function initial(directory){return {transactions:journal([],{directory,snapshotId:'synthetic_empty_source_baseline',mode:'INITIAL_BASELINE',observedAt:'2026-11-05T00:00:00Z'})};}
const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
function packet(options={}){
 const id=options.id||900001,title=options.title||'[합성fixture] 서울 45㎡ 입주자 모집공고',end=options.end||'2026-11-07',loc=options.location===undefined?'서울특별시 은평구 불광동 302-13':options.location;
 const lines=['SYNTHETIC — 실제 공고 아님','■단지명 : 합성 테스트 주택',...(loc?['■주택위치 : '+loc,'■공급주택형 : '+loc+' 아파트 전용면적 '+(options.unitArea||45)+'㎡']:[]),'■공급호수 : 금회 임대 4세대','■사업주체 : 합성 공급기관','■청약신청 : 2026. 11. 05. 09:00 ~ '+end.replaceAll('-','. ')+'. 17:00'];
 if(options.roundLabel!==false)lines.push('■모집회차 : '+(options.roundLabel||'2026년도 최초 1차 모집'));
 if(options.conflict)lines.push('■청약신청 : 2026. 11. 05. 09:00 ~ 2026. 11. 09. 17:00');if(options.extra)lines.push(options.extra);
 const html='<div class="board_cont">'+lines.map(x=>'<p>'+esc(x)+'</p>').join('')+'</div>';
 const raw={boardId:id,bbsId:'BMSR00015',nttSj:title,optn1:'2026-11-05',optn2:options.supplyType==='PUBLIC_RENT'?'1':'2',optn3:'합성 공급기관',optn4:'2026-11-05',optn5:'1',regDate:Date.parse('2026-11-05T00:00:00Z'),modDate:Date.parse('2026-11-05T00:00:00Z'),atchFileId:null,content:html};
 const key='SOCO_YOUTH:BMSR00015:'+id,url='https://soco.seoul.go.kr/youth/bbs/BMSR00015/view.do?boardId='+id+'&menuNo=400008';
 const transactions=journal([raw],options),detail={url,status:200,text:html},envelope=transactions.at(-1).observations[0],parsed=S.soco53ParseDetail(detail,envelope.observation);
 const quote=parsed.bodyText.split(/\n/).map(x=>x.trim()).find(x=>/^[■●\s]*주택위치\s*[:：]/.test(x));
 const sido=quote&&((quote.match(/서울특별시|경기도|부산광역시/)||[])[0]);
 const regionEvidence=quote&&sido?[{sido,sigungu:null,quote,origin:{url,layer:'WEB_BODY'},status:'OFFICIAL_LITERAL_ADDRESS_EVIDENCE'}]:[];
 const h=E.convert(Stage.envelope(parsed,envelope.stage),{regionEvidence,supplyTypeEvidence:{origin:{url,layer:'SOCO_LIST_JSON'},field:'optn2',value:raw.optn2,basis:'OFFICIAL_LIST_FIELD_MAPPING'},sourceResponseSha256:H.sha256(html),fixtureSha256:H.sha256(html)});
 const input={synthetic:true,transactions,details:{[key]:detail},handoffs:{[key]:h},captures:{[key]:{kind:'SYNTHETIC_FIXTURE',synthetic:true}},roundResolutions:{}};
 const roundQuote=parsed.bodyText.split(/\n/).map(x=>x.trim()).find(x=>/^[■●\s]*모집회차\s*[:：]/.test(x));
 if(options.resolve!==false){const result=require('../src/RoundResolverV04.cjs').resolveLiteralRound({handoff:h,observation:parsed,kind:options.resolutionKind||'ROUND_RESOLUTION',confirmedAt:new Date(Date.parse(options.observedAt||'2026-11-05T00:10:00Z')+60000).toISOString()});if(result.state==='CONFIRMED')input.roundResolutions[key]=result.resolution;}
 return input;
}
function activate(pipeline,directory){const input=initial(directory);pipeline.bridge.registerBaseline(input);const tx=input.transactions.at(-1);pipeline.bridge.activate({source:'SOCO',approved:true,mode:'MOCK_ONLY',baselineId:baseline().id,incrementalAt:baseline().sources.SOCO.monitoringStartAt,baselineSnapshotId:tx.snapshotId,baselineCommitRef:tx.commitRef});}
module.exports={baseline,packet,initial,activate,journal,clone};
