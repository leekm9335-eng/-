# IntegrationBridge v0.2 / Work v0.4 전체 실행 패키지

**최우선 운영 과제: A6 공고판정·현황판 갱신 복구. 실제 clone 미검증이며 운영 NO-GO입니다.** 이번 산출물은 로컬 통합 구현입니다. 운영42.A3/사용자 시트/속성/트리거/토큰/실제 Telegram을 변경하지 않았습니다.

ZIP 전체를 풀고 최상위 폴더에서 실행하세요(Node.js24, npm/계정/네트워크 불필요).

```sh
node bridge/tools/e2e-v04.cjs
```

상세 계약/최소 clone 절차/복구/한계: `bridge/README.md`. 첫/두 번째 프로세스 실행 로그·입력·원장: `bridge/reports/v04/e2e-first/`, `e2e-second/`. 신규45 및 기존 bridge56/A6 420/B133/Work386 로컬 회귀 결과는 `bridge/reports/v04/`에 있습니다.

성공 사례는 합성 확정 입력입니다. 제공된 실제 인계 JSON5개는 원래HOLD/null 회차 상태로 보존합니다. Work의 실제 GAS 저장 실증은 독립 미완료 과제입니다.

최종 A6 원본 전체 ZIP: `baseline/local6/full.zip`; A6 전체 TXT: `scripts/A6_Code.gs.txt`. B 전체 실행 TXT: `b11/scripts/`; 새 bridge 전체 TXT/소스: `bridge/scripts/`, `bridge/src/`. Node 전용 파일을 운영 Apps Script에 붙여넣지 마세요.

현재 bridge 이전 버전 대비 diff 및 Work 원본 v03→v04 diff: `bridge/reports/v04/diffs/`. 기존 A6/B diff도 보존했습니다. 버전/커밋은 `git-metadata.json`, 전체 파일 무결성은 `SHA256SUMS.txt`로 확인합니다. 실제 운영 복구 성공을 선언하지 않습니다.
